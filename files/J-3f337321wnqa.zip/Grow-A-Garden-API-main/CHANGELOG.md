# Changelog
## v1.1.5 
### Added
- Calculate Plant Value Module

## v1.1.4
### Fixed Vulcan API issue :D
- Nice Try Vulcan but if you want to contact me my username is | ijuew | on Discord
## v1.1.3
### Added Back Weather
- Yippe :D

## v1.1.2
### Added Hash Check
- This Will Prevent Too much Traffic from senting a lot of request to vulcan api

## v1.1.1
### Fixed GetStock
- Removed Old Method of Getting Stocks 
- Stoled Some other guy Api 🤑

## v1.1.0
### Added
- Added Proper Error Codes for Weather & GetStock
- Added success to Weather & GetStock

## v1.0

### Added / Changed
- Added /api/stocks/getstock
- Added /api/stocks/restock-time
- Added /api/getweather
- Added /api/item-info
- Added IP Whitelisted 
- Added Changeable port
- Added Dashboard You can disable it if you don't like it or want to use it through servers 
