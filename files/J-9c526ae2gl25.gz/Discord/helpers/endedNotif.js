
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('jkt48connect-discord');
const { getRecentLive } = require('jkt48connect-cli');

const channelConfigPath = './Discord/channel/idn-notif.json';
const databasePath = './sentEndedLive.json';

function ensureDatabase() {
    const dir = path.dirname(databasePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(databasePath)) {
        fs.writeFileSync(databasePath, JSON.stringify([]));
    }
}

function readDatabase() {
    ensureDatabase();
    return JSON.parse(fs.readFileSync(databasePath, 'utf8'));
}

function writeDatabase(data) {
    fs.writeFileSync(databasePath, JSON.stringify(data, null, 2));
}

function formatDuration(durationInMilliseconds) {
    const durationInSeconds = durationInMilliseconds / 1000;
    const hours = Math.floor(durationInSeconds / 3600);
    const minutes = Math.floor((durationInSeconds % 3600) / 60);
    let durationString = '';
    if (hours > 0) durationString += `${hours} Jam`;
    if (minutes > 0 || hours === 0) {
        if (durationString) durationString += ' | ';
        durationString += `${minutes} Menit`;
    }
    return durationString || '0 Menit';
}

async function fetchRecentEndedStreams() {
    try {
        console.log('Fetching recent ended streams...');
        const data = await getRecentLive('JKTCONNECT');
        if (data && Array.isArray(data)) {
            console.log(`Found ${data.length} recent ended streams.`);
            return data.map(recent => ({
                id: recent.data_id,
                name: recent.member?.name || 'Unknown',
                nickname: recent.member?.nickname || null,
                title: recent.idn?.title || `Live Showroom: ${recent.member?.nickname}`,
                image: recent.idn?.image || null,
                views: recent.live_info?.viewers?.num || '0',
                duration: recent.live_info?.duration || 0,
                avatar: recent.member?.img || null,
                type: recent.type || 'Unknown',
                url: recent.idn?.slug || recent.member?.url || 'unknown',
                total_gift: recent.total_gift || 'Rp 0', // Added total_gift field
                is_excitement: recent.live_info?.viewers?.is_excitement || false // Added excitement indicator
            }));
        }
        return [];
    } catch (error) {
        console.error('Error fetching recent ended streams:', error);
        return [];
    }
}

async function sendEndedLiveNotification(discordClient) {
    try {
        const endedStreams = await fetchRecentEndedStreams();
        if (!endedStreams.length) {
            console.log('No ended streams found.');
            return;
        }
        
        const sentData = readDatabase();

        let liveChannelIds;
        try {
            liveChannelIds = JSON.parse(fs.readFileSync(channelConfigPath, 'utf8'));
            if (!liveChannelIds || !liveChannelIds.length) {
                console.log('No channel IDs configured.');
                return;
            }
        } catch (err) {
            console.error('Error reading channel IDs:', err);
            return;
        }

        for (const endedStream of endedStreams) {
            if (sentData.some(data => data.id === endedStream.id)) {
                console.log(`Stream with ID ${endedStream.id} already sent.`);
                continue;
            }

            console.log(`Processing notification for ${endedStream.name} (${endedStream.id})`);
            
            const formattedDuration = formatDuration(endedStream.duration);
            
            // Add excitement indicator for high-traffic streams
            const excitementIndicator = endedStream.is_excitement ? 
                '🔥 **EXCITEMENT!**' : '';
                
            // Set color based on platform
            let embedColor = '#FF5733'; // Default orange
            if (endedStream.type === 'showroom') {
                embedColor = '#FF1493'; // Pink for Showroom
            } else if (endedStream.type === 'idn') {
                embedColor = '#1E90FF'; // Blue for IDN
            }

            const embed = new EmbedBuilder()
                .setTitle(`🎬 Live Selesai! Terima Kasih, ${endedStream.name}! 🎬`)
                .setDescription(`
${excitementIndicator}
**${endedStream.nickname}** telah selesai live!
✨ **Judul:** \`${endedStream.title}\`
📊 **Durasi:** \`${formattedDuration}\`
👀 **Penonton:** \`${endedStream.views}\`
💰 **Total Gift:** \`${endedStream.total_gift}\`

Pantau terus live berikutnya hanya di [JKT48Connect](https://www.jkt48connect.my.id)!
                `)
                .setColor(embedColor)
                .setThumbnail(endedStream.avatar || undefined)
                .setImage(endedStream.image || undefined)
                .setFooter({ text: `Powered by JKT48Connect • Platform: ${endedStream.type.toUpperCase()}` })
                .setTimestamp();

            let notificationSent = false;
            for (const liveChannelId of liveChannelIds) {
                const liveChannel = discordClient.channels.cache.get(liveChannelId);
                if (!liveChannel) {
                    console.error(`Channel ID ${liveChannelId} not found.`);
                    continue;
                }
                try {
                    await liveChannel.send({ embeds: [embed] });
                    console.log(`Notification sent: ${endedStream.title} to ${liveChannelId}`);
                    notificationSent = true;
                } catch (err) {
                    console.error(`Error sending notification: ${endedStream.title} to ${liveChannelId}`, err);
                }
            }
            
            // Only mark as sent if we successfully sent at least one notification
            if (notificationSent) {
                sentData.push({ 
                    id: endedStream.id, 
                    name: endedStream.name,
                    timestamp: new Date().toISOString() 
                });
            }
        }
        
        // Limit the database to store only the last 100 entries to prevent it from growing too large
        if (sentData.length > 100) {
            sentData.splice(0, sentData.length - 100);
        }
        
        writeDatabase(sentData);
    } catch (error) {
        console.error('Error in sendEndedLiveNotification:', error);
    }
}

function startCheckingEvery10Seconds(discordClient) {
    console.log('Starting ended live notification service...');
    // Run immediately once
    sendEndedLiveNotification(discordClient).catch(err => 
        console.error('Error on initial check:', err)
    );
    
    // Then set interval
    return setInterval(() => {
        console.log('Checking for new ended live streams...');
        sendEndedLiveNotification(discordClient).catch(err => 
            console.error('Error on interval check:', err)
        );
    }, 10000);
}

module.exports = sendEndedLiveNotification;
