// Discord/helpers/checkLive.js
const axios = require('axios');

async function checkLive() {
    try {
        const response = await axios.get('https://idn-api.zyrohost.my.id/api/jkt48');
        const data = response.data;

        // If no stream is live, return null
        if (!data || data.length === 0) return null;

        // Assuming the API returns an array of streams, we get the first stream
        const stream = data[0];
        return {
            name: stream.name,
            title: stream.title,
            liveAt: stream.live_at,
            viewCount: stream.view_count,
            streamUrl: stream.stream_url,
            imageUrl: stream.image
        };
    } catch (error) {
        console.error('Error fetching live data:', error);
        return null;
    }
}

module.exports = checkLive;
