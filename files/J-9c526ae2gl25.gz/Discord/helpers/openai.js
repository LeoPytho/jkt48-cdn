const axios = require('axios');

// Define GPT-4 logic
async function openai(text, logic) {
    try {
        // Send a POST request to the OpenAI API
        const response = await axios.post(
            "https://chateverywhere.app/api/chat/", // Ensure this URL is correct
            {
                model: "gpt-4", // Simplified model declaration
                messages: [
                    {
                        role: "user",
                        content: text, // User's input text
                    }
                ],
                prompt: logic, // Additional logic if required
                temperature: 0.5 // Adjust temperature as necessary
            },
            {
                headers: {
                    "Accept": "application/json", // Expect JSON response
                    "Content-Type": "application/json", // Specify content type
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            }
        );

        // Return the text of the assistant's reply from the response data
        return response.data; // Adjust this line if response structure differs
    } catch (error) {
        console.error('Error with OpenAI API request:', error.message);
        
        // Log detailed response error if available
        if (error.response) {
            console.error('API Response Error:', error.response.data);
        }
        
        // Throw a new error to handle it where the function is called
        throw new Error('Failed to communicate with OpenAI API');
    }
}

module.exports = openai;
