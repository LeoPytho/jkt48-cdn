const fs = require('fs');
const path = require('path');
const { getNews, getNewsDetail } = require('jkt48connect-cli');
const { EmbedBuilder } = require('discord.js');

// Path ke file penyimpanan berita terkirim
const sentNewsFilePath = path.join(__dirname, '../../Discord/channel/sent-news.json');

// Fungsi untuk membaca daftar berita yang sudah terkirim
function readSentNews() {
    if (fs.existsSync(sentNewsFilePath)) {
        try {
            return JSON.parse(fs.readFileSync(sentNewsFilePath, 'utf8'));
        } catch (error) {
            console.error('Error membaca sent-news.json:', error);
        }
    }
    return [];
}

// Fungsi untuk menyimpan daftar berita yang sudah terkirim
function saveSentNews(newsList) {
    try {
        fs.writeFileSync(sentNewsFilePath, JSON.stringify(newsList, null, 2));
    } catch (error) {
        console.error('Error menyimpan sent-news.json:', error);
    }
}

// Fungsi untuk memproses konten HTML menjadi teks
function parseHTMLContent(content) {
    return content
        .replace(/&nbsp;/g, ' ')
        .replace(/&bull;/g, '•')
        .replace(/&ldquo;/g, '“')
        .replace(/&rdquo;/g, '”')
        .replace(/&amp;/g, '&')
        .replace(/<br\s*\/?\>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .trim();
}

// Fungsi untuk membagi teks panjang menjadi beberapa bagian (max 1024 karakter per field)
function splitTextIntoChunks(text, chunkSize = 1024) {
    let chunks = [];
    for (let i = 0; i < text.length; i += chunkSize) {
        chunks.push(text.substring(i, i + chunkSize));
    }
    return chunks;
}

// Fungsi untuk mengambil daftar berita terbaru
async function fetchLatestNews() {
    try {
        const response = await getNews('JKTCONNECT');
        return response.news || [];
    } catch (error) {
        console.error('Error fetching latest news from API:', error);
        return [];
    }
}

// Fungsi untuk mengambil detail berita
async function fetchNewsDetail(newsId) {
    try {
        const response = await getNewsDetail('JKTCONNECT', newsId);
        return {
            title: response.title,
            parsedContent: parseHTMLContent(response.content),
            thumbnailUrl: response.label ? `https://jkt48.com${response.label}` : null
        };
    } catch (error) {
        console.error(`Error fetching news detail for ID ${newsId}:`, error);
        return null;
    }
}

// Fungsi untuk mengirim berita ke Discord
async function sendNewsEmbed(discordClient) {
    let sentNews = readSentNews();
    const latestNewsList = await fetchLatestNews();

    for (const news of latestNewsList) {
        if (sentNews.includes(news._id)) continue; // Skip jika sudah terkirim
        
        const detail = await fetchNewsDetail(news.id);
        if (!detail) continue;

        const contentChunks = splitTextIntoChunks(detail.parsedContent);

        const embed = new EmbedBuilder()
            .setTitle(`${news.title} - ${news.date}`)
            .setURL(`https://jkt48.com/news/detail/id/${news.id}?lang=id`)
            .setColor('#FFD700')
            .setFooter({ text: 'Powered by JKT48Connect' });

        if (detail.thumbnailUrl) embed.setThumbnail(detail.thumbnailUrl);

        // Menambahkan isi berita ke dalam field tanpa terlihat terpisah
        embed.addFields(
            { name: "Deskripsi", value: contentChunks[0], inline: false },
            ...contentChunks.slice(1).map(chunk => ({ name: "\u200B", value: chunk, inline: false }))
        );

        const channelsPath = path.join(__dirname, '../../Discord/channel/news-notif.json');
        if (!fs.existsSync(channelsPath)) {
            console.error('File news-notif.json tidak ditemukan.');
            continue;
        }

        const channels = JSON.parse(fs.readFileSync(channelsPath, 'utf8')) || [];
        
        for (const channelId of channels) {
            const channel = discordClient.channels.cache.get(channelId);
            if (!channel) continue;
            try {
                await channel.send({ embeds: [embed] });
                console.log(`Berita terbaru "${news.title}" dikirim ke ${channelId}.`);
            } catch (error) {
                console.error(`Error sending news to channel ${channelId}:`, error);
            }
        }

        sentNews.push(news._id);
        saveSentNews(sentNews);
    }
}

// Fungsi untuk menjalankan polling berita
async function startNewsPolling(discordClient, interval = 60000) {
    console.log('Memulai polling berita...');
    setInterval(() => sendNewsEmbed(discordClient), interval);
}

module.exports = startNewsPolling;
