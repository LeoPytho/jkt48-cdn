const axios = require('axios');
const { EmbedBuilder } = require('jkt48connect-discord');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Path to the database directory and file
const dbDirectory = path.join(__dirname, '../Database');
const dbPath = path.join(dbDirectory, 'theater_schedule.db');

// Check if the Database directory exists, create it if it doesn't
if (!fs.existsSync(dbDirectory)) {
    fs.mkdirSync(dbDirectory, { recursive: true });
}

// Initialize the SQLite database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to the theater_schedule database.');
    }
});

// Create the schedule table if it doesn't exist
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            start_at INTEGER,
            notified INTEGER DEFAULT 0
        )
    `);
});

// Map of setlist titles to their image URLs
const imageMap = {
    'Pajama Drive': 'https://res.cloudinary.com/dbim4qou7/image/upload/v1718869150/pajama%20drive.png',
    'Cara Meminum Ramune': 'https://res.cloudinary.com/dbim4qou7/image/upload/v1721790478/ramuneintens.jpg',
    'Aturan Anti Cinta': 'https://res.cloudinary.com/dbim4qou7/image/upload/v1726117952/rkjnewwtyp.jpg',
    'Ingin Bertemu': 'https://res.cloudinary.com/dbim4qou7/image/upload/v1718872127/inginbertemutyp.jpg',
};

// Function to fetch the schedule data from the API
async function fetchTheaterSchedule() {
    try {
        const response = await axios.get('https://sorum-valz-store.vercel.app/api/rooms/theater-schedule');
        return response.data;
    } catch (error) {
        console.error('Error fetching theater schedule:', error);
        return null;
    }
}

// Function to save shows to the database
function saveShowToDatabase(title, start_at) {
    db.run(
        `INSERT INTO schedule (title, start_at, notified) VALUES (?, ?, 0)`,
        [title, start_at],
        function (err) {
            if (err) {
                console.error('Error saving show to database:', err.message);
            } else {
                console.log(`Show saved to database: ${title}`);
            }
        }
    );
}

// Function to send the reminder message
async function sendReminderMessage(discordClient, schedule) {
    const reminderChannel = discordClient.channels.cache.get('1298992690045915166');

    if (!reminderChannel) {
        console.error('Reminder channel not found.');
        return;
    }

    // Get the image URL based on the title
    const showTitle = schedule.title;
    const imageUrl = imageMap[Object.keys(imageMap).find(title => showTitle.includes(title))] || null;

    const embed = new EmbedBuilder()
        .setColor('#ff4500')
        .setTitle('⏰ Show Reminder!')
        .setDescription(`Setlist **${schedule.title}** will start soon!`)
        .addFields(
            { name: 'Show Date', value: `<t:${Math.floor(schedule.start_at)}:D>` },
            { name: 'Start Time', value: `<t:${Math.floor(schedule.start_at)}:t>` }
        )
        .setFooter({ text: 'Setlist will begin shortly. Stay tuned!' });

    if (imageUrl) {
        embed.setImage(imageUrl);
    }

    try {
        await reminderChannel.send({ embeds: [embed] });
        console.log('Reminder message sent.');

        // Mark the show as notified in the database
        db.run(`UPDATE schedule SET notified = 1 WHERE id = ?`, [schedule.id], (err) => {
            if (err) {
                console.error('Error updating notification status:', err.message);
            }
        });
    } catch (error) {
        console.error('Error sending reminder message:', error);
    }
}

// Function to automatically send reminders for today's shows
async function sendTodayShowReminders(discordClient) {
    const today = new Date().toISOString().split('T')[0];
    
    db.all(
        `SELECT * FROM schedule WHERE strftime('%Y-%m-%d', start_at, 'unixepoch') = ? AND notified = 0`,
        [today],
        (err, rows) => {
            if (err) {
                console.error('Error querying shows for today:', err.message);
                return;
            }

            const now = Date.now() / 1000;
            rows.forEach(show => {
                if (show.start_at > now) {
                    const delay = (show.start_at - now) * 1000;
                    setTimeout(() => {
                        sendReminderMessage(discordClient, show);
                    }, delay);
                    console.log(`Scheduled reminder for today's show "${show.title}" 1 hour before the start.`);
                } else {
                    console.log(`Skipped scheduling for "${show.title}" as it's already started.`);
                }
            });
        }
    );
}

// Function to schedule reminders and save new shows to the database
async function scheduleShowReminders(discordClient) {
    const scheduleData = await fetchTheaterSchedule();

    if (!scheduleData || scheduleData.length === 0) {
        console.log('No schedule data available.');
        return;
    }

    // Save upcoming shows to the database if not already saved
    scheduleData.forEach(show => {
        db.get(`SELECT id FROM schedule WHERE title = ? AND start_at = ?`, [show.title, show.start_at], (err, row) => {
            if (err) {
                console.error('Error querying database:', err.message);
            } else if (!row) {
                saveShowToDatabase(show.title, show.start_at);
            }
        });
    });

    // Check and send reminders for today's shows
    sendTodayShowReminders(discordClient);
}

module.exports = { scheduleShowReminders };
