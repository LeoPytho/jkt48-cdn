const { ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const axios = require('axios');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

// Plan details with pricing and limits
const PLANS = {
  '1_week': {
    name: '1 Minggu',
    limit: 50,
    price: 13,
  },
  '1_month': {
    name: '1 Bulan',
    limit: 150,
    price: 4,
  },
  '3_months': {
    name: '3 Bulan',
    limit: 200,
    price: 5,
  },
  'permanent': {
    name: 'Permanen',
    limit: 'Unlimited',
    price: 10,
  }
};

// Function to generate a random API key
function generateRandomApiKey() {
  // Randomly choose between 'V' and 'D'
  const prefix = Math.random() < 0.5 ? 'V' : 'D';
  
  // Generate a random string of 15 characters (capital letters and numbers)
  const randomString = crypto.randomBytes(10).toString('hex')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, () => Math.floor(Math.random() * 36).toString(36).toUpperCase());
  
  return `${prefix}${randomString}`;
}

// Function to generate a random fee between 3-100
function generateRandomFee(baseAmount) {
  const baseFee = Math.floor(Math.random() * 98) + 3; // 3-100
  const scaleFactor = baseAmount / 1000; // Scale fee with base amount
  return Math.floor(baseFee * scaleFactor);
}

// Function to check payment status
async function checkPaymentStatus(totalAmount) {
  try {
    console.log("Memeriksa status pembayaran...");

    const statusApiUrl = 'https://api.jkt48connect.my.id/api/orkut/cekstatus';
    const statusResponse = await axios.get(statusApiUrl, {
      params: {
        merchant: 'OK1453563',
        keyorkut: '584312217038625421453563OKCT6AF928C85E124621785168CD18A9B693',
        amount: totalAmount, // Using total amount including fee
        api_key: 'JKTCONNECT'
      }
    });

    const paymentStatus = statusResponse.data;
    console.log("Hasil API cekstatus:", paymentStatus);

    // Improved payment verification logic
    const isPaymentValid = paymentStatus.status === 'success' && 
      paymentStatus.data && 
      paymentStatus.data.length > 0 && 
      paymentStatus.data[0].amount === totalAmount.toString();

    return {
      isPaymentValid,
      paymentDetails: isPaymentValid ? paymentStatus.data[0] : null
    };
  } catch (error) {
    console.error('Error checking payment status:', error);
    return {
      isPaymentValid: false,
      paymentDetails: null,
      error: error.message
    };
  }
}

// 📌 Fungsi untuk mengirim email ke support
async function sendEmailToSupport(planName, totalAmount, userId, apiKey) {
  return new Promise((resolve, reject) => {
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false, // Use TLS
      auth: {
        user: process.env.EMAIL_USER || 'jkt48connect@gmail.com',
        pass: process.env.EMAIL_PASS || 'yffkdsunrxpoigvb'
      }
    });

    const mailOptions = {
      from: 'jkt48connect@gmail.com',
      to: 'support@jkt48connect.my.id',
      subject: 'Permintaan APIKey Baru',
      text: `Ada permintaan APIKey baru:

- **Plan:** ${planName}
- **Total Pembayaran:** Rp${totalAmount}
- **User ID:** ${userId}
- **APIKey:** ${apiKey}

Silakan konfirmasi dan kirim APIKey sesuai permintaan ini.
`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("❌ Gagal mengirim email ke support:", error);
        reject(error);
      } else {
        console.log("📧 Email berhasil dikirim ke support!");
        resolve(info);
      }
    });
  });
}

// Fungsi untuk mengirim APIKey ke user via Direct Message
async function sendApiKeyToUser(interaction, apiKey, planName, totalAmount) {
  try {
    const apiKeyEmbed = new EmbedBuilder()
      .setTitle('🔑 APIKey Berhasil Diterbitkan')
      .setColor(0x4BB543) // Green color
      .setDescription('Berikut adalah detail APIKey yang telah Anda beli:')
      .addFields(
        { name: 'APIKey', value: `\`${apiKey}\``, inline: false },
        { name: 'Plan', value: planName, inline: true },
        { name: 'Total Pembayaran', value: `Rp${totalAmount}`, inline: true }
      )
      .setFooter({ text: 'Simpan APIKey Anda dengan aman!' });

    await interaction.user.send({ embeds: [apiKeyEmbed] });
    return true;
  } catch (error) {
    console.error('Gagal mengirim APIKey via DM:', error);
    return false;
  }
}

// Fungsi utama untuk proses pembelian APIKey
async function buyApiKeyHelper(interaction) {
  try {
    // Create select menu for plan selection
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_apikey_plan')
      .setPlaceholder('Pilih Plan APIKey')
      .addOptions(
        Object.entries(PLANS).map(([key, plan]) => ({
          label: `${plan.name}`,
          description: `Limit: ${plan.limit} | Harga: Rp${plan.price}`,
          value: key
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    // Reply with plan selection menu
    const response = await interaction.reply({
      content: 'Pilih salah satu plan APIKey:',
      components: [row],
      ephemeral: true
    });

    // Collector for plan selection
    const planCollector = response.createMessageComponentCollector({
      componentType: 3, // StringSelect
      time: 60000
    });

    planCollector.on('collect', async (planInteraction) => {
      const selectedPlanKey = planInteraction.values[0];
      const selectedPlan = PLANS[selectedPlanKey];

      const fee = generateRandomFee(selectedPlan.price);
      const totalAmount = selectedPlan.price + fee;

      console.log(`Membuat pembayaran untuk plan: ${selectedPlan.name}`);
      console.log(`Total amount: Rp${totalAmount}, Fee: Rp${fee}`);

      try {
        const paymentApiUrl = `https://api.jkt48connect.my.id/api/orkut/createpayment?amount=${totalAmount}&qris=00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214149391352933240303UMI51440014ID.CO.QRIS.WWW0215ID20233077025890303UMI5204541153033605802ID5919VALZSTORE%20OK14535636006SERANG61054211162070703A016304DCD2&api_key=JKTCONNECT`;

        const paymentResponse = await axios.get(paymentApiUrl);
        const paymentResult = paymentResponse.data;

        if (!paymentResult || !paymentResult.qrImageUrl) {
          return planInteraction.update({
            content: '❌ Terjadi kesalahan saat membuat pembayaran. Silakan coba lagi.',
            components: []
          });
        }

        const paymentEmbed = new EmbedBuilder()
          .setTitle('Konfirmasi Pembayaran APIKey')
          .setDescription(`Anda memilih plan: ${selectedPlan.name}\n\nDetail Pembayaran:`)
          .addFields(
            { name: 'Harga Dasar', value: `Rp${selectedPlan.price}`, inline: true },
            { name: 'Biaya Admin', value: `Rp${fee}`, inline: true },
            { name: 'Total Pembayaran', value: `Rp${totalAmount}`, inline: true },
            { name: 'Limit', value: `${selectedPlan.limit}`, inline: true }
          )
          .setImage(paymentResult.qrImageUrl);

        const checkStatusButton = new ButtonBuilder()
          .setCustomId(`check_payment_status_${selectedPlanKey}_${totalAmount}`)
          .setLabel('Cek Status Pembayaran')
          .setStyle(ButtonStyle.Primary);

        const buttonRow = new ActionRowBuilder().addComponents(checkStatusButton);

        // Update the interaction with payment details and status check button
        await planInteraction.update({
          embeds: [paymentEmbed],
          components: [buttonRow],
          ephemeral: true
        });

        // Create a separate collector specifically for this interaction's status check button
        const filter = (buttonInteraction) => 
          buttonInteraction.customId === `check_payment_status_${selectedPlanKey}_${totalAmount}` &&
          buttonInteraction.user.id === interaction.user.id;

        const collector = interaction.channel.createMessageComponentCollector({
          filter,
          time: 300000
        });

        collector.on('collect', async (statusInteraction) => {
          try {
            const { isPaymentValid, paymentDetails } = await checkPaymentStatus(totalAmount);

            if (isPaymentValid) {
              console.log("Pembayaran berhasil! Pembayaran detail:", paymentDetails);

              // Generate new random API key
              const newApiKey = generateRandomApiKey();

              try {
                // Send email to support
                await sendEmailToSupport(
                  selectedPlan.name, 
                  totalAmount, 
                  statusInteraction.user.id, 
                  newApiKey
                );

                // Send APIKey to user via DM
                const dmSent = await sendApiKeyToUser(
                  statusInteraction, 
                  newApiKey, 
                  selectedPlan.name, 
                  totalAmount
                );

                if (dmSent) {
                  await statusInteraction.reply({
                    content: `✅ Pembayaran Berhasil! APIKey telah dikirim ke Direct Message Anda.`,
                    ephemeral: true
                  });
                } else {
                  await statusInteraction.reply({
                    content: `✅ Pembayaran Berhasil! APIKey: \`${newApiKey}\`\n\n⚠️ Tidak dapat mengirim DM. Harap periksa pengaturan privasi Discord Anda.`,
                    ephemeral: true
                  });
                }
              } catch (emailError) {
                // If email or DM sending fails
                await statusInteraction.reply({
                  content: `✅ Pembayaran Berhasil! Namun terjadi kesalahan saat mengirim APIKey. Silakan hubungi support.`,
                  ephemeral: true
                });
              }
            } else {
              console.warn("Pembayaran belum terverifikasi!");
              await statusInteraction.reply({
                content: '❌ Pembayaran Belum Terverifikasi. Silakan coba lagi.',
                ephemeral: true
              });
            }
          } catch (error) {
            console.error('Error checking payment status:', error);
            await statusInteraction.reply({
              content: '❌ Terjadi kesalahan saat memeriksa status pembayaran.',
              ephemeral: true
            });
          }
        });

      } catch (error) {
        console.error("Error saat memanggil API createpayment:", error);
        await planInteraction.update({
          content: '❌ Terjadi kesalahan dalam proses pembayaran.',
          components: []
        });
      }
    });

  } catch (error) {
    console.error('Error in buyApiKeyHelper:', error);
    await interaction.reply({
      content: 'Terjadi kesalahan dalam proses pembelian APIKey.',
      ephemeral: true
    });
  }
}

module.exports = {
  buyApiKeyHelper,
  checkPaymentStatus
};