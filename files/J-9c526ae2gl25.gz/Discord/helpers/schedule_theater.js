const { EmbedBuilder } = require('jkt48connect-discord');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const { getTheater, getTheaterDetail } = require('@jkt48connect/cli');

const dbDirectory = path.join(__dirname, '../Database');
const dbPath = path.join(dbDirectory, 'theater_notifications.db');

if (!fs.existsSync(dbDirectory)) {
    fs.mkdirSync(dbDirectory, { recursive: true });
}

const db = new sqlite3.Database(dbPath);

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            theater_id TEXT NOT NULL
        )
    `);
});

function isNotificationSent(date, theaterId) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT * FROM notifications WHERE date = ? AND theater_id = ?`, 
            [date, theaterId], 
            (err, row) => {
                if (err) {
                    return reject(err);
                }
                resolve(!!row);
            }
        );
    });
}

function saveNotification(date, theaterId) {
    return new Promise((resolve, reject) => {
        db.run(`INSERT INTO notifications (date, theater_id) VALUES (?, ?)`, 
            [date, theaterId], 
            (err) => {
                if (err) {
                    console.error('Error saving notification:', err);
                    return reject(err);
                }
                console.log(`Notification saved: ${date} - Theater ID: ${theaterId}`);
                resolve();
            }
        );
    });
}

function getChannelID() {
    try {
        const data = fs.readFileSync('./Discord/channel/jadwal-notif.json', 'utf8');
        const jsonData = JSON.parse(data);
        return jsonData.channel_id;
    } catch (err) {
        console.error('Error reading channel ID from JSON:', err);
        return null;
    }
}

async function fetchTheaterDataForToday() {
    try {
        const theaterData = await getTheater(global.jkt48connect);
        const today = new Date().toISOString().split('T')[0];
        const todayTheater = theaterData.theater.find(show => show.date.split('T')[0] === today);

        if (todayTheater) {
            const theaterDetail = await getTheaterDetail(global.jkt48connect, todayTheater.id);
            return {
                ...theaterDetail.shows[0],
                id: todayTheater.id, // Include the theater ID for unique identification
                fullTheaterData: theaterData // Include full theater data for additional info
            };
        }
        return null;
    } catch (error) {
        console.error('Error fetching theater data:', error);
        return null;
    }
}

// Format Currency (for ticket prices)
function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

// Get day name in Indonesian
function getDayName(date) {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    return days[date.getDay()];
}

// Flag to prevent concurrent execution
let isProcessing = false;

async function sendTheaterNotification(discordClient) {
    // Prevent concurrent executions
    if (isProcessing) {
        console.log('Previous theater notification process still running, skipping...');
        return;
    }

    try {
        isProcessing = true;
        
        const theaterData = await fetchTheaterDataForToday();
        if (!theaterData) {
            console.log('No theater data available for today.');
            isProcessing = false;
            return;
        }

        const theaterChannelID = getChannelID();
        if (!theaterChannelID) {
            console.log('Channel ID not found.');
            isProcessing = false;
            return;
        }

        const theaterChannel = discordClient.channels.cache.get(theaterChannelID);
        if (!theaterChannel) {
            console.log(`Channel with ID ${theaterChannelID} not found.`);
            isProcessing = false;
            return;
        }

        const today = new Date().toISOString().split('T')[0];
        
        // Check if notification for this specific theater has been sent today
        const notificationSent = await isNotificationSent(today, theaterData.id);
        if (notificationSent) {
            console.log(`Theater notification already sent today for theater ID: ${theaterData.id}`);
            isProcessing = false;
            return;
        }

        const showDate = new Date(theaterData.date);
        const dayName = getDayName(showDate);
        const formattedDate = `${dayName}, ${showDate.getDate()} ${showDate.toLocaleString('id-ID', { month: 'long' })} ${showDate.getFullYear()}`;
        const formattedTime = showDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' });
        
        // Format members list with generation and team info if available
        const formattedMembers = theaterData.members && theaterData.members.length > 0
            ? theaterData.members.map(member => {
                const teamInfo = member.team ? ` (Team ${member.team})` : '';
                const genInfo = member.generation ? ` - Gen ${member.generation}` : '';
                return `${member.name}${teamInfo}${genInfo}`;
            }).join('\n')
            : 'Belum ada anggota yang diumumkan';
        
        // Format seitansai members with more detail
        const formattedSeitansai = theaterData.seitansai && theaterData.seitansai.length > 0
            ? theaterData.seitansai.map(member => {
                const teamInfo = member.team ? ` (Team ${member.team})` : '';
                const genInfo = member.generation ? ` - Gen ${member.generation}` : '';
                return `${member.name}${teamInfo}${genInfo}`;
            }).join('\n')
            : 'Tidak ada yang ulang tahun hari ini';

        // Get ticket info if available
        let ticketInfo = '';
        if (theaterData.ticket_types && theaterData.ticket_types.length > 0) {
            ticketInfo = theaterData.ticket_types.map(ticket => 
                `${ticket.name}: ${formatCurrency(ticket.price)}`
            ).join('\n');
        } else {
            ticketInfo = 'Informasi tiket belum tersedia';
        }

        // Additional setlist information
        const setlistInfo = theaterData.setlist?.description || 'Tidak ada deskripsi setlist';
        
        // Create rich embed
        const embed = new EmbedBuilder()
            .setColor('#FF69B4') // Pink color for JKT48
            .setTitle(`🎭 JKT48 Theater Show Today: ${theaterData.setlist.title}`)
            .setDescription(
                `Halo JKT48 Fans! Hari ini akan ada pertunjukan theater JKT48. Berikut adalah informasi lengkapnya:`
            )
            .addFields(
                { 
                    name: '📅 Informasi Pertunjukan', 
                    value: `\`\`\`🎪 Setlist: ${theaterData.setlist.title}\n🗓️ Tanggal: ${formattedDate}\n⏰ Waktu Mulai: ${formattedTime} WIB\n📍 Lokasi: JKT48 Theater, Lantai 4 fX Sudirman, Jakarta\`\`\``
                },
                { 
                    name: '💰 Informasi Tiket', 
                    value: `\`\`\`${ticketInfo}\`\`\`` 
                },
                { 
                    name: '💫 Tentang Setlist', 
                    value: `\`\`\`${setlistInfo.substring(0, 1000)}\`\`\`` 
                },
                { 
                    name: '🎂 Member Seitansai', 
                    value: `\`\`\`${formattedSeitansai}\`\`\`` 
                },
                { 
                    name: '🎤 Line-up Member', 
                    value: `\`\`\`${formattedMembers}\`\`\`` 
                },
                { 
                    name: '⚠️ Catatan Penting', 
                    value: "```• Line-up member dapat berubah sewaktu-waktu tanpa pemberitahuan\n• Pastikan datang 30 menit sebelum pertunjukan dimulai\n• Dilarang merekam selama pertunjukan berlangsung\n• Perhatikan peraturan Theater JKT48 untuk kenyamanan bersama```" 
                }
            )
            .setAuthor({ 
                name: 'JKT48 Theater Bot', 
                iconURL: 'https://jkt48.com/images/logo.png',
                url: 'https://jkt48.com/theater/schedule'
            })
            .setFooter({ 
                text: `Powered by JKT48Connect | Theater ID: ${theaterData.id}` 
            })
            .setTimestamp();
        
        // Add setlist banner if available
        if (theaterData.setlist.banner) {
            embed.setImage(theaterData.setlist.banner);
        }

        // Add thumbnail
        embed.setThumbnail('https://jkt48.com/images/theater.jpg');

        try {
            // Send the notification and save in one transaction
            await theaterChannel.send({ 
                content: `@everyone Pengumuman Theater JKT48 hari ini, ${formattedDate}!`,
                embeds: [embed] 
            });
            await saveNotification(today, theaterData.id);
            console.log(`Theater notification sent for show ID ${theaterData.id} on ${today}`);
        } catch (error) {
            console.error('Error sending theater notification:', error);
        }

    } catch (error) {
        console.error('Error in theater notification process:', error);
    } finally {
        isProcessing = false;
    }
}

function scheduleDailyTheaterNotification(discordClient) {
    // Run once at startup to check if we need to send a notification now
    setTimeout(() => {
        sendTheaterNotification(discordClient);
    }, 5000); // Wait 5 seconds after startup before first check

    // Now schedule the daily 9 AM check
    const now = new Date();
    const jakartaTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));

    const targetTime = new Date(jakartaTime);
    targetTime.setHours(9, 0, 0, 0);

    // If it's already past 9 AM, schedule for tomorrow
    if (jakartaTime >= targetTime) {
        targetTime.setDate(targetTime.getDate() + 1);
    }

    const delayUntilTarget = targetTime - jakartaTime;
    
    console.log(`Theater notification scheduled for ${targetTime.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })}`);
    
    // Schedule the first 9 AM notification
    setTimeout(() => {
        sendTheaterNotification(discordClient);
        
        // Then set up the daily interval
        setInterval(() => {
            sendTheaterNotification(discordClient);
        }, 24 * 60 * 60 * 1000);
    }, delayUntilTarget);
}

module.exports = {
    sendTheaterNotification,
    scheduleDailyTheaterNotification
};