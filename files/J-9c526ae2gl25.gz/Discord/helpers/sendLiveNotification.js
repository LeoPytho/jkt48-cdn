
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { getLive } = require('jkt48connect-cli');

// Improved file paths with proper directories
const dataDirectory = path.join(__dirname, '../Database');
const liveDataPath = path.join(dataDirectory, 'live_notifications.json');
const channelConfigPath = './Discord/channel/idn-notif.json';

const apiKey = global.jkt48connect;

// Ensure data directory exists
if (!fs.existsSync(dataDirectory)) {
    fs.mkdirSync(dataDirectory, { recursive: true });
}

// Enhanced data structure to store more metadata about sent notifications
function saveLiveData(liveData) {
    try {
        fs.writeFileSync(liveDataPath, JSON.stringify(liveData, null, 2), 'utf8');
        console.log(`📝 Live data saved with ${liveData.length} entries`);
    } catch (err) {
        console.error('❌ Error saving live data:', err);
    }
}

function getSavedLiveData() {
    if (fs.existsSync(liveDataPath)) {
        try {
            const data = JSON.parse(fs.readFileSync(liveDataPath, 'utf8')) || [];
            console.log(`📚 Loaded ${data.length} previous live notifications`);
            
            // Clean up old entries (older than 7 days)
            const now = Date.now();
            const sevenDaysAgo = now - (7 * 24 * 60 * 60 * 1000);
            
            const filteredData = data.filter(entry => {
                // If it's an object with timestamp, check the timestamp
                if (typeof entry === 'object' && entry.timestamp) {
                    return entry.timestamp > sevenDaysAgo;
                }
                // If it's just an ID (old format), keep it
                return true;
            });
            
            if (filteredData.length !== data.length) {
                console.log(`🧹 Cleaned up ${data.length - filteredData.length} old notification entries`);
                saveLiveData(filteredData);
            }
            
            return filteredData;
        } catch (err) {
            console.error('❌ Error parsing saved live data:', err);
            return [];
        }
    }
    console.log('📋 No existing live data found, creating new database');
    return [];
}

function formatWIBDate(isoString) {
    if (!isoString) return 'Tidak tersedia';

    const date = new Date(isoString);
    // No need to manually adjust for WIB when using timeZone in toLocaleString
    
    return date.toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        hour12: false,
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
}

// Helper function to encode the name for URL
function encodeForUrl(name) {
    if (!name) return '';
    return encodeURIComponent(name.trim());
}

// Flag to prevent concurrent execution
let isProcessing = false;

async function sendLiveNotification(discordClient) {
    // Prevent concurrent executions
    if (isProcessing) {
        console.log('⚠️ Previous live notification process still running, skipping...');
        return;
    }
    
    try {
        isProcessing = true;
        console.log('🔄 Fetching live data from JKT48Connect...');
        
        const liveDataList = await getLive(apiKey);
        console.log(`📊 Found ${liveDataList.length} active live streams`);
        
        let savedLiveData = getSavedLiveData();
        
        // Convert old format to new format if needed
        savedLiveData = savedLiveData.map(entry => {
            if (typeof entry === 'string') {
                return { id: entry, timestamp: Date.now() };
            }
            return entry;
        });

        let channelIds;
        try {
            channelIds = JSON.parse(fs.readFileSync(channelConfigPath, 'utf8'));
            console.log(`📢 Will send notifications to ${channelIds.length} channels`);
        } catch (err) {
            console.error('❌ Error reading channel IDs from JSON file:', err);
            isProcessing = false;
            return;
        }

        // Store newly sent notifications
        const newNotifications = [];

        for (const liveData of liveDataList) {
            // Generate a unique ID with more specific identifiers
            let uniqueID;
            if (liveData.type === 'idn') {
                uniqueID = `idn_${liveData.room_id || liveData.slug}_${liveData.started_at || Date.now()}`;
            } else if (liveData.type === 'showroom') {
                uniqueID = `showroom_${liveData.room_id}_${liveData.started_at || Date.now()}`;
            } else if (liveData.type === 'youtube') {
                uniqueID = `youtube_${liveData.videoId || liveData.url}_${liveData.publishedAt || Date.now()}`;
            } else {
                uniqueID = `unknown_${liveData.url || liveData.room_id || Date.now()}`;
            }

            // Check if this live has already been notified
            if (savedLiveData.some(entry => entry.id === uniqueID)) {
                console.log(`⏭️ Notification already sent for: ${liveData.name || liveData.channelTitle} (${liveData.type})`);
                continue;
            }

            console.log(`🆕 Processing new live: ${liveData.name || liveData.channelTitle} (${liveData.type})`);

            let platformName;
            let platformUrl;
            let jkt48connectUrl;
            let embedTitle;
            let embedDescription;
            let thumbnailUrl;

            // Get the member name for JKT48Connect URL
            const memberName = liveData.name || liveData.channelTitle || '';
            
            // Create the JKT48Connect URL with encoded name parameter
            jkt48connectUrl = `https://www.jkt48connect.web.id/live?name=${encodeForUrl(memberName)}`;

            // Determine platform & data
            switch (liveData.type) {
                case 'idn':
                    platformName = 'IDN APP';
                    platformUrl = `https://www.idn.app/${liveData.url_key}/live/${liveData.slug}`;
                    break;
                case 'showroom':
                    platformName = 'Showroom';
                    platformUrl = `https://www.showroom-live.com/r/${liveData.url_key}`;
                    break;
                case 'youtube':
                    platformName = 'YouTube';
                    platformUrl = liveData.url;
                    break;
                default:
                    platformName = 'Platform Tidak Diketahui';
                    platformUrl = '#';
            }

            // Create embed based on platform type
            if (liveData.type === 'idn' || liveData.type === 'showroom') {
                embedTitle = `✨ ${memberName} Sedang Live di ${platformName}!`;
                embedDescription = `
📌 **Judul Live:**  
\`${liveData.title || liveData.slug?.replace(/-/g, ' ') || 'Tidak tersedia'}\`

🕒 **Jam Tayang:**  
\`${formatWIBDate(liveData.started_at)}\`

👥 **Jumlah Penonton:**  
\`${liveData.viewers?.num || '0'} penonton\`

🎤 **Dukung ${memberName} di siaran kali ini!**  
Ayo berikan dukungan terbaikmu dan temukan informasi lebih lengkap hanya di [JKT48Connect](https://www.jkt48connect.web.id)!

🔗 **Link Menonton:**  
- [${platformName}](${platformUrl})  
- [JKT48Connect Platform](${jkt48connectUrl})

🎥 **Jangan lewatkan siaran seru ini dan ajak teman-temanmu menonton bersama!**
                `;
                thumbnailUrl = liveData.img || liveData.img_alt || liveData.thumbnail;
            } else if (liveData.type === 'youtube') {
                embedTitle = `📢 **${memberName} Sedang Live di YouTube!**`;
                embedDescription = `
🎬 **Judul:**  
\`${liveData.title}\`

👁️ **Penonton:**  
\`${liveData.viewCount || '0'} penonton\`

🕒 **Mulai Tayang:**  
\`${formatWIBDate(liveData.publishedAt || liveData.started_at)}\`

📃 **Deskripsi:**  
${liveData.description?.substring(0, 200) || 'Tidak ada deskripsi'}${liveData.description?.length > 200 ? '...' : ''}

🔴 **Status:** Live Now

🔗 **Tonton sekarang!**
`;
                thumbnailUrl = liveData.thumbnails?.high?.url || liveData.thumbnails?.medium?.url || liveData.thumbnails?.default?.url || liveData.thumbnail;
            } else {
                embedTitle = '🎥 Live Streaming Tidak Diketahui';
                embedDescription = 'Informasi tidak tersedia.';
                thumbnailUrl = null;
            }

            // Create Discord embed
            const embed = new EmbedBuilder()
                .setTitle(embedTitle)
                .setDescription(embedDescription)
                .setColor(liveData.type === 'idn' ? '#FF1493' : liveData.type === 'showroom' ? '#1E90FF' : '#FF0000')
                .setImage(thumbnailUrl)
                .setFooter({
                    text: `Powered by JKT48Connect • ${platformName} • ID: ${uniqueID.substring(0, 20)}...`,
                })
                .setTimestamp();

            // Create interactive buttons
            const buttons = new ActionRowBuilder();

            // Add JKT48Connect button
            buttons.addComponents(
                new ButtonBuilder()
                    .setLabel('Tonton di JKT48Connect')
                    .setStyle(ButtonStyle.Link)
                    .setURL(jkt48connectUrl)
            );

            // Add platform button
            buttons.addComponents(
                new ButtonBuilder()
                    .setLabel(`Tonton di ${platformName}`)
                    .setStyle(ButtonStyle.Link)
                    .setURL(platformUrl)
            );

            // Add a "View All Lives" button
            buttons.addComponents(
                new ButtonBuilder()
                    .setLabel('Lihat Semua Live')
                    .setStyle(ButtonStyle.Link)
                    .setURL('https://www.jkt48connect.web.id/stream')
            );

            // Send notification to each channel
            let notificationSent = false;
            
            for (const channelId of channelIds) {
                const channel = discordClient.channels.cache.get(channelId);
                if (!channel) {
                    console.log(`⚠️ Channel dengan ID ${channelId} tidak ditemukan.`);
                    continue;
                }

                try {
                    await channel.send({ 
                        content: `🔴 **LIVE ALERT!** ${memberName} sedang live sekarang!`,
                        embeds: [embed], 
                        components: [buttons] 
                    });
                    
                    console.log(`✅ Notification sent for: ${memberName} (${liveData.type}) to channel ${channelId}`);
                    notificationSent = true;
                } catch (err) {
                    console.error(`❌ Error sending notification for ${memberName} to channel ${channelId}:`, err);
                }
            }

            // Only mark as sent if successfully sent to at least one channel
            if (notificationSent) {
                newNotifications.push({
                    id: uniqueID,
                    timestamp: Date.now(),
                    platform: liveData.type,
                    memberName: memberName,
                    title: liveData.title || liveData.slug
                });
            }
        }

        // Update saved notifications with new ones
        if (newNotifications.length > 0) {
            const updatedSavedLiveData = [...savedLiveData, ...newNotifications];
            
            // Limit database size to prevent it from growing too large
            // Keep only the last 100 notifications
            const trimmedData = updatedSavedLiveData.slice(-100);
            
            saveLiveData(trimmedData);
            console.log(`✨ Added ${newNotifications.length} new notifications to database`);
        }
        
    } catch (err) {
        console.error('❌ Error in live notification process:', err);
    } finally {
        isProcessing = false;
    }
}

// Function to check for live streams at regular intervals
function startLiveCheckInterval(discordClient, intervalMinutes = 2) {
    console.log(`🔄 Starting live stream check every ${intervalMinutes} minutes`);
    
    // Run immediately on startup
    setTimeout(() => {
        sendLiveNotification(discordClient);
    }, 3000);
    
    // Then run at the specified interval
    const intervalMillis = intervalMinutes * 60 * 1000;
    setInterval(() => {
        sendLiveNotification(discordClient);
    }, intervalMillis);
}

module.exports = sendLiveNotification;
