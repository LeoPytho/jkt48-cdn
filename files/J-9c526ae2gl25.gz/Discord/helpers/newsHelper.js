const { getNews, getNewsDetail } = require('jkt48connect-cli');
const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('jkt48connect-discord');

// Fungsi untuk memproses konten HTML menjadi teks
function parseHTMLContent(content) {
    return content
        .replace(/&nbsp;/g, ' ') // Mengganti &nbsp; dengan spasi biasa
        .replace(/&bull;/g, '•') // Mengganti &bull; dengan bullet
        .replace(/&ldquo;/g, '“') // Mengganti &ldquo; dengan tanda kutip buka
        .replace(/&rdquo;/g, '”') // Mengganti &rdquo; dengan tanda kutip tutup
        .replace(/&amp;/g, '&') // Mengganti &amp; dengan simbol &
        .replace(/<br\s*\/?>/gi, '\n') // Mengganti <br> dengan baris baru
        .replace(/<[^>]+>/g, '') // Menghapus tag HTML lainnya
        .trim();
}

// Fungsi untuk mengambil daftar berita dari API
async function fetchNewsFromAPI() {
    try {
        const response = await getNews('JKTCONNECT'); // API key
        const newsList = response.news;

        if (newsList && newsList.length > 0) {
            return newsList.map((news) => ({
                id: news.id,
                title: news.title,
            }));
        } else {
            console.log('Tidak ada berita yang tersedia.');
            return [];
        }
    } catch (error) {
        console.error('Error fetching news from API:', error);
        return [];
    }
}

// Fungsi untuk mengambil detail berita berdasarkan ID
async function fetchNewsDetail(newsId) {
    try {
        const response = await getNewsDetail('JKTCONNECT', newsId); // API key dan ID berita
        const { content, date, label, title } = response;

        // Format tanggal
        const formattedDate = new Date(date).toLocaleString('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });

        // Parsing konten HTML ke teks
        const parsedContent = parseHTMLContent(content);

        // Menambahkan domain pada label jika ada
        const thumbnailUrl = label ? `https://jkt48.com${label}` : null;

        return { title, parsedContent, formattedDate, thumbnailUrl };
    } catch (error) {
        console.error(`Error fetching news detail for ID ${newsId}:`, error);
        return null;
    }
}

// Helper untuk mengirim daftar berita sebagai menu pilihan
async function sendNewsList(interaction) {
    const newsList = await fetchNewsFromAPI();

    if (newsList.length === 0) {
        await interaction.reply('Tidak ada berita yang tersedia saat ini.');
        return;
    }

    const options = newsList.map((news) => ({
        label: news.title.length > 100 ? `${news.title.slice(0, 97)}...` : news.title,
        description: `ID Berita: ${news.id}`,
        value: news.id,
    }));

    const menu = new StringSelectMenuBuilder()
        .setCustomId('select-news')
        .setPlaceholder('Pilih berita untuk melihat detailnya')
        .addOptions(options);

    const row = new ActionRowBuilder().addComponents(menu);

    await interaction.reply({
        content: 'Berikut daftar berita terbaru:',
        components: [row],
    });
}

// Helper untuk mengirim detail berita berdasarkan pilihan pengguna
async function sendNewsDetail(interaction, newsId) {
    const detail = await fetchNewsDetail(newsId);

    if (!detail) {
        await interaction.reply('Gagal mengambil detail berita. Silakan coba lagi.');
        return;
    }

    const { title, parsedContent, formattedDate, thumbnailUrl } = detail;

    const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(`**Tanggal:** ${formattedDate}\n\n${parsedContent}`)
        .setURL(`https://jkt48.com/news/detail/id/${newsId}?lang=id`)
        .setColor('#FFD700')
        .setFooter({ text: 'Powered by JKT48Connect' });

    if (thumbnailUrl) embed.setThumbnail(thumbnailUrl);

    await interaction.update({
        content: null,
        embeds: [embed],
        components: [],
    });
}

module.exports = {
    sendNewsList,
    sendNewsDetail,
};
