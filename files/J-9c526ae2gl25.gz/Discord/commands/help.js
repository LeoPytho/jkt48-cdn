const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Lihat daftar perintah bot JKT48Connect dan izin yang diperlukan',
    async execute(interaction) {
        const commandsList = [
            { name: '/setshowchannel', description: 'Set the channel where live notifications will be sent' },
            { name: '/setlivechannel', description: 'Set the channel where live notifications will be sent' },
            { name: '/setnewschannel', description: 'Set the channel where news notifications will be sent' },
            { name: '/donasi', description: 'Donasi ke bot via WhatsApp' },
        ];

        const requiredPermissions = [
            { name: 'SEND_MESSAGES', description: 'Mengizinkan bot mengirim pesan di channel.' },
            { name: 'EMBED_LINKS', description: 'Memungkinkan bot mengirim embed messages.' },
            { name: 'READ_MESSAGE_HISTORY', description: 'Memungkinkan bot membaca riwayat pesan untuk interaksi yang lebih baik.' },
            { name: 'USE_EXTERNAL_EMOJIS', description: 'Memungkinkan bot menggunakan emoji dari server lain.' },
        ];

        const commandListString = commandsList
            .map(cmd => `**${cmd.name}** - ${cmd.description}`)
            .join('\n');

        const permissionsString = requiredPermissions
            .map(perm => `**${perm.name}** - ${perm.description}`)
            .join('\n');

        // Format waktu WIB
        const now = new Date();
        now.setHours(now.getHours() + 7); // Konversi ke WIB
        const formattedDate = now.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

        // Embed daftar command
        const commandEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📌 Daftar Perintah JKT48Connect')
            .setDescription(commandListString)
            .setImage('https://files.catbox.moe/dp8jq8.png')
            .setFooter({ text: `JKT48Connect || Valzy • ${formattedDate} WIB`, iconURL: 'https://files.catbox.moe/bcjk2g.jpg' });

        // Embed daftar permission
        const permissionEmbed = new EmbedBuilder()
            .setColor('#ff9900')
            .setTitle('⚙️ Izin yang Diperlukan')
            .setDescription(permissionsString)
            .setImage('https://files.catbox.moe/dp8jq8.png')
            .setFooter({ text: `JKT48Connect || Valzy • ${formattedDate} WIB`, iconURL: 'https://files.catbox.moe/bcjk2g.jpg' });

        // Tombol navigasi & dashboard
        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('previous')
                    .setLabel('⬅ Previous')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true), // Disabled karena di halaman pertama
                new ButtonBuilder()
                    .setCustomId('next')
                    .setLabel('Next ➡')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setLabel('Dashboard')
                    .setStyle(ButtonStyle.Link)
                    .setURL('https://dash.jkt48connect.my.id')
            );

        const message = await interaction.reply({ embeds: [commandEmbed], components: [buttons], ephemeral: true });

        // Collector untuk menangani interaksi tombol
        const collector = message.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async (buttonInteraction) => {
            if (buttonInteraction.user.id !== interaction.user.id) return;

            if (buttonInteraction.customId === 'next') {
                await buttonInteraction.update({
                    embeds: [permissionEmbed],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId('previous')
                                    .setLabel('⬅ Previous')
                                    .setStyle(ButtonStyle.Primary),
                                new ButtonBuilder()
                                    .setCustomId('next')
                                    .setLabel('Next ➡')
                                    .setStyle(ButtonStyle.Secondary)
                                    .setDisabled(true), // Disabled karena di halaman terakhir
                                new ButtonBuilder()
                                    .setLabel('Dashboard')
                                    .setStyle(ButtonStyle.Link)
                                    .setURL('https://dash.jkt48connect.my.id')
                            )
                    ],
                });
            } else if (buttonInteraction.customId === 'previous') {
                await buttonInteraction.update({
                    embeds: [commandEmbed],
                    components: [buttons],
                });
            }
        });
    },
};
