const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'setshowchannel',
    description: 'Set the channel where live notifications will be sent',
    options: [
        {
            name: 'channel',
            type: 7, // Channel type
            description: 'Select the channel to send live notifications',
            required: true,
        }
    ],
    execute: async (interaction) => {
        const channel = interaction.options.getChannel('channel');
        
        // Define the path to the JSON file
        const jsonFilePath = path.join(__dirname, '../../Discord/channel/jadwal-notif.json');
        
        // Create the JSON object to store the channel ID
        const channelData = {
            channel_id: channel.id
        };

        // Write the channel ID to the JSON file
        try {
            // Check if the directory exists
            const dirPath = path.dirname(jsonFilePath);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
            }

            // Write the updated data to the file
            fs.writeFileSync(jsonFilePath, JSON.stringify(channelData, null, 2));
            console.log(`Channel ID ${channel.id} saved to ${jsonFilePath}`);
        } catch (error) {
            console.error('Error saving channel ID to file:', error);
            await interaction.reply('There was an error while saving the channel ID.');
            return;
        }

        // Reply with a confirmation message
        await interaction.reply(`Live notifications will now be sent to ${channel}.`);
    }
};
