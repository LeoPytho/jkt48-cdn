const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('jkt48connect-discord');
const fetch = require('node-fetch');

module.exports = {
    name: 'donasi',
    description: 'Donasi ke bot via WhatsApp',
    execute: async (interaction) => {
        try {
            // Fetch data from the API
            const response = await fetch('https://www.showroom-live.com/api/live/onlives');
            const data = await response.json();

            // Filter shows containing "JKT48" in "main_name" (case-insensitive)
            const jkt48Shows = data.onlives.flatMap((group) =>
                group.lives.filter((live) => live.main_name && live.main_name.toLowerCase().includes('jkt48'))
            );

            // Check if there are JKT48 shows available
            if (jkt48Shows.length === 0) {
                await interaction.reply('Tidak ada live show JKT48 saat ini.');
                return;
            }

            // Use a Set to store unique main names
            const uniqueShows = new Set();
            const filteredShows = jkt48Shows.filter(show => {
                if (uniqueShows.has(show.main_name)) {
                    return false; // Skip duplicate entries
                } else {
                    uniqueShows.add(show.main_name);
                    return true; // Include unique entries
                }
            });

            // Create a single embed with unique JKT48 show information
            const embed = new EmbedBuilder()
                .setTitle('Dukung Kami dengan Donasi!')
                .setDescription('Berikut adalah show yang mengandung JKT48. Silakan berdonasi melalui tombol di bawah ini untuk mendukung pengembangan bot ini.')
                .setColor('#FFD700')
                .setImage('https://8030.us.kg/file/jLufFTYSysde.jpg')
                .setFooter({ text: 'Terima kasih atas dukungannya!' });

            // Add each unique JKT48 show as a field in the embed
            filteredShows.forEach(show => {
                embed.addFields([
                    { name: 'Nama', value: show.main_name, inline: true },
                    { name: 'Pengikut', value: show.follower_num.toString(), inline: true },
                    { name: 'Penonton', value: show.view_num.toString(), inline: true },
                    { name: 'Tonton Live', value: `[Klik di sini](https://www.showroom-live.com/${show.room_url_key})`, inline: true }
                ]);
            });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Donasi via WhatsApp')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://wa.me/6285701479245')
                );

            await interaction.deferReply();
            await interaction.editReply({
                embeds: [embed],
                components: [row]
            });
        } catch (error) {
            console.error(error);
            await interaction.editReply('Maaf, terjadi kesalahan saat mengirimkan permintaan donasi.');
        }
    }
};
