const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'setlivechannel',
    description: 'Set the channel where live notifications will be sent',
    options: [
        {
            name: 'channel',
            type: 7, // Channel type
            description: 'Select the channel to send live notifications',
            required: true,
        }
    ],
    execute: async (interaction) => {
        const channel = interaction.options.getChannel('channel');
        
        // Path to the JSON file where the channel IDs will be saved
        const filePath = path.join(__dirname, '../../Discord/channel/idn-notif.json');

        try {
            // Ensure the directory exists
            const dirPath = path.dirname(filePath);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
            }

            // Read the existing data from the JSON file, if any
            let existingData = [];
            if (fs.existsSync(filePath)) {
                const fileData = fs.readFileSync(filePath, 'utf8');
                
                try {
                    existingData = JSON.parse(fileData);
                    // Ensure the existing data is an array, if it's not, reset it to an empty array
                    if (!Array.isArray(existingData)) {
                        existingData = [];
                    }
                } catch (err) {
                    console.error('Error parsing JSON, resetting data:', err);
                    existingData = [];
                }
            }

            // Add the new channel ID to the list if it doesn't already exist
            if (!existingData.includes(channel.id)) {
                existingData.push(channel.id);

                // Write the updated list back to the JSON file
                fs.writeFileSync(filePath, JSON.stringify(existingData, null, 2));
                
                await interaction.reply(`Live notifications will now be sent to ${channel}.`);
            } else {
                await interaction.reply(`${channel} is already set for live notifications.`);
            }
        } catch (error) {
            console.error('Error saving channel ID:', error);
            await interaction.reply('There was an error setting the live notification channel.');
        }
    }
};
