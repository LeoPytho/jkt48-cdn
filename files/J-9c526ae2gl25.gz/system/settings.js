let fs = require('fs') 
let chalk = require('chalk')
let moment = require('moment-timezone')


/*============== OWNER & USER SETTINGS ==============*/
global.mods = ['6285701479245'] // Moderator
global.prems = ['6285701479245'] // Premium Permanent
global.nomorbot = '62857014792453' // Nomot bot
global.nomorown = '6285701479245' // Real owner
global.creator = "6285701479245@s.whatsapp.net" // Nomot creator

global.nameown = 'Valzyy' // nama owner
global.namebot = 'ZENOVA-MD' // nama bot
global.owner = [
  [`${global.nomorown}`, 'ValzyyDev', true]
]


/*============== WATERMARK SETTINGS ==============*/
global.set = {
  bot: 'Zenova-MD',
  wm: `© Zenova-MD`,
  footer: 'sɪᴍᴘʟᴇ ᴡʜᴀᴛsᴀᴘᴘ ʙᴏᴛ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴠᴀʟᴢʏʏ',
  packname: 'Sticker By',
  author: 'Valzyy - Zenova-MD'
}
global.packname = 'Valzyy - Zenova-MD'
global.author = 'Valzyy'
global.wm = '© Zenova-MD'
global.wm3 = `Zenova-MD` 
global.newsletterid = "120363409207264021@newsletter" // id channel whatsapp
global.newslettername = "Zenova-MD x Adeline Wijaya" // nama channel whatsapp
global.wm2 = 'Zenova-MD.js'
global.titlebot = `${global.wm}`
global.danied = 'A K S E S  K A M U  D I  T O L A K!!'
global.done = '```Status Request :```' + ' `Succes`'
global.packname = 'Zenova-MD'
global.author = 'Valzyy'
global.wait = 'Wait a moment... '
const spack = fs.readFileSync("lib/exif.json")
const stickerpack = JSON.parse(spack)
if (stickerpack.spackname == '') {
  var sticker_name = 'Valzyy - Zenova-MD'
  var sticker_author = 'Valzyy'
} else {
  var sticker_name = 'Valzyy - Zenova-MD'
  var sticker_author = 'Valzyy'
}


/*============== MEDIA/FOTO SETTINGS ==============*/
global.thumb = 'https://telegra.ph/file/7b5416e93b4423845762d.jpg' // thumbnail 1
global.thumbnail = 'https://telegra.ph/file/7b5416e93b4423845762d.jpg' // thumbnail 2
global.contexticon = 'https://8030.us.kg/file/rm13zoKqYu2g.jpg' // side icon
global.menu = 'https://files.catbox.moe/1y16na.jpg' // Gambar menu
global.accessdenied = 'https://files.catbox.moe/a4bpur.jpg' // access denied image
global.largecontext = 'https://files.catbox.moe/62c6ty.jpg' // large icon
global.menuvid = 'https://files.catbox.moe/ft0831.mp4' // video di menu
global.menuaudio = "https://files.catbox.moe/er6tr4.mp3" // audio yang dikirim saat mengirim menu
global.welcomeaudio = 'https://files.catbox.moe/x9376p.mp3' // audio yang dikirim saat member bergabung di grup
global.goodbyeaudio = 'https://files.catbox.moe/x9376p.mp3' // audio yang dikirim saat member keluar dari grup


/*============== SOCIAL MEDIA SETTINGS ==============*/
global.gcbot = 'https://chat.whatsapp.com/KAMjs4qGQvTGBtuC3ti7VA' // link group
global.saluranbot = 'https://whatsapp.com/channel/0029VaEGq6MDeON8TGlwWN1Y' // link saluran
global.instagram = 'https://instagram.com/vncntmikael' //ig owner
global.email = 'support@jkt48connect.my.id' // ganti dengan email mu
global.github = 'https://github.com/Valzyys' // ganti dengan github mu
global.sgc = `${gcbot}` // ga usah di ubah
global.swa = 'https://wa.me/6285701479245' // nomor wa
global.sig = '-'
global.syt = '-' // Link youtube
global.sgh = '-'
global.swb = '-' // Link Discord
global.snh = '-' // Link nhentai


/*============== PAYMENT SETTINGS ==============*/
global.qris = 'https://telegra.ph/file/460ada2631894b3513e68.jpg' // link gambar qris (kosongkan jika tida ada)
global.pdana = '082152866630' // Nomor dana (kosongkan jika tida ada)
global.povo = '~Not Found~' //  Nomor ovo (kosongkan jika tida ada)
global.pgopay = '082152866630' // Nomor gopay (kosongkan jika tida ada)
global.pulsa = '082152866630'  // Nomor pulsa (kosongkan jika tida ada)
global.pulsa2 = '~Not Found~'  // Nomor pulsa kedua (kosongkan jika tida ada)
global.psaweria = '~Not Found~' // Link saweria (kosongkan jika tida ada)
global.ptrakteer = '~Not Found~' // Link trakteer (kosongkan jika tida ada)
global.psbuzz = '~Not Found~' // Link Sociabuzz (kosongkan jika tida ada)


/*============== API SETTINGS ==============*/
global.rose = 'yaU7nZmhh1tFirAE07TvJRl0yGD459jKF0EGKsvYCh7o1Jr9ojy3Zr3XlmB3mkro';
global.xyro = 'ClaraKeyOfficial'; // xyro apikey
global.beta = 'valzyy'; // betabotz apikey
global.btc = `${global.beta}`; // tidak perlu di ubah
global.xzn = 'katz'; // xzn apikey
global.yanz = 'Vynzzdev0667'; // yanz apikey
global.alyapi = 'AxellDev'; // Alya Apikey
global.alya = `${global.alyapi}`; // tidak perlu di ubah
global.roseapi = 'yaU7nZmhh1tFirAE07TvJRl0yGD459jKF0EGKsvYCh7o1Jr9ojy3Zr3XlmB3mkro'; // Rose Apikey
global.lolkey = 'vYnZfdE2v72'; // Lolhuman Apikey
global.neoapi = 'Kemii'; // Neoxr Apikey
global.jkt48connect = 'JKTCONNECT'; // jkt48connect apikey
global.zein = 'zenzkey_c22460242f6e', // zein apikey
global.xteam = 'AIzaoEvIuGYceMxZlkAI' //  xtermai apikey
global.APIs = {
    xteam: 'https://aihub.xtermai.xyz',
    lol: 'https://api.lolhuman.xyz',
    males: 'https://malesin.xyz',
    neoxr: 'https://api.neoxr.eu',
    xyro: 'https://api.xyroinee.xyz',
    btc: 'https://api.betabotz.org',
    yanz: 'https://api.yanzbotz.live',
    xfarr: 'https://api.xfarr.com',
    alya: 'https://api.alyachan.dev',
    dzx: 'https://api.dhamzxploit.my.id',
    zein: 'https://api.zahwazein.xyz',
    rose: 'https://api.itsrose.rest',
    popcat: 'https://api.popcat.xyz',
    xzn: 'https://skizo.tech',
    saipul: 'https://saipulanuar.cf',
    beta : 'https://api.betabotz.eu.org',
}
global.APIKeys = {
    'https://api.zahwazein.xyz': 'zenzkey_c22460242f6e',
    'https://api.xteam.xyz': 'cristian9407',
    'https://api.xyroinee.xyz': 'ClaraKeyOfficial',
    'https://api.neoxr.eu': 'Composing',
    'https://api.yanzbotz.live': 'Vynzzdev0667',
    'https://api.xfarr.com': 'Kemii',
    'https://api.zahwazein.xyz': 'Kemii',
    'https://api.betabotz.org': 'Rizalzllk',
    'https://api.lolhuman.xyz': 'vHYbz23@Dv',
    'https://api.itsrose.rest': 'yaU7nZmhh1tFirAE07TvJRl0yGD459jKF0EGKsvYCh7o1Jr9ojy3Zr3XlmB3mkro',
    'https://skizo.tech': 'katz',
}


/*============== HARGA NOKOS ==============*/
global.nokosindo = '10000'
global.nokosusa = '8000'
global.nokosmalay = '12000'

/*============== PANEL SETTINGS ==============*/
global.domain = '-' // Domain Web
global.apikey = '-' // Key PTLA
global.c_apikey = '-' // Key PTLC
global.eggs = '15' // id eggs
global.locs = '1'


global.discord = true
global.tokenn ='MTMwNTE0MTY5MzQ3NzAyNzg5MQ.GXZ70g.ioj6gXnYCYM7XN9ObS9x7MfAELZBMKqBM0uiLw'
global.token ='MTMwNTE0MTY5MzQ3NzAyNzg5MQ.GXZ70g.ioj6gXnYCYM7XN9ObS9x7MfAELZBMKqBM0uiLw'
global.clientId ='1305141693477027891'
global.prompt ='Nama kamu adalah DelynnAI, kamu dibuat dan dikembangkan oleh tim developer Valzy dan medsos valzy adalah, instagram(@valzy._), tiktok(@valzyycans), youtube(@valzyofc). Pakailah bahasa gaul seperti gue dan lu.'

/*============== OTHER SETTINGS ==============  (JANGAN UBAH JIKA TIDAK TAU INI APA)*/
global.fsizedoc = '99999999999999' // default 10TB
global.fpagedoc = '999'
global.useMulti = true
global.autoread = true
global.sessionName = 'Session' // gausah di sentuh
global.minety = pickRandom(['application/msword', 'application/vnd.ms-excel', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
global.kiku = 'application/vnd.android.package-archive'
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 1 // Bypass certificate
const file_exif = "lib/exif.json"
fs.watchFile(file_exif, () => {
  fs.unwatchFile(file_exif)
  console.log(chalk.redBright("Update 'exif.json'"))
  delete require.cache[file_exif]
  require('./lib/exif.json')
})


/*============== HIASAN DAN EMOTE ==============*/
global.htki =  '───「' // Hiasan kiri
global.htka = '」──' // Hiasan kanan
global.htjava = '❃' // Hiasan
global.sa = '╭─'
global.gx = '│✇'
global.gy = '│•'
global.gz = '│'
global.sb = '╰────࿐'
global.kki = '「'
global.kka = '」'
global.multiplier = 1000 // The higher, The harder levelup
global.loading = (m, conn, back = false) => {
  if (!back) {
      return conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
  } else {
      return conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  }
}

global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      trash: '🗑',
      armor: '🥼',
      sword: '⚔️',
      wood: '🪵',
      rock: '🪨',
      string: '🕸️',
      horse: '🐎',
      cat: '🐈' ,
      dog: '🐕',
      fox: '🦊',
      petFood: '🍖',
      iron: '⛓️',
      gold: '👑',
      emerald: '💚'
    }
/*================== END OF CONFIGURATION ==================*/








    let results = Object.keys(emot).map(v =>vv [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Reloading 'settings.js'"))
  delete require.cache[file]
  require(file)
})
