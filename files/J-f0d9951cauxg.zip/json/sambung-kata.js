import fs from 'fs';

let kata = [];
try {
    const data = fs.readFileSync('./kbbi.json', 'utf-8');
    kata = JSON.parse(data);
} catch (error) {
    console.error("Gagal membaca atau memuat file kbbi.json:", error.message);
    process.exit(1);
}

function ckata(input) {
    if (!input || input.trim() === "") {
        return "Input tidak boleh kosong!";
    }
    if (kata.includes(input.toLowerCase())) {
        return "Kata valid!";
    } else {
        return "Kata tidak valid!";
    }
}

export {
kata, 
ckata
}