let handler = async (m) => {
let ch = (Object.keys(conn.chats)).filter((v) => v.endsWith("newsletter"))
if (ch) return;
let tq =`Sama samaa 🥰
`
await m.reply(tq)
}
handler.customPrefix = /makasih|terimaksih|tanks|tengkiu|maci|maaci|trimakasih|thx|thank|thanks|makasi/i
handler.command = new RegExp

export default handler