import { ephoto, ephoto2 } from "../scraper/ephoto.js";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*[❗] Contoh Penggunaan:*
.glitch *Teks Anda* (untuk model 1 teks)
.pornhub *Teks1|Teks2* (untuk model 2 teks) `;

    m.reply("[ ⏳ ] Creating image...");

    global.models = {
        glitch: 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html',
        write: 'https://en.ephoto360.com/write-text-on-wet-glass-online-589.html',
        advancedglow: 'https://en.ephoto360.com/advanced-glow-effects-74.html',
        typography: 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html',
        pixelglitch: 'https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html',
        neonglitch: 'https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html',
        flag: 'https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html',
        flag3d: 'https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html',
        deleting: 'https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html',
        blackpink: 'https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html',
        glowing: 'https://en.ephoto360.com/create-glowing-text-effects-online-706.html',
        underwater: 'https://en.ephoto360.com/3d-underwater-text-effect-online-682.html',
        logomaker: 'https://en.ephoto360.com/free-bear-logo-maker-online-673.html',
        cartoonstyle: 'https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html',
        papercutstyle: 'https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html',
        watercolor: 'https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html',
        effectclouds: 'https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html',
        blackpinklogo: 'https://en.ephoto360.com/create-blackpink-logo-online-free-607.html',
    };

    global.models2 = {
        pornhub: "https://en.ephoto360.com/create-pornhub-style-logos-online-free-549.html",
        marvel: "https://en.ephoto360.com/create-marvel-style-logo-419.html",
        avengers: "https://en.ephoto360.com/create-logo-3d-style-avengers-online-427.html",
        vintage: "https://en.ephoto360.com/create-realistic-vintage-3d-light-bulb-608.html",
        glitch2: "https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html",
        spooky: "https://en.ephoto360.com/create-spooky-photos-online-for-halloween-787.html",
        born: "https://en.ephoto360.com/create-blackpink-s-born-pink-album-logo-online-779.html",
        space: "https://en.ephoto360.com/latest-space-3d-text-effect-online-559.html",
        stone: "https://en.ephoto360.com/create-3d-stone-text-effect-online-508.html",
        steel: "https://en.ephoto360.com/steel-text-effect-66.html"
    };

    let model;
    
    try {
        if (text.includes('|')) {
            if (!(command in global.models2)) throw `*[❗] Model ini hanya mendukung teks satu bagian!*\nGunakan format: ${usedPrefix + command} teks1|teks2\n\nModel yang tersedia untuk 2 kata split:\n${Object.keys(global.models2).join("\n")}`;
            model = global.models2[command];
            let texts = text.split('|');
            let data = await ephoto2(model, texts[0], texts[1]);
            await conn.sendMessage(m.chat, { image: { url: data } }, { quoted: m });
        } else {
            if (!(command in global.models)) throw `*[❗] Model ini hanya mendukung satu teks!*\nGunakan format: ${usedPrefix + command} teks Anda\n\nModel yang tersedia untuk 1 kata no split:\n${Object.keys(global.models).join("\n")}`;
            model = global.models[command];
            let data = await ephoto(model, text);
            await conn.sendMessage(m.chat, { image: { url: data } }, { quoted: m });
        }
    } catch (e) {
        if (command in global.models) {
            throw `[❗] Itu adalah command untuk model 1 kata\nList Model 1 Kata:\n${Object.keys(global.models).join("\n")}`;
        } else {
            return m.reply(`[❗] Itu adalah command untuk model 2 kata (gunakan format teks1|teks2)\nList Model 2 Kata:\n${Object.keys(global.models2).join("\n")}`);
        }
    }
};

handler.help = handler.command = [
    "glitch", "write", "advancedglow", "typography", "pixelglitch", "neonglitch", "flag", "flag3d", "deleting", "blackpink", "glowing", "underwater", "logomaker", "cartoonstyle", "papercutstyle", "watercolor", "effectclouds", "blackpinklogo", "pornhub", "marvel", "avengers", "vintage", "glitch2", "spooky", "born", "space", "stone", "steel"
];
handler.tags = ["maker", "image"];

export default handler;