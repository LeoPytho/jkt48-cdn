import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, text, usedPrefix, command }) => {
let stiker = `https://telegra.ph/file/4749ebddec8e60a5c3b8d.png`
    conn.sendMessage(m.chat,{
           requestPayment: {      
           currency: "IDR",
           amount: "10".repeat(999> conn.sendMessage(m.chat,{
           requestPayment: {      
           currency: "IDR",
           amount: "10".repeat(999),
           from: m.sender,
           sticker: { url: sticker },
           background: {
             id: "100",
             fileLength: 928283,
             width: "1000",
             height: "1000",
             mimetype: "image/webp",
             placeholderArgb: "0xFF00FF00",
             textArgb: 4294967295,
             subtextArgb: 4278190080
     }}}
   )),
           from: m.sender,
           sticker: { url: sticker },
           background: {
             id: "100",
             fileLength: 928283,
             width: "1000",
             height: "1000",
             mimetype: "image/webp",
             placeholderArgb: "0xFF00FF00",
             textArgb: 4294967295,
             subtextArgb: 4278190080
     }}}
   )
    conn.reply(nomorown + jid, 'Ayangg, ada yang nyariin kamu tuhh', m);
}

handler.customPrefix = /^(owens|@6285358977442)$/i;
handler.command = new RegExp();

export default handler;