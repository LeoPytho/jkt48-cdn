import axios from "axios";

let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.sendMessage(m.chat, {
    react: {
      text: '✔',
      key: m.key,
    }
  });

  if (command === "spotify") {
    if (!text) throw `[❗] lah query-nya mana bree?\nContoh: ${usedPrefix + command} gak pake lama`;

    let cari;
    try {
      cari = (await axios.get(`${APIs.jl}/downloader/spotifyplay?q=${encodeURIComponent(text)}`)).data;
    } catch (err) {
      throw "[❗] Anjir error, apinya kaga nyaut bree.";
    }

    const jul = cari?.result;
    if (!jul) throw "[❗] gak nemu lagu-nya bree, coba cek lagi dah.";

    const hasil = `*[ Spotify - Play ]*

• 🎵 Judul: *${jul.title}*
• 👤 Artis: *${jul.artist}*
• ⏱️ Durasi: *${jul.duration}*
• 🔗 Link: *${jul.spotifyUrl}*

 sabar bree, ini bot lagi ngirim audionya...`;

    await conn.sendMessage(m.chat, {
      document: {
        url: 'https://wa.me/6285358977442' // Ganti link kalau mau kirim file asli
      },
      mimetype: 'image/png',
      fileName: `${m.name || 'spotify'}.png`,
      jpegThumbnail: await conn.resize(pp, 400, 400),
      fileLength: 10,
      caption: hasil,
      footer: wm,
      buttons: [
        {
          buttonId: ".menu",
          buttonText: { displayText: "🗒️ Menu" }
        },
        {
          buttonId: `.spotifys ${text}`,
          buttonText: { displayText: "🚀 Lebih banyak result" }
        }
      ],
      viewOnce: true,
      headerType: 6,
      contextInfo: {
        isForwarded: true,
        forwardingScore: 999,
        mentionedJid: [m.sender],
        forwardedNewsletterMessageInfo: {
          newsletterName: wm2,
          newsletterJid: idsal,
          serverMessageId: null
        },
        externalAdReply: {
          title: "</> Spotify Play </>",
          body: "Cari lagu langsung dapet bree",
          thumbnailUrl: jul.cover,
          sourceUrl: saluran,
          mediaType: 1,
          mentionedJid: [m.sender],
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

  const audioBuffer = await fetch(jul.downloadUrl).then(res => res.arrayBuffer())

  await conn.sendMessage(m.chat, {
    audio: Buffer.from(audioBuffer),
    mimetype: 'audio/mp4',
    fileName: `${jul.title}.mp3`,
    contextInfo: {
      externalAdReply: {
        title: jul.title,
        body: `🎵 Judul: ${jul.title}\n📺 Channel: ${jul.artist}\n⏱️ Durasi: ${jul.duration}\n`,
        thumbnailUrl: jul.cover,
        mediaType: 1,
        sourceUrl: jul.spotifyUrl,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
  }
};

handler.command = handler.help = ['spotify', 'spotifyp'];
handler.tags = ['internet', 'downloader'];

export default handler;