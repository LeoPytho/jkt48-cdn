/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owenssw
* 𝘪𝘯𝘧𝘰: -
* 𝘺𝘵: https://youtube.com/CekGem
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

import uploadImage from '../lib/uploadImage.js'
import pkg from 'wa-sticker-formatter'
import fs from 'fs'

const { createSticker } = pkg;
const effects = ['jail', 'gay', 'glass', 'wasted', 'triggered']

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    let effect = text.trim().toLowerCase()
    if (!effects.includes(effect)) throw `
*Usage:* ${usedPrefix}stickmaker <effectname>
*Example:* ${usedPrefix}filter jail

*List Effect:*
${effects.map(effect => `_> ${effect}_`).join('\n')}
`.trim()

    if (/image/g.test(mime) && !/webp/g.test(mime)) {
        try {
            let img = await q.download?.()
            let out = await uploadImage(img)
            let apiUrl = global.API('https://some-random-api.com/canvas/', encodeURIComponent(effect), {
                avatar: out
            })
            await conn.sendFile(m.chat, apiUrl, 'sticker.webp', '', m)
        } catch (e) {
            console.log(e)
        }
    } else {
        m.reply(`Kirim Gambar Dengan Caption *${usedPrefix + command}* Atau Tag Gambar Yang Sudah Dikirim`)
    }
}

handler.help = ['filter']
handler.tags = ['maker']
handler.command = /^(filter)$/i

export default handler