const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('[❗] Input Prompt\n\nEx: .text2img kucing diatas pohon');
  
  let {key} = await conn.sendMessage(m.chat, {text:'[⏱️] Processing the image. Please wait a moment.'}, {quoted:m});
  
  try {
    const response = APIs.ft+`/ai/txt2img?prompt=`+text;
    
    if (response) {
      await conn.delay(3000);
      let a = await conn.sendMessage(m.chat, { text: ` ✔ Image berhasil di buat...`, edit: key });
       let hoh = await conn.sendMessage(m.chat, { text: `🔁 Image hasil sedang dikirim, mohon bersabar...`, edit: a.key});
      await conn.delay(3000);
      await conn.sendMessage(m.chat, { 
        image: { url: response },
        caption: "*[🔍] Result:* " + text
      }, { quoted: m });
       await conn.delay(3000);
      await conn.sendMessage(m.chat, { delete: hoh });
      m.react("✅") 
    } else {
      m.reply(`[❗] Failed to generate image: ${response.result}`);
    }
  } catch (error) {
    m.reply(error.stack);
  }
};

handler.help = ['text2img <prompt>'];
handler.command = ['texttoimg', 'text2img', 'aiimg', 'txt2img'];
handler.tags = ['ai'];

export default handler;