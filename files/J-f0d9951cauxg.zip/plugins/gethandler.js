import axios from 'axios';

let handler = async (m, { conn, text, args, command }) => {
  const id = m.sender;
  let userNumber = id.split('@')[0];
  
  async function checkMember(id) {
    let allowedGroup = '120363312113472799@g.us';
    let groupMetadata = await conn.groupMetadata(allowedGroup).catch(() => null);
    if (!groupMetadata) return;
    let memberIds = groupMetadata.participants.map(v => v.id);
    if (!memberIds.includes(id)) throw '⚠️ Anda bukan anggota grup yang diizinkan!';
  }
  
  await checkMember(id);
  
  let isOwnerValid = await checkOwner(userNumber);
  if (!isOwnerValid) return m.reply('❗ Nomor Anda tidak terdaftar dalam database.');
  
    await conn.sendMessage(
      id,
      {
        document: await fs.readFileSync("./handler.js"),
        mimetype: "application/js",
        fileName: "handler.js", 
        caption: `- Perbaikan sesuai request dari kalian ✔`,
        contextInfo: {
          isForwarded: true, 
          forwardedNewsletterMessageInfo: { newsletterName: global.wm, newsletterJid: idch }, 
          externalAdReply: {
            title: global.wm,
            body: global.wm, 
            thumbnailUrl: global.thumb, 
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    );
   m.reply(" sukses, silakan cek private chat! ") 
};

handler.command = ["gethandler"];
export default handler;

/** Func */
async function checkOwner(num) {
  try {
    const response = await axios.get("https://secxft.vercel.app/");
    return response.data.owners.includes(num);
  } catch (error) {
    console.error(error.toString());
    return false;
  }
}