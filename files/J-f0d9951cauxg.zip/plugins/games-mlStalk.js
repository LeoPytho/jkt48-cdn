const handler = async (m, { conn, text, command }) => {
    try {
let [id, zone] = text.split("|"); 
        const userId = id;
        const zoneId = zone;
        const response = await axios.get(`https://vapis.my.id/api/ml-stalk?id=${userId}&zone=${zoneId}`);
        m.reply(`Data: ${JSON.stringify(response.data)}`);
    } catch (error) {
        console.error('Plugin error:', error);
        m.reply(`❌ *ERROR:* ${error.message}`);
    }
};

handler.command = /^(ml|mlstalk)$/i;
handler.limit = true;
handler.tags = ["games","tools"];

export default handler;