const handler = async (m, { conn }) => {
  const user = global.db.data.users[m.sender];

  if (user.pasangan === "") {
    return conn.reply(m.chat, `Kamu sedang tidak menembak siapapun!`, m);
  }

  const pasanganUser = global.db.data.users[user.pasangan];

  if (pasanganUser.pasangan === m.sender) {
    return conn.reply(m.chat, `Kamu telah berpacaran dengan @${user.pasangan.split('@')[0]}`, m, {
      contextInfo: {
        mentionedJid: [user.pasangan],
      },
    });
  }

  conn.reply(m.chat, `Kamu sudah mengikhlaskan @${user.pasangan.split('@')[0]} karena dia tidak memberikan jawaban diterima atau ditolak`, m, {
    contextInfo: {
      mentionedJid: [user.pasangan],
    },
  });

  user.pasangan = "";
};

handler.help = ['ikhlasin'];
handler.tags = ['jadian'];
handler.command = /^(ikhlasin|ikhlas)$/i;
handler.mods = false;
handler.premium = false;
handler.group = true;
handler.fail = null;

export default handler