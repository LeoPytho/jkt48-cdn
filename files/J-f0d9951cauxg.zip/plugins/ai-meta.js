let handler = async (m, { conn, text }) => {    
    if (!text) return m.reply('Apa yang ingin kamu ajukan?');
    try {
        const apiUrl = `https://fastrestapis.fasturl.cloud/aillm/meta?ask=${encodeURIComponent(text)}&sessionId=1234-5678-abcd-efgh`;
        const response = await fetch(apiUrl);
        const mark = await response.json();
        let meta = "13135550002"+jid;
        let a = await conn.profilePictureUrl(meta, "image")
        const ress = mark.result.message || 'Maaf, saya tidak bisa memahami permintaan Anda.';
        await conn.sendMessage(m.chat, { 
            text: ress, 
            contextInfo: { 
                isForwarded: true, 
                businessMessageForwardInfo: { businessOwnerJid: meta }, 
                externalAdReply: {
                title: " ✨ M E T A - A I", 
                body: "Powered By WhatsApp", 
                sourceUrl: "https://meta.ai", 
                thumbnailUrl: a, 
                renderLargerThumbnail: false
                }
            } 
        }, { quoted: m });
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

handler.help = ['aimeta', 'ai'];
handler.tags = ['ai'];
handler.command = /^(aimeta|metaai|6289514594072|ai)$/i;

export default handler;