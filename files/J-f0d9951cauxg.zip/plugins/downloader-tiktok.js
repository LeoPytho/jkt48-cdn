const handler = async (m, { conn, command, args }) => {
    if (!args[0]) throw `[❗] Input TikTok URL parameter!\n\nEx: /${command} https://vt.tiktok.com/xxxx`;

    const url = args[0];

    try {
        await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

        const { data } = await axios.get(`${APIs.ft}/download/tiktok?url=${url}`);
        const { metadata } = data.result;
        const slide = metadata.download.slide;
        const video = metadata.download.video;
        const audio = metadata.download.audio;

        if (slide.length > 0) {
            for (let i = 0; i < slide.length; i++) {
                await conn.sendMessage(
                    m.chat,
                    { image: { url: slide[i] }, caption: `` },
                    { quoted: m }
                );
            }
        } else if (video) {
            await conn.sendMessage(
                m.chat,
                { video: { url: video }, caption: metadata.title || 'Video TikTok' },
                { quoted: m }
            );
        }
            if (audio) {
                await conn.sendAudio(
                    m.chat,
                    audio, false,
                    m
                );
            }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
        console.error(e);
        m.reply(e.message);
    }
};

handler.help = ['tt <url>', 'ttdl <url>', 'tiktok <url>', 'tiktokdl <url>'];
handler.tags = ['downloader'];
handler.command = /^(tt|ttdl|tiktok|tiktokdl)$/i;

export default handler;