let handler = async (m, { conn, text }) => {
  if (!text) throw `[❗] Input URL CapCut!`;

  try {
    let url = await func.isUrl(text);
    await load();

    let { data: { result } } = await axios.get(`${APIs.ft}/download/capcut?url=${url}`);

    await conn.sendMessage(m.chat, {
      video: { url: result.videoUrl },
      caption: `[ CAPCUT - DOWNLOADER ]\n\n*Judul:* ${result.title}\n*Author:* ${result.author}\n*Description:* ${result.description}\n*Thumb:*\n${result.thumb}\n*Source:* ${result.source}\n`,
      contextInfo: {
        externalAdReply: {
          title: result.title,
          body: result.description,
          thumbnailUrl: result.thumb,
          renderLargerThumbnail: true,
          mediaType: 1
        }
      }
    }, { quoted: m });

    await m.react(`✅`);
  } catch (e) {
    await m.react("❌");
    await conn.reply(`${owner[0][0]}@s.whatsapp.net`, e.stack, m);
  }
};

handler.command = /^(cc|capcut|capcutdl|ccdl)$/i;
handler.help = ["capcutdl","capcut"];
handler.tags = ["downloader"];
handler.register = true;
handler.limit = true;

export default handler;