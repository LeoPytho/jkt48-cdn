let handler = async(m, {conn, args, command}) => {
if(!args[0]) return m.reply(`[❕] Donasi Via Qris Auto
Masukkan Nominal dengan min. 1000, contoh:
/${command} <amount> <note>
/${command} 1000 Ini donasi 1000 bang`)
if(args[0] <= 999) return m.reply('kikir bgt')

let note = args[1].trim()
let usn = qris.username //global.qris di config.js
if (!usn) return `[❗] Tidak ada tujuan transaksi/qris tidak di set oleh owner, segera hubungi owner!\n\nwa.me//${owner[0][0]}`

const cqris = (await axios.get(APIs.ft+`/tools/qrisajaib?username=${usn}&amount=${parseInt(args[0])}&note=${note}`)).data;

let status = "";
const expiredAt = new Date(cqris.expiresAt);
const expiredTime = expiredAt.toLocaleTimeString('en-US', { 
  hour: '2-digit', 
  minute: '2-digit',
  hour12: false,
  timeZone: 'Asia/Jakarta'
})
const sQris = await conn.sendMessage(m.chat, {
    image: { url: cqris.qris },
    caption: `Scan Qris Untuk Melakukan Pembayaran\n\nWaktu Expired : ${expiredTime} WIB\nTotal Pembayaran : ${cqris.total}\nTrxID : #${cqris.orderId.split('-')[1]}`
}, { quoted: m });

while (status !== "completed") {
    if (new Date() >= expiredAt) {
        await conn.sendMessage(m.chat, { delete: sQris.key });
        m.reply("QRIS telah expired, pembayaran dibatalkan..");
        return;
    }

    const res = await checkStatus(cqris.orderId, cqris.nominal);
    if (res && res.status === "completed") {
        status = "completed";
        await conn.sendMessage(m.chat, { delete: sQris.key });
        m.reply('Pembayaran Berhasil!\n\nTerimakasih telah melakukan pembayaran di Furina^^✨');
        return;
    }
    await conn.delay(5000);
}

}
handler.command = handler.help = ["donasi", "bayar", "qrisajaib"]
handler.tags = ["main"]

export default handler