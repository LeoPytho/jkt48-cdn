let handler = async(m, { text }) => {
    
    try {
        await m.reply('> Waitt...')
        const { data } = await axios.get(`https://www.loliapi.com/acg/pe/?type=url`)
        conn.sendMessage(m.chat, { image: { url: data }, caption: '*`Pedoo-!!`*' }, { quoted: m })
    } catch (err) {
        console.error(err)
        m.reply('> Terjadi kesalahan!')
    }
}
handler.command = handler.help = ["randomloli", "loli2"]
handler.tags = ["internet", "image"]

export default handler