const toM = (a) => '@' + a.split('@')[0];

export function handler(m, { groupMetadata }) {
    const participants = groupMetadata.participants.map(v => v.id);
    if (participants.length < 2) {
        return m.reply('🚩 *Tidak cukup peserta di grup untuk memulai permainan.*');
    }

    let a = participants[Math.floor(Math.random() * participants.length)];
    let b;

    do {
        b = participants[Math.floor(Math.random() * participants.length)];
    } while (b === a);

    m.reply(`${toM(a)} ❤️ ${toM(b)}`, null, {
        mentions: [a, b]
    });
}

handler.help = ['jadian'];
handler.tags = ['fun'];
handler.command = ['jadian'];
handler.limit = false;
handler.group = true;

export default handler