import uploadImage from '../lib/uploadImage.js'

let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m;
  if (!/(image|sticker)/i.test(q.mtype)) throw '[❗] Media Image atau Sticker tidak ditemukan';
  try {
    let a = await q?.download();
    let y = await uploadImage(a);
    await load();
    let { data: { result } } = await axios.get(APIs.ft + "/ai/img2prompt?imageUrl=" + y);
    await conn.sendMessage(
      m.chat,
      {
        text: "//Result.json\n" + JSON.stringify(result, null, 2),
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true, 
            title: "[ IMG TO PROMPT ]",
            body: "Powered by Kyzryzz",
            thumbnailUrl: y,
            renderLargerThumbnail: false,
            mediaType: 1
          }
        }
      },
      { quoted: m }
    );
  } catch (e) {
    await m.react("❌");
    await conn.reply(`${owner[0][0]}@s.whatsapp.net`, e.stack, m);
  }
};

handler.command = /^(img2prompt|image2prompt|img2text|img2txt)$/i;
handler.help = ["img2prompt", "img2text"];
handler.tags = ["ai"];

export default handler;