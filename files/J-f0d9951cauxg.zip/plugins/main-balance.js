let handler = async (m, { command }) => {
let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
    if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak ada didalam data base'
    let user = global.db.data.users[who]
    let limit = user.premiumTime >= 1 ? '∞' : user.limit    
let kontol = { key: { remoteJid: 'status@broadcast', participant: '13135550002@s.whatsapp.net' }, message: { orderMessage: { itemCount: limit, status: 1, thumbnail: await conn.resize(await getBuffer(pp),300,150), surface: 1, message: 'ʏ ᴏ ᴜ ʀ  ʟ ɪ ᴍ ɪ ᴛ: ' + limit, orderTitle: wm, sellerJid: '0@s.whatsapp.net' } } }
let i = await style(command, 1) 
let balance = i.split("").join(" ");
let ah = await style(`
▧ *u s e r - i n f o*
│ ∘ *ᴜsᴇʀɴᴀᴍᴇ:* ${user.registered ? user.name : conn.getName(who)}
│ ∘ *tag:* @${who.split`@`[0]}
│ ∘ *sᴛᴀᴛᴜs:*  ${who.split`@`[0] == global.nomorwa ? '🎗️Developer🎗️' : user.premiumTime >= 1 ? '👑Premium👑' : user.level >= 1000 ? '🪖ᴇʟɪᴛᴇ ᴜsᴇʀ🪖' : '👤Free User👤'}
└───╌┄❍

▧ *m e t a d a t a*
│ ∘ *money:* ${user.money}
│ ∘ *bank:* ${user.bank}
│ ∘ *limit:* ${limit}
└───╌┄❍`, 1) 
conn.sendMessage(m.chat, {
text: ah,
contextInfo: {
mentionedJid: [who], 
externalAdReply: {
showAdAttribution: true,
title: await style(' t h i s - b a l a n c e', 1),
thumbnailUrl: 'https://files.catbox.moe/3s8nlt.jpeg',
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: kontol})
}
handler.help = ['limit', 'balance'].map(a => a + ' [@user]') 
handler.tags = ['main']
handler.command = /^(limit|balance)$/i
export default handler