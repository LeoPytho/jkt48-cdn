/**
 * 𝙆𝙮𝙯𝙍𝙮𝙯𝙯 𝙓𝘿
 * 𝘵𝘦𝘭𝘦: https://t.me/kyzoffc
 * 𝘪𝘯𝘧𝘰: https://s.id/kyzzxd
 * 𝘺𝘵: https://youtube.com/KyzXD
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
**/

export async function before(m, {
    isAdmin,
    isBotAdmin
}) {

    let chat = global.db.data.chats[m.chat]
    if (m.chat.endsWith('broadcast') || chat.isBanned || !chat.getmsg || global.db.data.users[m.sender].banned || m.isBaileys) return
    let msgs = global.db.data.msgs
    if (!(m.text in msgs)) return
    let _m = this.serializeM(JSON.parse(JSON.stringify(msgs[m.text]), (_, v) => {
        if (
            v !== null &&
            typeof v === 'object' &&
            'type' in v &&
            v.type === 'Buffer' &&
            'data' in v &&
            Array.isArray(v.data)) {
            return Buffer.from(v.data)
        }
        return v
    }))
    await _m.copyNForward(m.chat, false)
}

// Get Message No Prefix