/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/OwensDev
* 𝘪𝘯𝘧𝘰: -
* 𝘺𝘵: https://youtube.com/OwensDev
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

import fetch from "node-fetch"
let handler = async(m, { conn, usedPrefix, command, text }) => {
	if  (command == 'tahlil') {
	let res = await(await fetch('https://raw.githubusercontent.com/veann-xyz/result-daniapi/main/religion/tahlil.json')).json()
	const sections = Object.values(res.result.data).map((v, index) => ({
        title: v.title, rows: [
           { title: v.title, rowId: usedPrefix + 'tahlil-get ' + index, description: v.arabic }
    ]}))
    const listMessage = {
        text: `乂 *_Doa Tahlil_*`,
        footer: `_Silahkan Pilih Doa Tahlil Dibawah Ini..._`,
        title: '',
        buttonText: 'Tap!',
        viewOnce:true, 
        sections
    }
    return conn.sendMessage(m.chat, listMessage, { quoted: m })
    }
    if (command == 'tahlil-get') {
    	let res = await(await fetch('https://raw.githubusercontent.com/veann-xyz/result-daniapi/main/religion/tahlil.json')).json()
        let { title, arabic, translation } = res.result.data[text]
        let teks = `乂 _*${title}*_
        
_*Arabic:*_ ${arabic}

_*Translation:*_ ${translation}
`
        m.reply(teks)
    }
}
handler.help = ['tahlil']
handler.tags = ['islami']
handler.command = /^(tahlil|tahlil-get)$/i
export default handler