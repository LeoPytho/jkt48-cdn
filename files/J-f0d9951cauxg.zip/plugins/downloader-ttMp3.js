let handler = async (m, { conn, text, command }) => {
  if (!text) throw `[❗] Input parameter TikTok URL\nContoh: /${command} https://vt.tiktok.com/xxxx`

  try {
  let { data: { result }} = await axios.get(APIs.ft + "/download/tiktok?url=" + text)
    let v = result.metadata.musicInfo
    
    await load()
 
    await conn.sendMessage(m.chat, {
      audio: { url: v.audio },
      mimetype: 'audio/mpeg',
      fileName: v.title+'.mp3', 
      contextInfo: {
       isForwarded: true, 
       forwardedNewsletterMessageInfo: {
         newsletterJid: idch, 
         newsletterName: v.title, 
         serverMessageId: -1
       }, 
       externalAdReply: {
       title: v.title, 
       body: `Author: ${v.author} || Original? ${v.original}`, 
       sourceUrl: v.audio, 
       thumbnailUrl: v.thumbnail, 
       renderLargerThumbnail: false, 
       mediaType: 1
      }}
    }, { quoted: m })
  } catch (e) {
    console.error(e)
    throw e
  }
}

handler.command = handler.help = ["ttmp3", "ttaudio"]
handler.tags = ["downloader"]
handler.register = handler.limit = true

export default handler