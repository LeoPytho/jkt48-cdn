let handler = m => m

handler.before = async function (m) {
   const bannedPrefixes = ['212', '265', '91', '90']
   for (let prefix of bannedPrefixes) {
      if (m.sender.startsWith(prefix)) {
         global.db.data.users[m.sender].banned = true
      }
   }

   const nomorBot = global.nomorbot + '@s.whatsapp.net'
   if (m.sender === nomorBot) {
      global.db.data.users[m.sender].banned = true
   }
}

export default handler