let handler = async (m, { conn }) => {
  const asmaulHusna = [
    { name: "Ar-Rahman", clue: "Yang Maha Pengasih" },
    { name: "Ar-Rahim", clue: "Yang Maha Penyayang" },
    { name: "Al-Malik", clue: "Yang Maha Merajai" },
    { name: "Al-Quddus", clue: "Yang Maha Suci" },
    { name: "As-Salam", clue: "Yang Maha Sejahtera" },
    { name: "Al-Mu’min", clue: "Yang Maha Memberi Keamanan" },
    { name: "Al-Muhaymin", clue: "Yang Maha Mengawasi" },
    { name: "Al-Aziz", clue: "Yang Maha Perkasa" },
    { name: "Al-Jabbar", clue: "Yang Maha Memaksa" },
    { name: "Al-Mutakabbir", clue: "Yang Maha Megah" },
    { name: "Al-Khaliq", clue: "Yang Maha Pencipta" },
    { name: "Al-Bari'", clue: "Yang Maha Membuat Sesuatu" },
    { name: "Al-Musawwir", clue: "Yang Maha Membentuk" },
    { name: "Al-Ghaffar", clue: "Yang Maha Pengampun" },
    { name: "Al-Qahhar", clue: "Yang Maha Menundukkan" },
    { name: "Al-Wahhab", clue: "Yang Maha Pemberi" },
    { name: "Ar-Razzaq", clue: "Yang Maha Pemberi Rezeki" },
    { name: "Al-Fattah", clue: "Yang Maha Pembuka" },
    { name: "Al-‘Alim", clue: "Yang Maha Mengetahui" },
    { name: "Al-Qabid", clue: "Yang Maha Menyempitkan" },
    { name: "Al-Basit", clue: "Yang Maha Meluaskan" },
    { name: "Al-Khafid", clue: "Yang Maha Menjatuhkan" },
    { name: "Ar-Rafi‘", clue: "Yang Maha Meninggikan" },
    { name: "Al-Mu’izz", clue: "Yang Maha Memuliakan" },
    { name: "Al-Mudhill", clue: "Yang Maha Menghinakan" },
    { name: "As-Sami‘", clue: "Yang Maha Mendengar" },
    { name: "Al-Basir", clue: "Yang Maha Melihat" },
    { name: "Al-Hakam", clue: "Yang Maha Menetapkan" },
    { name: "Al-‘Adl", clue: "Yang Maha Adil" },
    { name: "Al-Latif", clue: "Yang Maha Halus" },
    { name: "Al-Khabir", clue: "Yang Maha Mengetahui" },
    { name: "Al-Halim", clue: "Yang Maha Penyantun" },
    { name: "Al-Azim", clue: "Yang Maha Agung" },
    { name: "Al-Ghafur", clue: "Yang Maha Pengampun" },
    { name: "Ash-Shakur", clue: "Yang Maha Mensyukuri" },
    { name: "Al-‘Aliyy", clue: "Yang Maha Tinggi" },
    { name: "Al-Kabir", clue: "Yang Maha Besar" },
    { name: "Al-Hafiz", clue: "Yang Maha Memelihara" },
    { name: "Al-Muqit", clue: "Yang Maha Memberi Kekuatan" },
    { name: "Al-Hasib", clue: "Yang Maha Membuat Perhitungan" },
    { name: "Al-Jalil", clue: "Yang Maha Mulia" },
    { name: "Al-Karim", clue: "Yang Maha Mulia" },
    { name: "Ar-Raqib", clue: "Yang Maha Mengawasi" },
    { name: "Al-Mujib", clue: "Yang Maha Mengabulkan" },
    { name: "Al-Wasi‘", clue: "Yang Maha Luas" },
    { name: "Al-Hakim", clue: "Yang Maha Bijaksana" },
    { name: "Al-Wadud", clue: "Yang Maha Pengasih" },
    { name: "Al-Majid", clue: "Yang Maha Mulia" },
    { name: "Al-Ba’ith", clue: "Yang Maha Membangkitkan" },
    { name: "Ash-Shahid", clue: "Yang Maha Menyaksikan" },
    { name: "Al-Haqq", clue: "Yang Maha Benar" },
    { name: "Al-Wakil", clue: "Yang Maha Mempercayakan" },
    { name: "Al-Qawiyy", clue: "Yang Maha Kuat" },
    { name: "Al-Matin", clue: "Yang Maha Kokoh" },
    { name: "Al-Waliyy", clue: "Yang Maha Melindungi" },
    { name: "Al-Hamid", clue: "Yang Maha Terpuji" },
    { name: "Al-Muhsi", clue: "Yang Maha Menghitung" },
    { name: "Al-Mubdi‘", clue: "Yang Maha Memulai" },
    { name: "Al-Mu‘id", clue: "Yang Maha Mengembalikan" },
    { name: "Al-Muhyi", clue: "Yang Maha Memberi Kehidupan" },
    { name: "Al-Mumit", clue: "Yang Maha Mematikan" },
    { name: "Al-Hayy", clue: "Yang Maha Hidup" },
    { name: "Al-Qayyum", clue: "Yang Maha Berdiri Sendiri" },
    { name: "Al-Wajid", clue: "Yang Maha Menemukan" },
    { name: "Al-Majid", clue: "Yang Maha Mulia" },
    { name: "Al-Wahid", clue: "Yang Maha Tunggal" },
    { name: "Al-Ahad", clue: "Yang Maha Esa" },
    { name: "As-Samad", clue: "Yang Maha Dibutuhkan" },
    { name: "Al-Qadir", clue: "Yang Maha Kuasa" },
    { name: "Al-Muqtadir", clue: "Yang Maha Menentukan" },
    { name: "Al-Muqaddim", clue: "Yang Maha Mendahulukan" },
    { name: "Al-Mu’akhkhir", clue: "Yang Maha Mengakhirkan" },
    { name: "Al-Awwal", clue: "Yang Maha Awal" },
    { name: "Al-Akhir", clue: "Yang Maha Akhir" },
    { name: "Az-Zahir", clue: "Yang Maha Menyatakan" },
    { name: "Al-Batin", clue: "Yang Maha Tersembunyi" },
    { name: "Al-Wali", clue: "Yang Maha Memiliki" },
    { name: "Al-Muta‘ali", clue: "Yang Maha Tinggi" },
    { name: "Al-Barr", clue: "Yang Maha Baik" },
    { name: "At-Tawwab", clue: "Yang Maha Penerima Taubat" },
    { name: "Al-Muntaqim", clue: "Yang Maha Pembalas" },
    { name: "Al-‘Afuw", clue: "Yang Maha Pemaaf" },
    { name: "Ar-Ra’uf", clue: "Yang Maha Pengasih" },
    { name: "Malik al-Mulk", clue: "Pemilik Kerajaan" },
    { name: "Dhul-Jalali wal-Ikram", clue: "Yang Maha Memiliki Keagungan dan Kemuliaan" },
    { name: "Al-Muqsit", clue: "Yang Maha Adil" },
    { name: "Al-Jami‘", clue: "Yang Maha Mengumpulkan" },
    { name: "Al-Ghaniyy", clue: "Yang Maha Kaya" },
    { name: "Al-Mughni", clue: "Yang Maha Memberi Kekayaan" },
    { name: "Al-Mani‘", clue: "Yang Maha Mencegah" },
    { name: "Ad-Darr", clue: "Yang Maha Memberi Mudharat" },
    { name: "An-Nafi‘", clue: "Yang Maha Memberi Manfaat" },
    { name: "An-Nur", clue: "Yang Maha Bercahaya" },
    { name: "Al-Hadi", clue: "Yang Maha Memberi Petunjuk" },
    { name: "Al-Badi‘", clue: "Yang Maha Pencipta" },
    { name: "Al-Baqi", clue: "Yang Maha Kekal" },
    { name: "Al-Warith", clue: "Yang Maha Mewarisi" },
    { name: "Ar-Rashid", clue: "Yang Maha Memberi Petunjuk ke Jalan yang Lurus" },
    { name: "As-Sabur", clue: "Yang Maha Sabar" },
  ];

  if (!conn.tebakAsmaulHusna) conn.tebakAsmaulHusna = {};

  if (m.sender in conn.tebakAsmaulHusna) {
    m.reply("Kamu masih punya pertanyaan yang belum selesai!");
    return;
  }

  const randomAsmaul = asmaulHusna[Math.floor(Math.random() * asmaulHusna.length)];
  conn.tebakAsmaulHusna[m.sender] = {
    answer: randomAsmaul.name.toLowerCase(),
    timeout: setTimeout(() => {
      delete conn.tebakAsmaulHusna[m.sender];
      m.reply(`Waktu habis! Jawabannya adalah *${randomAsmaul.name}*.`);
    }, 30 * 1000), // 30 detik
  };

  m.reply(
    `*Tebak Asmaul Husna*\n\nClue: ${randomAsmaul.clue}\n\nKetik jawabanmu dalam waktu 30 detik!`
  );
};

handler.before = async (m, { conn }) => {
  if (!conn.tebakAsmaulHusna || !(m.sender in conn.tebakAsmaulHusna)) return;

  const game = conn.tebakAsmaulHusna[m.sender];
  if (m.text.toLowerCase() === game.answer) {
    clearTimeout(game.timeout);
    delete conn.tebakAsmaulHusna[m.sender];
    m.reply(`Selamat! Jawaban kamu benar: *${game.answer}*.`);
  } else {
    m.reply("Jawaban salah! Coba lagi.");
  }
};

handler.help = ["tebakasmaulhusna"];
handler.tags = ["islami"];
handler.command = /^(tebakasmaulhusna|tebakhusna)$/i;

export default handler;