let handler = m => m
handler.all = async(m, { participants, isBotAdmin }) => {
if (chats.antiHt === false) return 
if (m.isGroup&&m.mentionedJid.length == participants.length){
				await conn.sendMessage(m.chat, {

					delete: {
						remoteJid: m.chat,
						fromMe: false,
						id: m.key.id,
						participant: m.key.participant
					}
				});
				if(isBotAdmin) m.reply('⛔Pesan ini dihapus karena mengandung tagall.')
				return;
			}
}