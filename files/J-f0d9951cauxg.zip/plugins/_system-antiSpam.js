import {
  performance
} from "perf_hooks";
const SPAM_THRESHOLD = 5,
  COOLDOWN_DURATION = 1e4,
  BAN_DURATION = 5e3;
export async function before(m, {
  isOwner
}) {
  const users = db.data.users[m.sender],
    chats = db.data.chats;
  if (m.isBaileys && m.fromMe) return true;
  if (!m.isGroup) return false;
  if (chats[m.chat].antiSpam && !m.isBaileys && !["protocolMessage", "pollUpdateMessage", "reactionMessage"].includes(m.mtype) && m.msg && m.message && m.key.remoteJid === m.chat && !users.banned && !chats[m.chat].isBanned) {
    users.spammer = users.spammer || {}, users.spammer[m.sender] = users.spammer[m.sender] || {
      count: 0,
      lastspammer: 0
    };
    const now = performance.now();
    if (now - users.spammer[m.sender].lastspammer < 1e4) {
      if (users.spammer[m.sender].count++, users.spammer[m.sender].count >= 5) {
        if (!isOwner) users.banned = !0, users.spammer[m.sender].lastspammer = now + 5e3,
          setTimeout(() => {
            users.banned = !1, users.spammer[m.sender].count = 0, m.reply("✅ *Cooldown selesai*\nAnda bisa mengirim pesan lagi.");
          }, 5e3);
        const remainingCooldown = Math.ceil((users.spammer[m.sender].lastspammer - now) / 1e3),
          message = m.mtype.replace(/message$/i, "").replace("audio", m.msg.ptt ? "PTT" : "audio").replace(/^./, v => v.toUpperCase()) || "Unknown";
        return m.reply(`❌ *Mohon jangan spam ${message}*\nTunggu setelah ${remainingCooldown} detik`);
      }
    } else users.spammer[m.sender].count = 0;
    users.spammer[m.sender].lastspammer = now;
  }
}