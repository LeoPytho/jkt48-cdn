/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owensdev
* 𝘪𝘯𝘧𝘰: -
* 𝘺𝘵: https://youtube.com/owensdev
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/C9zCqhsLAuwEXkr4xwXEph

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

let handler = m => m;

let lastUpdate = null;

handler.before = async function (m, { conn }) {
    settings.gcDesc = true;
    if (settings.gcDesc === false) return;

    const jid = global.idgc;
    const now = new Date();
    const today = now.toISOString().split("T")[0];

    if (lastUpdate === today) return;

    lastUpdate = today;

    const daysOfWeek = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const currentDay = daysOfWeek[now.getDay()];

    let currentDescription = (await conn.groupMetadata(jid)).desc || "";

    const dayLine = `*Hari:* ${currentDay}`;

    if (!currentDescription.includes("*Hari:*")) {
        currentDescription = dayLine + "\n" + currentDescription;
    } else {
        currentDescription = currentDescription.replace(/(\*Hari:\*)\s\w+/, `$1 ${currentDay}`);
    }

    await conn.groupUpdateDescription(jid, currentDescription);

    const holiday = await displayNextHoliday();
    const groupName = `ℭ𝔬𝔤𝔞𝔫/ℭ𝔢𝔠𝔞𝔫¹ || 𝖦𝗋𝗈𝗎𝗉 𝖢𝗁𝖺𝗍\n\n𝖬𝖾𝗇𝗎𝗃𝗎: ${holiday}`;

    await conn.groupUpdateSubject(jid, groupName);
};

export default handler;

async function getIndonesianHolidays(year) {
    return [
        { name: "𝗧𝗮𝗵𝘂𝗻 𝗕𝗮𝗿𝘂 𝗠𝗮𝘀𝗲𝗵𝗶", date: new Date(year, 0, 1) },
        { name: "𝗛𝗮𝗿𝗶 𝗥𝗮𝘆𝗮 𝗡𝘆𝗲𝗽𝗶", date: new Date(year, 2, 22) },
        { name: "𝗛𝗮𝗿𝗶 𝗕𝗨𝗥𝗨𝗛 𝗜𝗻𝘁𝗲𝗿𝗻𝗮𝘀𝗶𝗼𝗻𝗮𝗹", date: new Date(year, 4, 1) },
        { name: "𝗛𝗮𝗿𝗶 𝗥𝗮𝘆𝗮 𝗪𝗮𝗶𝘀𝗮𝗸", date: new Date(year, 4, 22) },
        { name: "𝗛𝗮𝗿𝗶 𝗥𝗮𝘆𝗮 𝗜𝗱𝘂𝗹 𝗙𝗶𝘁𝗿𝗶", date: new Date(year, 3, 21) },
        { name: "𝗛𝗮𝗿𝗶 𝗞𝗲𝗺𝗲𝗿𝗱𝗲𝗸𝗮𝗮𝗻 𝗥𝗜", date: new Date(year, 7, 17) },
        { name: "𝗛𝗮𝗿𝗶 𝗥𝗮𝘆𝗮 𝗡𝗮𝘁𝗮𝗹", date: new Date(year, 11, 25) }
    ];
}

async function countdownToNextH(date) {
    const now = new Date();
    now.setHours(now.getHours() + 7);
    const diff = date - now;
    if (diff <= 0) return `telah berlalu.`;

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    return `${days} hari lagi`;
}

async function displayNextHoliday() {
    const year = new Date().getFullYear();
    const holidays = await getIndonesianHolidays(year);
    const now = new Date();
    now.setHours(now.getHours() + 7);
    const upcomingHoliday = holidays.find(holiday => holiday.date > now);

    if (upcomingHoliday) {
        return `${upcomingHoliday.name}\n dalam: ${await countdownToNextH(upcomingHoliday.date)}`;
    } else {
        const nextYearHolidays = await getIndonesianHolidays(year + 1);
        return `${nextYearHolidays[0].name}\n dalam ${await countdownToNextH(nextYearHolidays[0].date)}`;
    }
}