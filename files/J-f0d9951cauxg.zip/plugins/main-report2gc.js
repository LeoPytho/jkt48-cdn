let handler = async (m, { conn, text, command }) => {
    if (!text) throw `Silahkan Masukkan Laporannya`
    if (text.length < 10) throw `Kalo Mau Report Tuh Yg Niat!`
    if (text.length > 1000) throw `Lu Mau Curhat Apa Gimana Awowkowk.`
    let idgrup = "120363233041141434" //cukup angka saja
    let teks = `*「 ${command.toUpperCase()} 」*\n\nDari: *@${m.sender.split`@`[0]}*\n\nPesan: ${text}\n`
    conn.reply(`${idgrup}@g.us`, m.quoted ? teks + m.quoted.text : teks, null, {
        contextInfo: {
            mentionedJid: [m.sender]
        }
    })
    m.reply(`_✔️Masalah telah dilaporkan ke Grup_`)
}
handler.help = ['reporttogc'].map(v => v + ' <teks>')
handler.tags = ['main']
handler.command = /^(reporttogc)$/i
export default handler