const { generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia } = (await import('@adiwajshing/baileys')).default;
const { proto } = (await import('@adiwajshing/baileys')).default;
const jid = '@s.whatsapp.net';
let handler = async (m, { conn }) => {
  const ownerNumber = global.owner[0][0];
  const botNumber = global.nomorbot;
  const namaOwner = global.nameown;
  const ownerName = namaOwner;
  const botName = global.namebot;
  const saluran = global.saluran;
  let p = await conn.profilePictureUrl(ownerNumber + jid, 'image');
  let pi = await conn.profilePictureUrl(botNumber + jid, 'image');
  let caption = `*Halo Kak @${m.sender.split`@`[0]}*

*[ BERIKUT OWNER SAYA ]*
${ownerNumber} [ ${namaOwner} ]
`;
  async function image(url) {
    const { imageMessage } = await generateWAMessageContent({ image: { url } }, { upload: conn.waUploadToServer });
    return imageMessage;
  }
  let a = await image(p);
  let b = await image(pi);
  let msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: ``
            },
            footer: { text: "" },
            carouselMessage: {
              cards: [
                {
                  header: proto.Message.InteractiveMessage.Header.create({
                    title: `Staff - Numbers`,
                    subtitle: ownerName,
                    productMessage: {
                      product: {
                        productImage: a,
                        productId: "9116471035103640",
                        title: `${namaOwner}`,
                        description: "👑 Owner",
                        currencyCode: "👑 Owner",
                        priceAmount1000: "0",
                        retailerId: namaOwner,
                        url: saluran,
                        productImageCount: 1
                      },
                      businessOwnerJid: ownerNumber + jid
                    },
                    hasMediaAttachment: false
                  }),
                  body: { text: `
     「 \`\`\`[ OWNER FURINA ]\`\`\` 
     
*[ ${namaOwner} ]*
 - Jangan Chat Yang Aneh Aneh
 - Jangan Telpon/Call Owner 
 - Chat Langsung ke intinya aja
 - Ada Fitur Error? Laporin Kesini
` },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "cta_url",
                        buttonParamsJson: `{"display_text":"cʜᴀᴛ ᴏᴡɴᴇʀ","url":"https://wa.me/${ownerNumber}","merchant_url":"https://wa.me/${ownerNumber}"}`
                      },
                      {
                        name: "cta_call",
                        buttonParamsJson: `{"display_text":"ᴄᴏɴᴛᴀᴄᴛ ᴏᴡɴᴇʀ","phone_number":"+62 859-2165-5444"}`
                      }
                    ]
                  }
                },
                {
                  header: proto.Message.InteractiveMessage.Header.create({
                    title: `Bot - Number`,
                    subtitle: ownerName,
                    productMessage: {
                      product: {
                        productImage: b,
                        productId: "9116471035103640",
                        title: `${conn.user.name}`,
                        description: "🫧 Bots",
                        currencyCode: "🫧 Bots",
                        priceAmount1000: "0",
                        retailerId: botName,
                        url: saluran,
                        productImageCount: 1
                      },
                      businessOwnerJid: botNumber + jid
                    },
                    hasMediaAttachment: false
                  }),
                  body: {
                    text: `
          「 \`\`\`[ NOMOR FURINA ]\`\`\` 」
          
*[ ${botName} ]*
 - Jangan Spam Bot
 - Jangan Telpon/Call Bot 
 - Gausah Chat Yg Aneh Aneh
 - Sewa bot Dll Chat Owner
`
                  },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "cta_url",
                        buttonParamsJson: `{"display_text":"cʜᴀᴛ ғᴜʀɪɴᴀ","url":"https://wa.me/${botNumber}","merchant_url":"https://wa.me/${botNumber}"}`
                      },
                      {
                        name: "cta_call",
                        buttonParamsJson: `{"display_text":"ᴄᴏɴᴛᴀᴄᴛ ғᴜʀɪɴᴀ","phone_number":"${botNumber}"}`
                      }
                    ]
                  }
                }
              ],
              messageVersion: 1
            }
          }
        }
      }
    },
    { userJid: m.sender, quoted: m }
  );
  await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
};
handler.help = ['owner <my owner>'];
handler.tags = ['info'];
handler.command = /^(owner)$/i;
export default handler;