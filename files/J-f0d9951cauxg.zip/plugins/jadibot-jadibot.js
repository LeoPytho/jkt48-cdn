/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owensdev
* 𝘪𝘯𝘧𝘰: https://hanlala.in/ows/
* 𝘺𝘵: https://youtube.com/owensdev
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/C9zCqhsLAuwEXkr4xwXEph

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁
*/

const {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion, 
    MessageRetryMap,
    makeCacheableSignalKeyStore, 
    jidNormalizedUser,
    PHONENUMBER_MCC
   } = await import('@adiwajshing/baileys')
import moment from 'moment-timezone'
import NodeCache from 'node-cache'
import readline from 'readline'
import qrcode from "qrcode"
import crypto from 'crypto'
import fs from "fs"
import pino from 'pino';
import * as ws from 'ws';
const { CONNECTING } = ws
import { Boom } from '@hapi/boom'
import { makeWASocket } from '../lib/simple.js';

if (global.conns instanceof Array) console.log()
else global.conns = []
  
let handler = async (m, { conn: _conn, args, usedPrefix, command, isOwner }) => {
  const authFolderB = m.sender.split("@")[0]
if (command === "jadibot") {
  let parent = args[0] && args[0] == 'plz' ? _conn : await global.conn
  if (!((args[0] && args[0] == 'plz') || (await global.conn).user.jid == _conn.user.jid)) {
	throw `📌Perintah ini hanya dapat digunakan di bot utama\n\n wa.me/${global.conn.user.jid.split`@`[0]}?text=${usedPrefix}jadibot`
}

	//=====
  async function bbts() {
  //let authFolderB = m.sender.split('@')[0]

    if (!fs.existsSync("./database/jadibot/"+ authFolderB)){
        fs.mkdirSync("./database/jadibot/"+ authFolderB, { recursive: true });
    }
    args[0] ? fs.writeFileSync("./database/jadibot/" + authFolderB + "/creds.json", JSON.stringify(JSON.parse(Buffer.from(args[0], "base64").toString("utf-8")), null, '\t')) : ""
    
//--
const {state, saveState, saveCreds} = await useMultiFileAuthState(`./database/jadibot/${authFolderB}`)
const msgRetryCounterMap = (MessageRetryMap) => { };
const msgRetryCounterCache = new NodeCache()
const {version} = await fetchLatestBaileysVersion();
let phoneNumber = m.sender.split('@')[0]

const methodCodeQR = process.argv.includes("qr")
const methodCode = !!phoneNumber || process.argv.includes("code")
const MethodMobile = process.argv.includes("mobile")

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (texto) => new Promise((resolver) => rl.question(texto, resolver))

const connectionOptions = {
  logger: pino({ level: 'silent' }),
  printQRInTerminal: false,
  mobile: MethodMobile, 
  browser: [ "Ubuntu", "Chrome", "20.0.04" ], 
  auth: {
  creds: state.creds,
  keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
  },
  markOnlineOnConnect: true, 
  generateHighQualityLinkPreview: true, 
  getMessage: async (clave) => {
  let jid = jidNormalizedUser(clave.remoteJid)
  let msg = await store.loadMessage(jid, clave.id)
  return msg?.message || ""
  },
  msgRetryCounterCache,
  msgRetryCounterMap,
  defaultQueryTimeoutMs: undefined,   
  version
  }

//--
let conn = makeWASocket(connectionOptions)

if (methodCode && !conn.authState.creds.registered) {
    if (!phoneNumber) {

        process.exit(0);
    }
    let cleanedNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!Object.keys(PHONENUMBER_MCC).some(v => cleanedNumber.startsWith(v))) {

        process.exit(0);
    }
    setTimeout(async () => {
       let codeBot = await conn.requestPairingCode(cleanedNumber, pairingCode);
        codeBot = codeBot?.match(/.{1,4}/g)?.join("-") || codeBot;
          let kopi = {
                 "name": "cta_copy",
                 "buttonParamsJson": `{\"display_text\":\"ᴄoᴘʏ ᴄᴏᴅᴇ\",\"id\":\"123456789\",\"copy_code\":\"${codeBot}\"}`
              };
  await parent.sendMessage(m.chat, {text:codeBot, footer: wm, interactiveButtons: [ kopi ] }, {quoted: m})
        await parent.sendFile(m.chat, 'https://telegra.ph/file/f8587a5cc1056cb0bc630.jpg', 'qrcode.png', `﹎﹎﹎『 *ᴊ ᴀ ᴅ ɪ ʙ ᴏ ᴛ* 』﹎﹎﹎\n\n*ᴛ ᴜ ᴛ ᴏ ʀ ɪ ᴀ ʟ*\n\n1 *ᴛᴇᴋᴀɴ ᴛɪᴛɪᴋ 3 ᴅɪ ᴘᴏᴊᴏᴋ ᴀᴛᴀs, ʟᴀʟᴜ ᴘᴇɴᴄᴇᴛ ᴘᴇʀᴀɴɢᴋᴀᴛ ᴛᴀᴜᴛᴀɴ*\n2 *ᴛᴇᴋᴀɴ ᴛᴀᴜᴛᴋᴀɴ , ᴛᴀᴜᴛᴋᴀɴ ɴᴏᴍᴏʀ ᴛᴇʟᴘᴏɴ sᴀᴊᴀ*\n3 *ᴍᴀsᴜᴋᴀɴ ᴄᴏᴅᴇ ᴘᴀɪʀɪɴɢ ᴅɪ ᴀᴛᴀs*\n4 *ᴄᴏᴅᴇ ᴘᴀɪʀɪɴɢ ᴇxᴘɪʀᴇᴅ ᴅᴀʟᴀᴍ 30 ᴍᴇɴɪᴛ*\n`)
        rl.close();
    }, 3000);
}

conn.isInit = false

//---new
let isInit = true

async function connectionUpdate(update) {
    const { connection, lastDisconnect, isNewLogin, qr } = update
    if (isNewLogin) conn.isInit = true

    const code = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode;
        if (code && code !== DisconnectReason.loggedOut && conn?.ws.socket == null) {
      let i = global.conns.indexOf(conn)
      if (i < 0) return console.log(await creloadHandler(true).catch(console.error))
      delete global.conns[i]
      global.conns.splice(i, 1)

     if (code !== DisconnectReason.connectionClosed){ 
        parent.sendMessage(conn.user.jid, {text : `⚠️ Koneksi terputus...`}, { quoted: m }) //reconectar
    } else {
        parent.sendMessage(m.chat, {text : `⛔ *ᴋᴀᴍᴜ ʙᴇʀʜᴇɴᴛɪ ᴊᴀᴅɪʙᴏᴛ ᴊɪᴋᴀ ᴍᴀᴜ ᴊᴀᴅɪʙᴏᴛ ᴋᴇᴍʙᴀʟɪ ᴀɴᴅᴀ ʙɪsᴀ ᴄʜᴀᴛ ɴᴏ ʙᴏᴛ *ғᴜʀɪɴᴀ ᴀɪ* ᴋɪʀɪᴍ ɪᴅ ʏᴀɴɢ sᴀʏᴀ ᴋɪʀɪᴍ ᴅɪʜᴀʀᴀᴘᴋᴀɴ ᴊᴀɴɢᴀɴ ᴅɪ ᴜʙᴀʜ ᴄᴏᴅᴇ ᴛᴇʀsᴇʙᴜᴛ ᴀɢᴀʀ ʙɪsᴀ ᴛᴇʀsᴀᴍʙᴜɴɢ ᴛᴀɴpᴀ sᴄᴀɴ ᴋᴇᴍʙᴀʟɪ*`}, { quoted: m }) // session cerrada
    }
    }
    //----
    if (global.db.data == null) loadDatabase()

    if (connection == 'open') {
    conn.isInit = true
    global.conns.push(conn)
    let yeaa = await parent.sendMessage(m.chat, {text : args[0] ? `✅ *ʙᴇʀʜᴀsɪʟ ᴛᴇʀʜᴜʙᴜɴɢ*` : `〔 *sᴜᴋsᴇs ᴛᴇʀsᴀᴍʙᴜɴɢ* 〕\n\n*[ ɴᴏᴛᴇ ]*\n◇ *ʙᴇʙᴇʀᴀᴘᴀ ғɪᴛᴜʀ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪ ᴀᴋsᴇs ᴅɪ ʙᴏᴛ ᴄʟᴏɴᴇ*\n◇ *ᴊɪᴋᴀ ʙᴏᴛ ᴍᴀᴛɪ ᴜɴᴛᴜᴋ ᴍᴇɴʏᴀᴍʙᴜɴɢ ᴋᴇᴍʙᴀʟɪ ᴀɴᴅᴀ ʙɪsᴀ ᴍᴇɴɢᴜɴɢᴋᴀᴘᴋᴀɴ ɪᴅ ʏᴀɴɢ ᴅɪ ᴋɪʀɪᴍ ᴘʀɪᴠᴀᴛᴇ*\n\n\n◇ ᴏᴡɴᴇʀ : ${nameown || `FurinnTeam`}\n◇ ɴᴏᴍᴏʀ : ${nomorown || owner[0][0] || `-`}`}, { quoted: m })
    let ownerJid = `${owner[0][0]}@s.whatsapp.net`
        await parent.sendMessage(
          ownerJid,
          {
            text:
              '✅ Ada yang menjadi bot dan berhasil. Berikut data pengguna tersebut:\n' +
              `{
          userTag: @${m.sender.split("@")[0]}, 
          userJid: ${m.sender}, 
          chatId: ${m.chat +`~`+await conn.getName(m.chat)},
          folderId: ${authFolderB}
        }`, 
          },
          { quoted: m }
        )

    await sleep(5000)
    if (args[0]) return
		await parent.sendMessage(conn.user.jid, {text : `✅ *ᴋᴇᴛɪᴋᴀ ᴋᴀᴍᴜ ᴊᴀᴅɪʙᴏᴛ ᴛᴀɴᴘᴀ sᴄᴀɴ ᴄᴏᴅᴇ ᴀɴᴅᴀ ʙɪsᴀ sᴀʟɪɴᴋ ɪᴅ ʏᴀɴɢ sᴀʏᴀ ᴋɪʀɪᴍ ᴋᴀɴ ᴋᴇ ᴘʀɪᴠᴀᴛᴇ ᴀɴᴅᴀ*`}, { quoted: yeaa })
		parent.sendMessage(conn.user.jid, {text : usedPrefix + command + " " + Buffer.from(fs.readFileSync("./database/jadibot/" + authFolderB + "/creds.json"), "utf-8").toString("base64")}, { quoted: m })
	  }
 
  }

  setInterval(async () => {
    if (!conn.user) {
      try { conn.ws.close() } catch { }
      conn.ev.removeAllListeners()
      let i = global.conns.indexOf(conn)
      if (i < 0) return
      delete global.conns[i]
      global.conns.splice(i, 1)
    }}, 60000)
    

	
let handler = await import('../handler.js')
let creloadHandler = async function (restatConn) {
try {
const Handler = await import(`../handler.js?update=${Date.now()}`).catch(console.error)
if (Object.keys(Handler || {}).length) handler = Handler
} catch (e) {
console.error(e)
}
if (restatConn) {
try { conn.ws.close() } catch { }
conn.ev.removeAllListeners()
conn = makeWASocket(connectionOptions)
isInit = true
}

if (!isInit) {
conn.ev.off('messages.upsert', conn.handler)
conn.ev.off('group-participants.update', conn.participantsUpdate)
conn.ev.off('groups.update', conn.groupsUpdate)
conn.ev.off('message.delete', conn.onDelete)
conn.ev.off('call', conn.onCall)
conn.ev.off('connection.update', conn.connectionUpdate)
conn.ev.off('creds.update', conn.credsUpdate)
}
  
conn.welcome = '❖━━━━━━[ ᴡᴇʟᴄᴏᴍᴇ ]━━━━━━❖\n\n┏––––––━━━━━━━━•\n│☘︎ @subject\n┣━━━━━━━━┅┅┅\n│( 👋 Hallo @user)\n├[ ɪɴᴛʀᴏ ]—\n│ ɴᴀᴍᴀ: \n│ ᴜᴍᴜʀ: \n│ ɢᴇɴᴅᴇʀ:\n┗––––––━━┅┅┅\n\n––––––┅┅ ᴅᴇsᴄʀɪᴘᴛɪᴏɴ ┅┅––––––\n@desc'
conn.bye = '❖━━━━━━[ ʟᴇᴀᴠɪɴɢ ]━━━━━━❖\n𝚂𝚊𝚢𝚘𝚗𝚊𝚛𝚊𝚊 @user 👋😔'
conn.spromote = '@user Sekarang jadi admin!'
 conn.sdemote = '@user Sekarang bukan lagi admin!'

conn.handler = handler.handler.bind(conn)
conn.participantsUpdate = handler.participantsUpdate.bind(conn)
conn.groupsUpdate = handler.groupsUpdate.bind(conn)
conn.onDelete = handler.deleteUpdate.bind(conn)
conn.connectionUpdate = connectionUpdate.bind(conn)
conn.credsUpdate = saveCreds.bind(conn, true)

conn.ev.on('messages.upsert', conn.handler)
conn.ev.on('group-participants.update', conn.participantsUpdate)
conn.ev.on('groups.update', conn.groupsUpdate)
conn.ev.on('message.delete', conn.onDelete)
conn.ev.on('connection.update', conn.connectionUpdate)
conn.ev.on('creds.update', conn.credsUpdate)
isInit = false
return true
}
creloadHandler(false)
}
bbts()
}
if (command === "listjadibot" || command === "ljb") {
const data = await fs.readFileSync("./database/jadibot/" + authFolderB + "/creds.json");
let json = JSON.parse(data);
if (!json[0]) throw `[❗] Tɪᴅᴀᴋ ᴀᴅᴀ ʏᴀɴɢ ᴍᴇɴᴊᴀᴅɪ ʙᴏᴛ`

if (json) {
let teks = `*[ List Cloning Bot ]*\n\n`
let no = 1
for (let bot of json) {
teks += `${no++}). ${await conn.getName(bot) || 'no name'} (${bot})\n`
}
m.reply(teks)
}
}
}

handler.help = ['jadibot','listjadibot']
handler.tags = ['jadibot']
handler.command = ['jadibot', 'listjadibot', 'ljb']
handler.premium = true

export default handler