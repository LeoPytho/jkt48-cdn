let handler = async (m, { conn, text, command }) => {
    if (!text) throw `Silahkan Masukkan Laporannya`
    if (text.length < 10) throw `Kalo Mau Report Tuh Yg Niat!`
    if (text.length > 1000) throw `Lu Mau Curhat Apa Gimana Awowkowk.`
    let gc = global.idgrup
    let teks = `*「 ${command.toUpperCase()} 」*\n\nDari: *@${m.sender.split`@`[0]}*\nPesan: ${text}\n`
    conn.reply(gc, m.quoted ? teks + m.quoted.text : teks, null, {
        contextInfo: {
            mentionedJid: [m.sender]
        }
    })
    m.reply(`_✔️Pesan telah dilaporkan_`)
}
handler.help = ['report','request'].map(v => v + ' <teks>')
handler.tags = ['info','main']
handler.command = /^(report|request|req)$/i
export default handler