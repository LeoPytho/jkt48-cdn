import axios from 'axios';

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    if (!text) {
        throw m.reply(`[❗] Masukkan query!\n\nContoh: ${usedPrefix + command} jj furina`);
    }

    m.reply('⏳ Tunggu sebentar...');
    try {
        const result = await tiktoks(text);
        const { title, no_watermark } = result;

        const caption = `*🫧 TikTok - Search*\n${title}\n`;

        conn.bubbleVid(
            m.chat,
            no_watermark,
            caption,
            wm,
            [
            { buttonId: "/ttsearch " + text, buttonText: { displayText: "➡️ ɴᴇxᴛ ᴠɪᴅᴇᴏ" }, type: 1 }
        ],
        m
        );
    } catch (err) {
        m.reply(`[❗] Terjadi kesalahan:\n${err}`);
    }
};

handler.help = ['ttsearch'];
handler.tags = ['downloader'];
handler.command = /^(ttsearch|tiktoksearch)$/i;
handler.limit = true;
handler.register = true;

export default handler;

async function tiktoks(query) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios({
                method: 'POST',
                url: 'https://tikwm.com/api/feed/search',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Cookie': 'current_language=en',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
                },
                data: new URLSearchParams({
                    keywords: query,
                    count: 10,
                    cursor: 0,
                    HD: 1,
                }).toString(),
            });

            const videos = response.data.data.videos;
            if (!videos || videos.length === 0) {
                reject("Video tidak ditemukan untuk query tersebut.");
                return;
            }

            const randomIndex = Math.floor(Math.random() * videos.length);
            const selectedVideo = videos[randomIndex];

            resolve({
                title: selectedVideo.title,
                cover: selectedVideo.cover,
                origin_cover: selectedVideo.origin_cover,
                no_watermark: selectedVideo.play,
                watermark: selectedVideo.wmplay,
                music: selectedVideo.music,
            });
        } catch (error) {
            reject(error.message || 'Terjadi kesalahan saat memproses permintaan.');
        }
    });
}