let {
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = (await import('@adiwajshing/baileys')).default
let handler = async function (m, { conn, text, usedPrefix }) {
let cap = `[ 📍 R U L E S  F O R  U S I N G ]`
let ruless = `*▬▭▬▭▬▭▬▭▬▭▬▭▬*
*${kyzryzz}🇬🇧 Eɴɢʟɪsʜ:${kyzryzz}*
 _ʜɪ sɪs, ʙᴇғᴏʀᴇ ɢᴏɪɴɢ ᴛᴏ ᴛʜᴇ ғᴇᴀᴛᴜʀᴇs ᴍᴇɴᴜ,ᴘʟᴇᴀsᴇ ʀᴇᴀᴅ ᴛʜᴇ ʀᴜʟᴇs ғᴏʀ ᴜsɪɴɢ ᴛʜᴇ ʙᴏᴛ_
*${kyzryzz}🇮🇩 Iɴᴅᴏɴᴇsɪᴀɴ:${kyzryzz}*
 _ʜɪ ᴋᴀᴋ, sᴇʙᴇʟᴜᴍ ᴍᴇɴᴜᴊᴜ ᴋᴇ ᴍᴇɴᴜ ғɪᴛᴜʀ, ᴅɪ ᴍᴏʜᴏɴ ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴀᴄᴀ ᴘᴇʀᴀᴛᴜʀᴀɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ_
 *▬▭▬▭▬▭▬▭▬▭▬▭▬*

*${kyzryzz}⫹❰⫺ 𝗧 𝗛 𝗘  𝗥 𝗨 𝗟 𝗘 𝗦 ⫹❱⫺${kyzryzz}*

*${kyzryzz}🇬🇧 𝖤ɴɢʟɪsʜ:${kyzryzz}*
> 𝟷. sᴘᴀᴍ ʙᴏᴛs ᴀʀᴇ ᴘʀᴏʜɪʙɪᴛᴇᴅ
> 𝟸. ᴄᴀʟʟɪɴɢ ʙᴏᴛs ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ
> 𝟹. ᴄᴀʟʟɪɴɢ ᴏᴡɴᴇʀ ɴᴜᴍʙᴇʀ ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ
> 𝟺. sᴘᴀᴍ ᴛᴏ ɴᴏ ᴏᴡɴᴇʀ ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ

*${kyzryzz}🇮🇩 𝖨ɴᴅᴏɴᴇsɪᴀɴ:${kyzryzz}*
> 𝟷. ᴅɪ ʟᴀʀᴀɴɢ sᴘᴀᴍ ʙᴏᴛ
> 𝟸. ᴅɪ ʟᴀʀᴀɴɢ ᴍᴇɴᴇʟғᴏɴ ʙᴏᴛ
> 𝟹. ᴅɪ ʟᴀʀᴀɴɢ ᴍᴇɴᴇʟғᴏɴ ɴᴏᴍᴏʀ ᴏᴡɴᴇʀ
> 𝟺. ᴅɪ ʟᴀʀᴀɴɢ sᴘᴀᴍ ᴋᴇ ɴᴏᴍᴏʀ ᴏᴡɴᴇʀ!
*▬▭▬▭▬▭▬▭▬▭▬▭▬*

`
let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: ruless,
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: cap, 
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "", 
                        subtitle: "", 
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
                            {
                "name": "quick_reply",
                "buttonParamsJson": "{\"display_text\":\"ᴋᴇᴍʙᴀʟɪ ᴋᴇ ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ 🫧\",\"id\":\".menu\"}"
              },             
              {
                "name": "quick_reply",
                "buttonParamsJson": "{\"display_text\":\"ᴛᴜᴛᴏʀɪᴀʟ ᴘᴇɴɢɢᴜɴᴀᴀɴ 💙\",\"id\":\".tutorial\"}"
              },             
               {
                 "name": "cta_url",
                 "buttonParamsJson": "{\"display_text\":\"ɪɴғᴏ ʙᴏᴛ ғᴜʀɪɴᴀ - ᴀɪ 🌐\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://www.google.com\"}"
              }
           ],
          }), 
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterName: "🔮 Powered By OᴡᴇɴꜱDᴇᴠ",
              newsletterJid: "120363247149539361@newsletter",
              serverMessageId: 143
            }
          }
        })
    }
  }
}, {quoted:m})
await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}

handler.help = ['rules']
handler.tags = ['main', 'info']
handler.command = /^(rules|rule)$/i
export default handler;  