import util from "util";
import path from "path";

let handler = async (m, { conn }) => {
 let salam = pickRandom(vn.salam) 
	conn.sendFile(m.chat, `${salam}`, "salam.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	});
};
handler.customPrefix = /(ass?alam|اَلسَّلاَمُ عَلَيْكُمْ|السلام عليکم)/i;
handler.command = new RegExp()

export default handler;
