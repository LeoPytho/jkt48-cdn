import { caklontong } from '@bochilteam/scraper'
import similarity from 'similarity'

let timeout = 130000
let xpReward = 10000
let threshold = 0.73

let handler = async (m, { conn, usedPrefix }) => {
  conn.caklontong = conn.caklontong || {}
  let id = m.chat

  if (id in conn.caklontong) {
    return conn.reply(m.chat, 'Masih ada soal yang belum dijawab!', conn.caklontong[id][0])
  }

  let json = await caklontong()
  let soal = json.soal
  let jawaban = json.jawaban
  let deskripsi = json.deskripsi

  let caption = `
🧠 *Cak Lontong Quiz*
📄 ${soal}
🕒 Timeout: ${(timeout / 1000).toFixed(0)} detik
💬 Balas pesan ini untuk menjawab.
📌 Ketik *.calo* untuk hint dan *nyerah* untuk menyerah.`.trim()

  conn.caklontong[id] = [
    await conn.reply(m.chat, caption, m),
    json,
    xpReward,
    setTimeout(() => {
      if (conn.caklontong[id]) {
        conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya adalah *${jawaban}*\n${deskripsi}`, conn.caklontong[id][0])
        delete conn.caklontong[id]
      }
    }, timeout)
  ]
}

handler.before = async (m, { conn }) => {
  conn.caklontong = conn.caklontong || {}
  let id = m.chat
  if (!conn.caklontong[id]) return
  if (!m.quoted) return
  if (!m.quoted.id || !m.quoted.id.includes(conn.caklontong[id][0].id)) return
  if (!m.text) return

  let json = conn.caklontong[id][1]
  let user = db.data.users[m.sender]

  if (m.text.toLowerCase() === 'nyerah') {
    clearTimeout(conn.caklontong[id][3])
    await conn.reply(m.chat, `🫡 Kamu menyerah.\nJawabannya: *${json.jawaban}*\n${json.deskripsi}`, m)
    delete conn.caklontong[id]
  } else if (m.text.toLowerCase().trim() === json.jawaban.toLowerCase().trim()) {
    user.exp += conn.caklontong[id][2]
    clearTimeout(conn.caklontong[id][3])
    await conn.reply(m.chat, `🎉 *Benar!* +${conn.caklontong[id][2]} XP\n${json.deskripsi}`, m)
    delete conn.caklontong[id]
  } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
    await conn.reply(m.chat, '🔥 *Dikit lagi!*', m)
  } else {
    await conn.sendMessage(m.chat, {
      react: {
        text: '❌',
        key: m.key
      }
    })
  }
}

handler.help = ['caklontong']
handler.tags = ['game']
handler.command = /^caklontong$/i

export default handler