import { tebakkata } from '@bochilteam/scraper'

let timeout = 60000
let poin = 4999

let handler = async (m, { conn, usedPrefix }) => {
  conn.tebakkata = conn.tebakkata || {}
  let id = m.chat

  if (id in conn.tebakkata) {
    return conn.reply(m.chat, '❗masih ada soal belum terjawab di chat ini', conn.tebakkata[id][0])
  }

  const json = await tebakkata()
  let caption = `
🧠 *tebak kata*
📄 ${json.soal}
🕒 ${(timeout / 1000).toFixed(0)} detik
🎁 bonus: ${poin} XP
📝 balas pesan ini untuk menjawab
📌 ketik *.teka* untuk hint dan *nyerah* untuk menyerah
`.trim()

  let soal = await conn.reply(m.chat, caption, m)

  conn.tebakkata[id] = [
    soal,
    json,
    poin,
    setTimeout(() => {
      if (conn.tebakkata[id]) {
        conn.reply(m.chat, `⏰ *waktu habis!*\njawabannya adalah *${json.jawaban}*`, conn.tebakkata[id][0])
        delete conn.tebakkata[id]
      }
    }, timeout)
  ]
}

handler.before = async (m, { conn }) => {
  conn.tebakkata = conn.tebakkata || {}
  let id = m.chat
  if (!conn.tebakkata[id]) return
  if (!m.quoted) return
  if (!m.quoted.id || !m.quoted.id.includes(conn.tebakkata[id][0].id)) return
  if (!m.text) return

  let json = conn.tebakkata[id][1]
  let user = db.data.users[m.sender] || {}
  if (!user.exp) user.exp = 0

  if (m.text.toLowerCase() === 'nyerah') {
    clearTimeout(conn.tebakkata[id][3])
    await conn.reply(m.chat, `😢 kamu menyerah.\njawabannya: *${json.jawaban}*`, m)
    delete conn.tebakkata[id]
  } else if (m.text.toLowerCase().trim() === json.jawaban.toLowerCase().trim()) {
    user.exp += conn.tebakkata[id][2]
    clearTimeout(conn.tebakkata[id][3])
    await conn.reply(m.chat, `🎉 *benar!* +${conn.tebakkata[id][2]} XP`, m)
    delete conn.tebakkata[id]
  } else {
    await conn.sendMessage(m.chat, {
      react: {
        text: '❌',
        key: m.key
      }
    })
  }
}

handler.help = ['tebakkata']
handler.tags = ['game']
handler.command = /^tebakkata$/i

export default handler