let handler = async (m, { conn }) => {
    conn.tebaklogo = conn.tebaklogo || {};
    let id = m.chat;
    if (!(id in conn.tebaklogo)) return;
    let jawaban = conn.tebaklogo[id][1].jawaban;
    conn.reply(m.chat, '```' + jawaban.replace(/[AIUEOaiueo]/ig, '_') + '```', m);
};

handler.command = /^hlog$/i;
handler.limit = true;

export default handler;