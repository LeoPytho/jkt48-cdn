const handler = async (m, { conn, command, usedPrefix }) => {
  const hijriMonths = [
    { month: "Muharram", clue: "Bulan pertama dalam kalender Hijriah." },
    { month: "Safar", clue: "Bulan kedua dalam kalender Hijriah." },
    { month: "Rabi'ul Awal", clue: "Bulan ketiga dalam kalender Hijriah, bulan kelahiran Nabi Muhammad." },
    { month: "Rabi'ul Akhir", clue: "Bulan keempat dalam kalender Hijriah." },
    { month: "Jumada al-Awwal", clue: "Bulan kelima dalam kalender Hijriah." },
    { month: "Jumada al-Akhir", clue: "Bulan keenam dalam kalender Hijriah." },
    { month: "Rajab", clue: "Bulan ketujuh dalam kalender Hijriah." },
    { month: "Sha'ban", clue: "Bulan kedelapan dalam kalender Hijriah." },
    { month: "Ramadhan", clue: "Bulan kesembilan dalam kalender Hijriah, bulan puasa." },
    { month: "Shawwal", clue: "Bulan kesepuluh dalam kalender Hijriah, bulan setelah Ramadhan." },
    { month: "Dhul-Qi'dah", clue: "Bulan kesebelas dalam kalender Hijriah." },
    { month: "Dhul-Hijjah", clue: "Bulan kedua belas dalam kalender Hijriah, bulan haji." },
  ];

  if (!conn.tebakHijriah) conn.tebakHijriah = {};

  if (m.sender in conn.tebakHijriah) {
    m.reply("Kamu masih punya pertanyaan yang belum selesai!");
    return;
  }

  const randomClue = hijriMonths[Math.floor(Math.random() * hijriMonths.length)];
  conn.tebakHijriah[m.sender] = {
    answer: randomClue.month.toLowerCase(),
    timeout: setTimeout(() => {
      delete conn.tebakHijriah[m.sender];
      m.reply(`Waktu habis! Jawabannya adalah *${randomClue.month}*.`);
    }, 30 * 1000), // 30 detik
  };

  m.reply(
    `*Tebakan Kalender Hijriah*\n\nClue: ${randomClue.clue}\n\nKetik jawabanmu dalam waktu 30 detik!`
  );
};

handler.before = async (m, { conn }) => {
  if (!conn.tebakHijriah || !(m.sender in conn.tebakHijriah)) return;

  const game = conn.tebakHijriah[m.sender];
  if (m.text.toLowerCase() === game.answer.toLowerCase()) {
    clearTimeout(game.timeout);
    delete conn.tebakHijriah[m.sender];
    m.reply(`Selamat! Jawaban kamu benar: *${game.answer}*.`);
  } else {
    m.reply("Jawaban salah! Coba lagi.");
  }
};

handler.help = ["tebakbulan"];
handler.tags = ["game"];
handler.command = /^(tebakbulan|tebakhijriah)$/i;
handler.limit = false;

export default handler;