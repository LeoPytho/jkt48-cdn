import fetch from 'node-fetch'

let timeout = 60000

let handler = async (m, { conn }) => {
  conn.tebakgambar = conn.tebakgambar || {}
  let id = m.chat
  if (id in conn.tebakgambar) {
    conn.reply(m.chat, 'Masih ada soal yang belum dijawab.', conn.tebakgambar[id][0])
    return
  }

  let res = await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
  let src = await res.json()
  let json = src[Math.floor(Math.random() * src.length)]

  let clue = json.jawaban.replace(/[aiueo]/gi, '_')
  let caption = `*[ TEBAK GAMBAR ]*
*• Timeout :* 60 detik
*• Clue :* ${clue}

Balas pesan ini untuk menjawab
Ketik *nyerah* untuk menyerah`.trim()

  let msg = await conn.sendMessage(m.chat, {
    image: { url: json.img },
    caption: caption
  }, { quoted: m })

  conn.tebakgambar[id] = [
    msg,
    json,
    setTimeout(() => {
      if (conn.tebakgambar[id]) {
        conn.sendMessage(m.chat, {
          text: `Game Over !!
Waktu habis!

Jawaban: *${json.jawaban}*`
        }, { quoted: m })
        delete conn.tebakgambar[id]
      }
    }, timeout)
  ]
}

handler.before = async (m, { conn }) => {
  conn.tebakgambar = conn.tebakgambar || {}
  let id = m.chat
  if (!m.text) return
  if (m.isCommand) return
  if (!conn.tebakgambar[id]) return

  let json = conn.tebakgambar[id][1]
  let reward = db.data.users[m.sender]

  if (m.text.toLowerCase() === 'nyerah' || m.text.toLowerCase() === 'surender') {
    clearTimeout(conn.tebakgambar[id][2])
    conn.sendMessage(m.chat, {
      text: `Game Over !!
Alasan: *${m.text}*

Jawaban: *${json.jawaban}*`
    }, { quoted: conn.tebakgambar[id][0] })
    delete conn.tebakgambar[id]
  } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
    reward.money += 10000
    reward.limit += 10
    clearTimeout(conn.tebakgambar[id][2])
    conn.sendMessage(m.chat, {
      text: `Benar! 🎉

+10.000 Money 💰
+10 Limit 📈

Soal berikutnya...`
    }, { quoted: conn.tebakgambar[id][0] })
    delete conn.tebakgambar[id]
    await conn.appendTextMessage(m, '.tebakgambar', m.chatUpdate)
  } else {
    conn.sendMessage(m.chat, {
      react: {
        text: '❌',
        key: m.key
      }
    })
  }
}

handler.help = ['tebakgambar']
handler.tags = ['game']
handler.command = ['tebakgambar']
handler.group = false

export default handler