import axios from "axios"
import uploadImage from "../lib/uploadImage.js"

let handler = async (m, { conn, usedPrefix }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ""
  if (!mime) throw "Fotonya?"
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`
  let img = await q.download()
  let upld = await uploadImage(img)
  await m.reply(wait)

  let res = await axios.get(
    APIs.ft + `/anime/whatsanime?buffer=${encodeURIComponent(upld)}`
  )
  let json = res.data.result
  let ult = json.info.media
  let card = []

  for (let {
    title,
    type,
    format,
    status,
    startDate,
    endDate,
    season,
    episodes,
    duration,
    source,
    coverImage,
    genres,
    synonyms,
    isAdult,
    siteUrl
  } of ult) {
    card.push({
      image: { url: coverImage.large },
      title: `*${title.romaji || "unknown"} (${title.native || "unknown"})*\n`,
      caption:
        `*Type :* ${type || "unknown"}\n` +
        `*Format :* ${format || "unknown"}\n` +
        `*Status :* ${status || "unknown"}\n` +
        `*StartDate :* ${startDate.day + "-" + startDate.month + "-" + startDate.year || "unknown"}\n` +
        `*EndDate :* ${endDate.day + "-" + endDate.month + "-" + endDate.year || "unknown"}\n` +
        `*SeasonReleased :* ${season || "unknown"}\n` +
        `*Episodes :* ${episodes || "unknown"}\n` +
        `*Duration :* ${duration + "Min" || "null"}\n` +
        `*Source :* ${source || "unknown"}\n` +
        `*Genre :* ${genres.join(", ") || "unknown"}\n` +
        `*Synonim :* ${synonyms[0] || "unknown"}\n` +
        `*isAdult :* ${isAdult}\n` +
        `*SourceUrl :* ${siteUrl || "unknown"}\n`,
      footer: `> ${wm}`,
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🔍 Source",
            url: siteUrl
          })
        }
      ]
    })
  }

  await conn.sendMessage(
    m.chat,
    {
      text: "",
      footer:
        `📝: Data Terkadang Tidak Sesuai, Jadi Mending Lu Tanya Aja Ke Temen Wibu Lu, Dripada Ngandelin Gw`,
      cards: [...card]
    },
    { quoted: m }
  )
}
handler.help = ["whatanime"]
handler.tags = ["anime"]
handler.command = /^(wait|whatanime|source)$/i
handler.limit = true
export default handler