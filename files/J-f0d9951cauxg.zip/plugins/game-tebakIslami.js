let handler = async (m, { conn, command, usedPrefix }) => {
  const islamicClues = [
    { name: "Nabi Muhammad", clue: "Nabi terakhir dan rasul penutup dalam Islam." },
    { name: "Al-Qur'an", clue: "Kitab suci umat Islam yang diturunkan kepada Nabi Muhammad." },
    { name: "Ka'bah", clue: "Bangunan suci yang menjadi kiblat umat Islam dalam shalat." },
    { name: "Shalat", clue: "Ibadah wajib yang dilakukan lima kali sehari oleh umat Islam." },
    { name: "Haji", clue: "Ibadah ke Tanah Suci yang merupakan rukun Islam kelima." },
    { name: "Zakat", clue: "Kewajiban memberikan sebagian harta untuk yang berhak menerimanya." },
    { name: "Ramadhan", clue: "Bulan suci di mana umat Islam berpuasa selama sebulan penuh." },
    { name: "Jibril", clue: "Malaikat yang menyampaikan wahyu kepada para nabi." },
    { name: "Masjid", clue: "Tempat ibadah umat Islam yang sering digunakan untuk shalat berjamaah." },
    { name: "Surga", clue: "Tempat balasan bagi orang-orang yang beriman dan beramal saleh." },
    { name: "Puasa", clue: "Menahan diri dari makan, minum, dan hal-hal tertentu sejak terbit fajar hingga terbenam matahari." },
    { name: "Lailatul Qadar", clue: "Malam yang lebih baik dari seribu bulan." },
    { name: "Nabi Adam", clue: "Manusia pertama yang diciptakan Allah." },
    { name: "Nabi Ibrahim", clue: "Nabi yang mendapat gelar kekasih Allah." },
    { name: "Nabi Musa", clue: "Nabi yang dikenal dengan mukjizat membelah laut." },
    { name: "Nabi Isa", clue: "Nabi yang lahir tanpa seorang ayah." },
    { name: "Taurat", clue: "Kitab suci yang diturunkan kepada Nabi Musa." },
    { name: "Injil", clue: "Kitab suci yang diturunkan kepada Nabi Isa." },
    { name: "Zabur", clue: "Kitab suci yang diturunkan kepada Nabi Dawud." },
    { name: "Mekah", clue: "Kota kelahiran Nabi Muhammad." },
    { name: "Madinah", clue: "Kota tempat Nabi Muhammad hijrah." },
    { name: "Isra' Mi'raj", clue: "Perjalanan Nabi Muhammad dari Masjidil Haram ke Sidratul Muntaha." },
    { name: "Hijriyah", clue: "Nama kalender Islam." },
    { name: "Masjid Quba", clue: "Masjid pertama yang dibangun dalam Islam." },
    { name: "Nabi Sulaiman", clue: "Nabi yang bisa berbicara dengan binatang." },
    { name: "Israfil", clue: "Malaikat yang bertugas meniup sangkakala pada hari kiamat." },
    { name: "Raqib dan Atid", clue: "Malaikat yang mencatat amal baik dan buruk manusia." },
    { name: "Shafa dan Marwah", clue: "Dua bukit yang dilalui saat melakukan sa'i dalam ibadah haji." },
    { name: "Bulan Muharram", clue: "Bulan pertama dalam kalender Hijriyah." },
    { name: "Ibadah Umrah", clue: "Ibadah yang mirip haji tetapi waktunya lebih fleksibel." },
    { name: "Jihad", clue: "Berjuang di jalan Allah dengan sungguh-sungguh." },
    { name: "Sedekah", clue: "Memberikan harta dengan ikhlas tanpa ada kewajiban tertentu." },
    { name: "Doa", clue: "Permohonan kepada Allah untuk memohon sesuatu." },
    { name: "Takbir", clue: "Ucapan 'Allahu Akbar' yang sering dilakukan saat sholat." },
    { name: "Tasbih", clue: "Ucapan 'Subhanallah' sebagai bentuk memuji Allah." },
    { name: "Tawaf", clue: "Mengelilingi Ka'bah sebanyak tujuh kali." },
    { name: "Nabi Yunus", clue: "Nabi yang pernah ditelan ikan paus." },
    { name: "Iblis", clue: "Makhluk yang menolak sujud kepada Nabi Adam." },
    { name: "Syahadat", clue: "Pernyataan keimanan kepada Allah dan Nabi Muhammad." },
    { name: "Wudhu", clue: "Cara bersuci sebelum melaksanakan shalat." },
    { name: "Tayammum", clue: "Cara bersuci menggunakan debu sebagai pengganti wudhu." },
    { name: "Adzan", clue: "Panggilan untuk melaksanakan shalat." },
    { name: "Iqamah", clue: "Panggilan untuk memulai shalat berjamaah." },
    { name: "I'tikaf", clue: "Berkhalwat di masjid untuk mendekatkan diri kepada Allah." },
    { name: "Fidyah", clue: "Kompensasi bagi orang yang tidak mampu berpuasa." },
    { name: "Qadha", clue: "Mengganti puasa yang ditinggalkan di luar bulan Ramadhan." },
    { name: "Khatib", clue: "Orang yang menyampaikan khutbah dalam shalat Jumat." },
    { name: "Asmaul Husna", clue: "Nama-nama Allah yang indah dan mulia." },
    { name: "Alhamdulillah", clue: "Ucapan syukur kepada Allah." },
    { name: "Bismillah", clue: "Ucapan sebelum memulai sesuatu dalam Islam." },
  ];

  if (!conn.tebakIslam) conn.tebakIslam = {};

  if (m.sender in conn.tebakIslam) {
    m.reply("Kamu masih punya pertanyaan yang belum selesai!");
    return;
  }

  const randomClue = islamicClues[Math.floor(Math.random() * islamicClues.length)];
  conn.tebakIslam[m.sender] = {
    answer: randomClue.name.toLowerCase(),
    timeout: setTimeout(() => {
      delete conn.tebakIslam[m.sender];
      m.reply(`Waktu habis! Jawabannya adalah *${randomClue.name}*.`);
    }, 30 * 1000), // 30 detik
  };

  m.reply(
    `*Tebak-Tebakan Islami*\n\nClue: ${randomClue.clue}\n\nKetik jawabanmu dalam waktu 30 detik!`
  );
};

handler.before = async (m, { conn }) => {
  if (!conn.tebakIslam || !(m.sender in conn.tebakIslam)) return;

  const game = conn.tebakIslam[m.sender];
  if (m.text.toLowerCase() === game.answer) {
    clearTimeout(game.timeout);
    delete conn.tebakIslam[m.sender];
    m.reply(`Selamat! Jawaban kamu benar: *${game.answer}*.`);
  } else {
    m.reply("Jawaban salah! Coba lagi.");
  }
};

handler.help = ["tebakkanislami","tebakislami"];
handler.tags = ["game","islami"];
handler.command = /^(tebakkanislami|tebakislami|tebak)$/i;

export default handler;