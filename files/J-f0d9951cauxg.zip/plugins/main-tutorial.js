const { generateWAMessageFromContent, proto } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn }) => {

let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: "Tutorial Penggunaan Bot :\n\n1. Semua Fitur Bot Menggunakan Prefix Yaitu Harus Menggunakan Titik (.) Di Awal Perintah Agar Perintahnya Aktif.\nContoh: Ketik .allmenu\n\n2. Jika Kamu Ingin Mencari Sesuatu Kamu Bisa Lihat Di List Menu Internet, Kamu Bisa Menemukan Seperti Tiktok search.\nContoh Penggunaan: Ketik .ttsearch Trending hari ini\n\n3. Jika Ingin Mendownload Seperti Video, Reels Fb/Ig, Story Ig, Dan Lain Sebagainya Kamu Bisa Melihat Di List Menu bagian downloader.\nContoh Penggunaan: Ketik .instagram https://www.instagram.com/reel/****\n\n4. Jika Ingin Mengubah Ataupun Menggunakan Fitur Yang Berhubungan Dengan Media Seperti Audio, Foto, Dan Video Kamu Harus Balas Chatnya Dan Ketik Perintahnya\nContoh Penggunaan: Balas/Reply Vn Nya Terus Ketik .tomp3\n\n5. Jika Kamu Kehabisan Limit Kamu Bisa Membelinya Dengan Cara Mengetik .buylimit 1. Kamu Tidak Punya Koin?, Kamu Bisa Memainkan Game Yang Ada Di Menu HaveFun, Jika Kamu Bisa Menjawab/Memenangkan Game Tersebut, Kamu Akan Mendapatkan Exp, Koin, Dan Limit.\n\n_Note: Jika Masih Tidak Mengerti Hubungin Owner Dengan Cara Mengetik .owner_"
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "Klik Tombol Dibawah Untuk Memulai Bot"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "[ 📍 T U T O R I A L ]\n",
            subtitle: "tutor pemula",
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
{
                "name": "quick_reply",
                "buttonParamsJson": "{\"display_text\":\"ᴛᴀᴍᴘɪʟᴋᴀɴ sᴇᴍᴜᴀ ᴍᴇɴᴜ\",\"id\":\".menu all\"}"
              },
{
                "name": "quick_reply",
                "buttonParamsJson": "{\"display_text\":\"ᴘᴇᴍɪʟɪᴋ ʙᴏᴛ ɪɴi\",\"id\":\".owner\"}"
              },            
              {
                 "name": "cta_url",
                 "buttonParamsJson": `{\"display_text\":\"${footer}\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://www.google.com\"}`
              }, 
           ],
          })
        })
    }
  }
}, {quoted: m})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}               
        
handler.help = ['tutorial']
handler.tags = ['main']
handler.command = /^(tutor(ial)?)$/i

handler.register = false

export default handler
