let handler = async (m, { conn, text, usedPrefix, command }) => {
    let input = `[❕] Wrong Input\nExample: ${usedPrefix + command} furina`;
    if (!text) return m.reply(input);

    m.react("⏱");

    let result = await pinterest(text);
    let cmd = usedPrefix + command + ' ' + text;

    const buttons = [
        {
            buttonId: cmd,
            buttonText: { displayText: 'ɴᴇxᴛ 🔍' }
        },
        {
            buttonId: ".menu",
            buttonText: { displayText: "ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ 📍" }
        }
    ];

    const buttonsMessage = {
        image: { url: result[0].images_url },
        caption: "ᴘɪɴᴛᴇʀᴇsᴛ ʀᴇsᴜʟᴛ: " + text,
        footer: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ @6285921655444",
        buttons: buttons,
        viewOnce: true, 
        headerType: 4
    };

    return await conn.sendMessage(m.chat, buttonsMessage);
};

handler.help = ['pint'];
handler.tags = ['downloader'];
handler.command = /^(pint)$/i;
handler.limit = true;
handler.register = true;

export default handler;

async function pinterest(query) {
  let res = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${query}`);
  let y = res.data.data;
  return y
}