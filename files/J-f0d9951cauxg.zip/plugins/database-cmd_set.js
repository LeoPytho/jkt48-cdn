let handler = async (m, { conn, text, usedPrefix, command }) => {
    db.data.stickers = db.data.stickers || {}
    if (!m.quoted) throw 'Balas stiker dengan perintah *${usedPrefix + command}*'
    if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
    if (!text) throw `Penggunaan:\n${usedPrefix + command} <teks>\n\nContoh:\n${usedPrefix + command} tes`
    let stickers = db.data.stickers
    let hash = m.quoted.fileSha256.toString('base64')
    if (stickers[hash] && stickers[hash].locked) throw 'Kamu tidak memiliki izin untuk mengubah perintah stiker ini'
    stickers[hash] = {
        text,
        mentionedJid: m.mentionedJid,
        creator: m.sender,
        at: + new Date,
        locked: false,
    }
    m.reply(`Success!`)
}


handler.help = ['cmd'].map(v => 'set' + v + ' <teks>')
handler.tags = ['database']
handler.command = ['setcmd']

export default handler