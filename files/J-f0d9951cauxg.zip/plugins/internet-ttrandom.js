import axios from 'axios';
let { proto, prepareWAMessageMedia, generateWAMessageFromContent } = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, args, text, usedPrefix, command }) => {

    m.reply(wait); 
    const query = [
        'story%20wa', 'story%20sad', 'video%20fun',
        'story%20wa%20galau', 'story%20wa%20sindiran',
        'story%20wa%20bahagia', 'story%20wa%20lirik%20lagu%20overlay',
        'story%20wa%20lirik%20lagu', 'video%20viral'
    ];

    try {
        const result = await tiktoks(query[Math.floor(Math.random() * query.length)]); // Menggunakan Math.random untuk memilih query acak
        let cap = result.title;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: cap
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: wm
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            ...(await prepareWAMessageMedia({ video: { url: result.no_watermark } }, { upload: conn.waUploadToServer })),
                            title: '*🫧 T i k T o k - R A N D O M*',
                            gifPlayback: true,
                            subtitle: '',
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: `{"display_text":"Nᴇxᴛ ᴠɪᴅᴇᴏ 🎥","id":".ttsearch ${text}"}`
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: `{"display_text":"Sᴏᴜɴᴅ 🎶","url":"${result.music}","merchant_url":"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q"}`
                                }
                            ]
                        }),
                        contextInfo: {
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363247149539361@newsletter',
                                newsletterName: '🔮 Powered By KyzRyzz',
                                serverMessageId: null
                            }
                        }
                    })
                }
            }
        }, { quoted: m });

        await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    } catch (err) {
        m.reply('Terjadi kesalahan: ' + err.message); // Mengganti 'eror' dengan pesan kesalahan yang sesuai
    }
}

handler.help = ['tiktokrandom']
handler.tags = ['downloader']
handler.command = /^(tiktokrandom|ttrandom)$/i
handler.limit = true 
handler.register = true
export default handler;

async function tiktoks(query) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios({
                method: 'POST',
                url: 'https://tikwm.com/api/feed/search',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Cookie': 'current_language=en',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                },
                data: new URLSearchParams({
                    keywords: query,
                    count: 10,
                    cursor: 0,
                    HD: 1
                }).toString()
            });

            const videos = response.data.data.videos;
            if (videos.length === 0) {
                reject("Tidak ada video yang ditemukan.");
            } else {
                const gywee = Math.floor(Math.random() * videos.length);
                const videorndm = videos[gywee];

                const result = {
                    title: videorndm.title,
                    cover: videorndm.cover,
                    origin_cover: videorndm.origin_cover,
                    no_watermark: videorndm.play,
                    watermark: videorndm.wmplay,
                    music: videorndm.music
                };
                resolve(result);
            }
        } catch (error) {
            reject(error.message || 'Terjadi kesalahan');
        }
    });
}