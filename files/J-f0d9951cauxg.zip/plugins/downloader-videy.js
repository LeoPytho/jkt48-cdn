/*
Created by AmakawaZykuan
@zuanxfnd on Instagram

 * Recode By: KyzRyzz XD
 * 𝘵𝘦𝘭𝘦: https://t.me/kyzoffc
 * 𝘪𝘯𝘧𝘰: https://s.id/kyzzxd
 * 𝘺𝘵: https://youtube.com/KyzXD
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

import axios from 'axios';
import cheerio from 'cheerio';

async function videy(url) {
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const videoSrc = $('source[type="video/mp4"]').attr('src');
    return videoSrc;
  } catch (error) {
    console.error(`Error fetching the URL: ${error.message}`);
    return null;
  }
}

let handler = async (m, { conn, command }) => {
  const url = m.text.split(' ')[1];
  if (!url) {
    await conn.sendMessage(m.chat, { text: '*Kirimkan link video dari Videy*\n_Example: .videy https://videy.co/v?xxxxxx_' }, { quoted: m });
    return;
  }

  const videoSrc = await videy(url);

  if (videoSrc) {
    await conn.sendMessage(m.chat, { video: { url: videoSrc }, caption: 'Successfully downloaded videos from Videy' }, { quoted: m });
  } else {
    await conn.sendMessage(m.chat, { text: 'Failed to fetch the video source. Please check the URL and try again.' }, { quoted: m });
  }
};

handler.help = ['videy'];
handler.command = ['videy'];
handler.tags = ['downloader','premium'];
handler.register = true;
handler.premium = true;

export default handler;