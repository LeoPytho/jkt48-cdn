/**
 * 𝙆𝙮𝙯𝙍𝙮𝙯𝙯 𝙓𝘿
 * 𝘵𝘦𝘭𝘦: https://t.me/kyzoffc
 * 𝘪𝘯𝘧𝘰: https://s.id/kyzzxd
 * 𝘺𝘵: https://youtube.com/KyzXD
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
**/
const handler = async (m) => {
  let user = db.data.users[m.sender]
  if (user.warn === 0) throw 'Kamu tidak memiliki dosa !'
  let waktu = user.lastIstigfar + 262800288
  if (new Date - user.lastIstigfar < 262800288)
  throw `[ 💬 ]Kamu harus menunggu selama, ${msToTime(waktu - new Date())}`
  user.warn -= 1
  m.reply(`🔥 *Dosa* : ${user.warn} / 100`)
  user.lastIstigfar = new Date * 1
}
handler.command = /^(astagh?fir(ullah)?|maaf)$/i
handler.limit = false
handler.exp = 100
export default handler

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24)
  hours = (hours < 10) ? "0" + hours : hours
  minutes = (minutes < 10) ? "0" + minutes : minutes
  seconds = (seconds < 10) ? "0" + seconds : Seconds
  return minutes + " menit " + seconds + " detik"
}