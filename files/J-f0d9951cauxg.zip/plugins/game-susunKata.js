import axios from 'axios'

let timeout = 120000
let poin = 4999

let handler = async (m, { conn, command, usedPrefix }) => {
  let imgr = flaaa.getRandom()

  conn.susunkata = conn.susunkata || {}
  let id = m.chat

  if (id in conn.susunkata) {
    conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.susunkata[id][0])
    return
  }

  let response = await axios.get('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json')
  let data = response.data
  let json = pickRandom(data)

  let soal = json.soal
  let jawaban = json.jawaban
  let tipe = json.tipe || ''

  if (!soal || !jawaban) throw 'Data soal tidak lengkap.'

  let caption = `*${command.toUpperCase()}*\n\n${soal}\n${tipe}\n\n🕒 Timeout: *${(timeout / 1000)} detik*\n📌 Ketik *${usedPrefix}hsus* untuk bantuan\n🎁 Bonus: *${poin} XP*\n\nBalas pesan ini untuk menjawab!`

  let sentMsg = await conn.sendMessage(m.chat, {
    image: { url: imgr + command },
    caption
  }, { quoted: m })

  conn.susunkata[id] = [
    sentMsg,
    { jawaban: jawaban.toLowerCase().trim() },
    poin,
    setTimeout(() => {
      if (conn.susunkata[id]) {
        conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya adalah *${jawaban}*`, conn.susunkata[id][0])
        delete conn.susunkata[id]
      }
    }, timeout)
  ]
}

handler.before = async (m, { conn }) => {
  conn.susunkata = conn.susunkata || {}
  let id = m.chat

  if (!m.text || !(id in conn.susunkata)) return
  if (!m.quoted || m.quoted.id !== conn.susunkata[id][0]?.key?.id) return

  let jawaban = conn.susunkata[id][1].jawaban

  if (m.text.toLowerCase().trim() === jawaban) {
    global.db.data.users[m.sender].exp += conn.susunkata[id][2]
    clearTimeout(conn.susunkata[id][3])
    await conn.reply(m.chat, `✅ *Benar!*\nKamu mendapat +${conn.susunkata[id][2]} XP!`, m)
    delete conn.susunkata[id]
  } else if (isAlmostCorrect(m.text.toLowerCase().trim(), jawaban)) {
    conn.reply(m.chat, `🤏 *Hampir benar!* Periksa lagi jawabanmu.`, m)
  } else {
    conn.reply(m.chat, `❌ *Salah!* Coba lagi.`, m)
  }
}

function isAlmostCorrect(userAnswer, correctAnswer) {
  let correctChars = 0
  for (let i = 0; i < userAnswer.length; i++) {
    if (correctAnswer[i] && userAnswer[i] === correctAnswer[i]) {
      correctChars++
    }
  }
  let similarity = correctChars / correctAnswer.length
  return similarity >= 0.6
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

handler.help = ['susunkata']
handler.tags = ['game']
handler.command = /^susunkata$/i

export default handler