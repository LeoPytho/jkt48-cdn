import fetch from 'node-fetch'
import similarity from 'similarity'

let timeout = 120000
let poin = 4999
let threshold = 0.72

let handler = async (m, { conn, usedPrefix, command }) => {
  conn.tekateki = conn.tekateki || {}
  let id = m.chat
  if (id in conn.tekateki) return conn.reply(m.chat, '❗ Masih ada soal belum terjawab!', conn.tekateki[id][0])

  let res = await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tekateki.json')
  let data = await res.json()
  let json = data[Math.floor(Math.random() * data.length)]

  let pp = `https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=inferno-logo&fontsize=50&fillTextType=1&backgroundColor=black&text=${command}`

  let caption = `🧠 *Teka-Teki*
📄 ${json.soal}
⏳ ${(timeout / 1000)} detik
💡 Balas pesan ini untuk menjawab
📌 Ketik *.htek* untuk hint
🎁 +${poin} XP jika benar`

  conn.tekateki[id] = [
    await conn.sendFile(m.chat, pp, 'teka.jpg', caption, m),
    json,
    poin,
    setTimeout(() => {
      if (conn.tekateki[id]) {
        conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya: *${json.jawaban}*`, conn.tekateki[id][0])
        delete conn.tekateki[id]
      }
    }, timeout)
  ]
}

handler.before = async function (m, { conn }) {
  conn.tekateki = conn.tekateki || {}
  let id = m.chat
  if (!(id in conn.tekateki)) return
  if (!m.quoted || !m.quoted.id) return
  if (!m.quoted.id.includes(conn.tekateki[id][0].id)) return
  let json = conn.tekateki[id][1]

  if (m.text.toLowerCase() === 'nyerah') {
    clearTimeout(conn.tekateki[id][3])
    conn.reply(m.chat, `☠️ Menyerah ya?\nJawabannya: *${json.jawaban}*`, m)
    delete conn.tekateki[id]
  } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
    global.db.data.users[m.sender].exp += conn.tekateki[id][2]
    clearTimeout(conn.tekateki[id][3])
    conn.reply(m.chat, `🎉 Jawaban benar!\n+${conn.tekateki[id][2]} XP`, m)
    delete conn.tekateki[id]
  } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase()) >= threshold) {
    conn.reply(m.chat, '🔥 Dikit lagi!', m)
  } else {
    conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }})
  }
}

handler.help = ['tekateki']
handler.tags = ['game']
handler.command = /^tekateki$/i

export default handler