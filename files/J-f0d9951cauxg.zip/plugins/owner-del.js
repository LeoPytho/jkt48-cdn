let ownerUtama = global.owner.map(o => o[0]); // Ambil hanya nomor dari global.owner

let handler = async (m, { conn, text }) => {
    let who;
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text;
    else who = m.chat;

    if (!who) throw 'Tag orang yang akan dihapus sebagai Owner!';
    
    let nomor = who.split('@')[0];
    let index = global.owner.findIndex(o => o[0] === nomor);
    if (index === -1) throw 'Orang ini tidak ditemukan di daftar Owner!';

    if (ownerUtama.includes(nomor)) throw 'Owner utama tidak bisa dihapus!';

    global.owner.splice(index, 1);
    const caption = `Sekarang @${nomor} telah dihapus dari daftar Owner!`;

    await conn.reply(m.chat, caption, m, {
        mentions: conn.parseMention(caption)
    });
}

handler.help = ['delowner @user'];
handler.tags = ['owner'];
handler.command = /^(del|hapus|-)owner$/i;
handler.owner = true;

export default handler;