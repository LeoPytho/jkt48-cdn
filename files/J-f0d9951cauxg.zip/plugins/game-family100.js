import { family100 } from '@bochilteam/scraper'
import similarity from 'similarity'

const winScore = 4999
const threshold = 0.73
const timeout = 180000

let handler = async (m, { conn }) => {
  conn.family100 = conn.family100 || {}
  let id = 'family100_' + m.chat

  if (id in conn.family100) {
    conn.reply(m.chat, '❗Masih ada kuis belum selesai di sini!', conn.family100[id].msg)
    throw false
  }

  const json = await family100()
  let hintList = json.jawaban.map(j => j.replace(/[aiueo]/gi, '_'))

  let caption = `
🧠 *Family 100*
📄 ${json.soal}
💡 Terdapat *${json.jawaban.length}* jawaban${json.jawaban.find(v => v.includes(' ')) ? ' (beberapa ada spasi)' : ''}
💰 +${winScore} XP per jawaban benar
⏳ ${(timeout / 1000)} detik
📝 Balas pesan ini untuk menjawab
📌 Ketik *nyerah* untuk menyerah
💬 Hint: ${hintList.join(', ')}
`.trim()

  let msg = await conn.reply(m.chat, caption, m)

  conn.family100[id] = {
    id,
    msg,
    soal: json.soal,
    jawaban: json.jawaban,
    terjawab: Array.from(json.jawaban, () => false),
    winScore,
    timeout: setTimeout(() => {
      if (conn.family100[id]) {
        conn.reply(m.chat, `⏰ *Waktu habis!*\nJawaban: ${json.jawaban.map((j, i) => `(${i + 1}) ${j}`).join('\n')}`, conn.family100[id].msg)
        delete conn.family100[id]
      }
    }, timeout)
  }
}

handler.before = async function (m, { conn }) {
  conn.family100 = conn.family100 || {}
  let id = 'family100_' + m.chat
  if (!conn.family100[id]) return
  if (!m.quoted || !m.quoted.id.includes(conn.family100[id].msg.id)) return
  if (!m.text) return

  let room = conn.family100[id]
  let userAns = m.text.toLowerCase().replace(/[^\w\s\-]+/, '')
  let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
  let user = global.db.data.users[m.sender] || (global.db.data.users[m.sender] = { exp: 0 })

  if (isSurrender) {
    clearTimeout(room.timeout)
    let result = room.jawaban.map((j, i) => `(${i + 1}) ${j}`).join('\n')
    conn.reply(m.chat, `😢 Menyerah ya?\nJawabannya:\n${result}`, room.msg)
    delete conn.family100[id]
    return
  }

  let index = room.jawaban.findIndex((j, i) => !room.terjawab[i] && j.toLowerCase() === userAns)
  if (index >= 0) {
    if (room.terjawab[index]) return
    room.terjawab[index] = m.sender
    user.exp += room.winScore
  } else {
    let similar = room.jawaban.some((j, i) =>
      !room.terjawab[i] && similarity(j.toLowerCase(), userAns) >= threshold
    )
    if (similar) return conn.reply(m.chat, '🔥 *Dikit lagi!*', m)
    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })
    return
  }

  let isWin = room.terjawab.every(Boolean)
  let result = room.jawaban.map((j, i) =>
    room.terjawab[i] ? `(${i + 1}) ${j} @${room.terjawab[i].split('@')[0]}` : false
  ).filter(Boolean).join('\n')

  await conn.reply(m.chat, `
📄 ${room.soal}
${isWin ? '*SEMUA JAWABAN TERJAWAB*' : ''}
${result}
+${winScore} XP tiap jawaban benar
`.trim(), room.msg)

  if (isWin) {
    clearTimeout(room.timeout)
    delete conn.family100[id]
  }
}

handler.help = ['family100']
handler.tags = ['game']
handler.command = /^family100$/i

export default handler