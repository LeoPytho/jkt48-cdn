let handler = m => m

handler.init = async function() {
  this.ev.on('call', async (call) => {
    try {
      if (call[0].status !== 'offer') return

      const isOwner = owner.some(([num]) => call[0].from === num + '@s.whatsapp.net')
      if (isOwner) return

      global.db.data.users[call[0].from].banned = true

      const ctc = await this.sendContactArray(call[0].from, [
        [
          owner[0][0],
          await this.getName(owner[0][0] + '@s.whatsapp.net'),
          'Developer Bot',
          'Owner Bot Furina AI',
          'furinnteam@gmail.com',
          '🇯🇵 Japan',
          'https://furinnteam.biz.id',
          'Owner Bot'
        ]
      ], fkontak)

      await this.reply(call[0].from, '*⚠️ Automated blocking & banned database system!*\nDo not call the bot!\nContact the Owner to be unblocked!', ctc)

      await this.rejectCall(call[0].id, call[0].from)
      await this.updateBlockStatus(call[0].from, 'block')

    } catch (err) {
      console.error('Error handling call event:', err)
    }
  })
}

export default handler