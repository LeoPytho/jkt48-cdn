/** 
* pungsi antibrat😈
* created by Kyzryzz
*/

import { sticker } from '../lib/sticker.js'

export async function all(m) {
if (db.data.antibrat) {
      if (m.text.includes("brat")) {
      
      let url = await sticker(null, `https://files.catbox.moe/hzzszx.webp`, global.packname, global.author)
      return this.sendFile(m.chat, url, 'sticker.webp', '', m)
      }
   }
}