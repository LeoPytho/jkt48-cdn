import fs from "fs";
import cp, { exec as _exec } from "child_process";
import { promisify } from "util";
let exec = promisify(_exec).bind(cp);

export async function all(m) {
  if (global.settings.backupSC) {
    if (Date.now() - global.settings.backupSC > 43200000) {
      try {
        let d = new Date(Date.now() + 3600000);
        let locale = "id";
        let date = d.toLocaleDateString(locale, {
          day: "numeric",
          month: "numeric",
          year: "numeric"
        });
        let sanitizedDate = date.replace(/\s+/g, "-").replace(/[^\w\-_.]/g, "-");
        let zipFileName = `FurinnProject_${sanitizedDate}_${time}.zip`;
        let a = await conn.sendMessage(owner[0][0] + jid, { text: "Sedang memulai proses backup. Harap tunggu..." });
        setTimeout(async () => {
          if (fs.existsSync("node_modules")) {
            let b = await conn.sendMessage(owner[0][0] + jid, { text: "Modul 'node_modules' tidak ikut di backup.", edit: a.key });
            await a.delete();
            await b.delete();
          }
          if (fs.existsSync("database/jadibot")) {
           let c = conn.reply(owner[0][0] + jid, "Database 'jadibot' tidak ikut di backup", null) 
          }
          const file = fs.readFileSync(zipFileName);
          await conn.sendFile(owner[0][0] + jid, file, zipFileName, `✅ autoBackup selesai dengan Size: ${await func.format.size(file.length)}`, fkon);
          setTimeout(async () => {
            fs.unlinkSync(zipFileName);
            let c = await conn.sendMessage(owner[0][0] + jid, { text: "File backup telah dihapus." });
          }, 5000);
        }, 3000);
        setTimeout(async () => {
          let zipCommand = `zip -r ${zipFileName} * -x "node_modules/*"`;
          await exec(zipCommand);
          global.settings.backupSC = Date.now();
        }, 1000);
      } catch (error) {
        await conn.reply(owner[0][0] + jid, "Terjadi kesalahan saat melakukan backup.\n\n" + error.message);
        console.error(error);
      }
    }
  }
}