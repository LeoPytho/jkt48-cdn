/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owenssw
* 𝘪𝘯𝘧𝘰: -
* 𝘺𝘵: https://youtube.com/CekGem
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

import fetch from 'node-fetch';
import {sticker} from '../lib/sticker.js';

let handler = async (m, { command, usedPrefix, conn, args }) => {
    await m.reply('[✔] Tunggu sebentar...');

    let res = await YesNo();
    let stiker = await sticker(null, res.image, "Bot say", (res.answer).toUpperCase());

    try {
        await conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m });
    } catch (e) {
        console.error(e);
        throw new Error('Terjadi kesalahan saat mengirim stiker');
    }
};

handler.help = ["yesno"];
handler.tags = ["game"];
handler.command = /^(yesno)$/i;

export default handler;

async function YesNo() {
    const response = await fetch('https://yesno.wtf/api');
    const data = await response.json();
    return data;
}