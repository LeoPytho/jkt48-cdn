const handler = m => m;

const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;

handler.before = async function(m, { user, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;
  
  const chat = global.db.data.chats[m.chat];
  const isGcLink = linkRegex.exec(m.text);

  if (chat.antiLink2 && isGcLink) {
    await m.reply(`*「 ANTI LINK V2 」*\n\nTerdeteksi *${await conn.getName(m.sender)}* Anda telah mengirimkan tautan grup!\n\nMaaf, pesan anda akan saya hapus!`);
    
    if (isAdmin) return m.reply('*Admin mah bebas ye kan..*');
    if (!isBotAdmin) return m.reply('*Yah Gk Bisa Kick bot bukan Admin*');
    
    const linkGC = ('https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat));
    const isLinkconnGc = new RegExp(linkGC, 'i');
    const isgclink = isLinkconnGc.test(m.text);
    
    if (isgclink) return m.reply('*「 ANTI LINK V2 」*\n\nPesanan ditolak, bot tidak akan menendang Anda.\nKarena tautan grup itu sendiri');
    
    await conn.sendMessage(m.chat, { delete: m.key });
  }
  
  return true;
};

export default handler;

export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}