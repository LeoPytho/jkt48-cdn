let handler = async (m, { conn, args, usedPrefix, command }) => {
  let who = m.sender
  if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak terdaftar dalam database.'
  let user = db.data.users[who]
  
  let jumlah = args[0] ? parseInt(args[0]) : 0
  if (!jumlah) throw `[❗] Ex: ${usedPrefix + command} 1000`
  if (isNaN(jumlah)) throw '[❗] Yang kamu masukkan bukan angka !'
  if (jumlah < 1) throw '[❗] Minimal deposit adalah 1'
  if (user.money < jumlah) throw '[❗] Uang kamu tidak cukup untuk deposit sebanyak itu!'
  
  user.money -= jumlah
  user.bank += jumlah
  m.reply(` ✔ Berhasil deposit ${jumlah} ke bank!\n\nSaldo sekarang:\n • Money: ${user.money}\n • Bank: ${user.bank}\nSilakan cek pada */bank* atau */balance*`)
}

handler.help = ['deposit', 'addbank'].map(a => `${a} <jumlah>`) 
handler.tags = ['main']
handler.command = /^(deposit|addbank)$/i

export default handler