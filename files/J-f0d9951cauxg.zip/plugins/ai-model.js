let handler = async (m, { conn, args, text, command }) => {
    let [chat, teks] = text.split('|');
    const aiList = {
        '--furina': "62856586301697@s.whatsapp.net"
    };

    conn.userSessions = conn.userSessions || {};

    if (chat === '--set') {
        if (!teks || !aiList[teks.trim()]) {
            return m.reply(`[❗] Model AI tidak valid. Pilih salah satu:\n\n${Object.keys(aiList).join('\n')}`);
        }
        conn.userSessions[m.sender] = {
            model: teks.trim(),
            timer: setTimeout(() => {
                delete conn.userSessions[m.sender];
            }, 600000)
        };
        return m.reply(`[✅] Model AI ${teks.trim()} telah disetel untuk Anda selama 10 menit.`);
    }

    let session = conn.userSessions[m.sender];
    if (session) {
        chat = `--${session.model}`;
    }

    let result = aiList[chat];

    if (!result) {
        return m.reply(`[❗] Perintah tidak dikenal, AI Tersedia adalah:\n\n${Object.keys(aiList).join('\n')}\n\nPenggunaan: /${command} --chatgpt|halo\n\nAtau gunakan /${command} --set|model untuk memilih model.`);
    }

    try {
        if (!teks) {
            return m.reply("[❗] Silakan masukkan pesan yang ingin dikirim.");
        }

        let aiThumb = await conn.profilePictureUrl(result, "image");
        await conn.sendMessage(result, { text: teks });
        m.reply("[✅] Pesan berhasil diteruskan. Mohon tunggu balasan.");

        if (global.responseListener) {
            conn.ev.off('messages.upsert', global.responseListener);
        }

        global.responseListener = async (msg) => {
            if (msg.messages[0].key.remoteJid === result && msg.messages[0].message?.conversation) {
                const response = msg.messages[0].message.conversation;
                await conn.sendMessage(
                    m.chat,
                    {
                        text: `> Balasan dari AI - ${chat.replace('--', '').toUpperCase()}:\n\n${response}`,
                        contextInfo: {
                            mentionedJid: [m.sender],
                            businessMessageForwardInfo: { businessOwnerJid: result },
                            externalAdReply: {
                                title: chat.replace('--', '').toUpperCase(),
                                body: "Powered By Kyzryzz",
                                thumbnailUrl: aiThumb,
                                renderLargerThumbnail: false
                            }
                        }
                    },
                    { quoted: m }
                );
            }
        };

        conn.ev.on('messages.upsert', global.responseListener);
    } catch (e) {
        return m.reply(`[❗] Terjadi kesalahan: ${e.message}`);
    }
};

handler.help = ['aimodel', 'ai-model'];
handler.command = /^(aimodel|model|ai-model)$/i;
handler.tags = ['ai'];

export default handler;