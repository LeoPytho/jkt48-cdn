import similarity from 'similarity';
const threshold = 0.72;

export async function before(m) {
    let id = m.chat;

    // Validasi jika pesan tidak relevan
    if (
        !m.quoted || 
        !m.quoted.fromMe || 
        !m.quoted.isBaileys || 
        !m.text || 
        !/Ketik.*hlog/i.test(m.quoted.text) || 
        /.*hlog/i.test(m.text)
    ) {
        return true;
    }

    this.tebaklogo = this.tebaklogo || {};

    // Periksa apakah ID chat ada dalam conn.tebaklogo
    if (!this.tebaklogo[id] || !Array.isArray(this.tebaklogo[id]) || this.tebaklogo[id].length < 4) {
        conn.reply(m.chat, 'Soal itu telah berakhir atau tidak valid', m);
        return true;
    }

    let data = this.tebaklogo[id];

    // Validasi soal terkait pesan yang dikutip
    if (!data[0]?.key?.id || m.quoted.id !== data[0].key.id) {
        conn.reply(m.chat, 'Soal itu telah berakhir atau tidak valid', m);
        return true;
    }

    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text);

    if (isSurrender) {
        clearTimeout(data[3]);
        delete this.tebaklogo[id];
        conn.reply(m.chat, '*Yah Menyerah :( !*', m);
        return true;
    }

    let jawaban = data[1]?.jawaban;

    // Validasi jawaban
    if (!jawaban) {
        conn.reply(m.chat, 'Jawaban tidak valid', m);
        delete this.tebaklogo[id];
        return true;
    }

    // Periksa jawaban
    if (m.text.toLowerCase() === jawaban.toLowerCase().trim()) {
        global.db.data.users[m.sender].exp += data[2];
        conn.reply(m.chat, `*Benar!*\n+${data[2]} XP`, m);
        clearTimeout(data[3]);
        delete this.tebaklogo[id];
    } else if (similarity(m.text.toLowerCase(), jawaban.toLowerCase().trim()) >= threshold) {
        m.reply(`*Dikit Lagi!*`);
    } else {
        conn.reply(m.chat, `*Salah!*`, m);
    }

    return true;
}

export const exp = 0;