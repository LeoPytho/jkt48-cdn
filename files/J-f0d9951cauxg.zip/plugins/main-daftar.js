/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owensdev
* 𝘪𝘯𝘧𝘰: https://hanlala.in/ows/
* 𝘺𝘵: https://youtube.com/owensdev
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/C9zCqhsLAuwEXkr4xwXEph

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

import { createHash } from 'crypto'
import canvafy from "canvafy";
import fetch from 'node-fetch'
import moment from 'moment-timezone'
import fs from 'fs'
const { generateWAMessageFromContent, proto } = (await import('@adiwajshing/baileys')).default

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i
let handler = async function (m, { text, usedPrefix, command }) {
await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}
let namae = conn.getName(m.sender)
const umurRandom = Math.floor(Math.random() * 40) + 5;
let user = global.db.data.users[m.sender]
const pp = await conn.profilePictureUrl(m.sender, "image").catch((_) => "./src/avatar_contact.png")
  if (user.registered === true) throw `Kamu Sudah Ter daftar Di Database, Apa Kamu Ingin Mendaftar Ulang? *${usedPrefix}unreg`

  let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Masukan nama.umur\nContoh: ${usedPrefix + command} ${m.name}.${umurRandom}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ""
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "ᴜɴᴛᴜᴋ ᴅᴀғᴛᴀʀ ᴍᴀɴᴜᴀʟ ᴋᴇᴛɪᴋ `.register ɴᴀᴍᴀ.ᴜᴍᴜʀ`",
            subtitle: "",
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [            
                            {
                "name": "quick_reply",
                "buttonParamsJson": "{\"display_text\":\"ᴋʟɪᴋ ᴅɪ sɪɴɪ ᴜɴᴛᴜᴋ ᴅᴀғᴛᴀʀ ᴏᴛᴏᴍᴀᴛɪs 🫧\",\"id\":\"@verify\"}"
                                            },
              {
                 "name": "quick_reply",
                 "buttonParamsJson": "{\"display_text\":\"ɢʀᴏᴜᴘ ʙᴏᴛᴢ ᴏғғɪᴄɪᴀʟ 🪩\",\"id\":\".gcbot\"}"
              }, 
              {
                 "name": "cta_url",
                 "buttonParamsJson": "{\"display_text\":\"ɪɴғᴏ ʙᴏᴛ ғᴜʀɪɴᴀ - ᴀɪ 🌐\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://www.google.com\"}"
              }, 
           ],
          })
          })
    }
  }
}, {quoted:m})

  if (!Reg.test(text)) return conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
  let [_, name, splitter, age] = text.match(Reg);
    if (!name) throw "ɴᴀᴍᴀ ᴛɪᴅᴀᴋ ʙᴏʟᴇʜ ᴋᴏsᴏɴɢ (Alphanumeric)";
    if (!age) throw "Umur tidak boleh kosong (Angka)";
    
    age = parseInt(age);
    if (age > 40) throw "*Gak boleh!*,\nTua Amat Dah 🗿";
    if (age < 5) throw "*Gak boleh!*,\nBanyak Pedo 🗿";
    if (user.name && user.name.trim() === name.trim()) throw "ɴᴀᴍᴀ sᴜᴅᴀʜ ᴅɪᴘᴀᴋᴀɪ";

    let sn = createHash("md5").update(m.sender).digest("hex");
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.fromMe ? conn.user.jid : m.sender;

    let cap = `
乂  *R E G I S T E R  S U C C E S S*

┌  ◦ *Name* : ${name}
│  ◦ *Age* : ${age}
└  ◦ *Serial Number* : _*ᴅɪ ᴋɪʀɪᴍ ᴋᴇ ᴘʀɪʙᴀᴅɪ.*_

ᴛᴇʀɪᴍᴀᴋᴀsɪʜ ᴛᴇʟᴀʜ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴠᴇʀɪғɪᴋᴀsɪ. ᴅᴀᴛᴀ ᴘᴇɴɢɢᴜɴᴀ ᴛᴇʟᴀʜ ᴅɪsɪᴍᴘᴀɴ ᴅᴇɴɢᴀɴ ᴀᴍᴀɴ ᴅɪ ᴅᴀᴛᴀʙᴀsᴇ *ꜰᴜʀɪɴᴀ ᴀɪ* ᴅᴀᴛᴀ ᴋᴀᴍᴜ sᴇᴋᴀʀᴀɴɢ sᴜᴅᴀʜ ᴛᴇʀᴠᴇʀɪғɪᴋᴀsɪ ᴅɪ *ꜰᴜʀɪɴᴀ ᴀɪ*

sᴇᴋᴀʀᴀɴɢ ᴋᴀᴍᴜ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ-ғɪᴛᴜʀ ᴋʜᴜsᴜs ʏᴀɴɢ ʜᴀɴʏᴀ ᴛᴇʀsᴇᴅɪᴀ ᴜɴᴛᴜᴋ ᴘᴇɴɢɢᴜɴᴀ ᴛᴇʀᴠᴇʀɪғɪᴋᴀsɪ.
`;

    const json = await createOtpCanvas(pp);
          
    let confirm = "☘️ ʀᴇᴘʟʏ ᴘᴇsᴀɴ ɪɴɪ ᴅᴇɴɢᴀɴ ᴍᴇɴɢᴇᴛɪᴋ ᴋᴏᴅᴇ ᴏᴛᴘ ʏᴀɴɢ ᴀᴅᴀ ᴘᴀᴅᴀ ɢᴀᴍʙᴀʀ!";
    let { key } = await conn.sendFile(m.chat, json.image, '', confirm, m);

    conn.registrasi[m.chat] = {
        ...conn.registrasi[m.chat],
        [m.sender]: {
            message: m,
            sender: m.sender,
            otp: json.otp,
            verified: json.verified,
            caption: cap,
            pesan: conn,
            age,
            user,
            name,
            key,
            timeout: setTimeout(() => {
                conn.sendMessage(m.chat, { delete: key });
                delete conn.registrasi[m.chat][m.sender];
            }, 60 * 1000)
        }
    };
}

handler.before = async (m, { conn }) => {
    conn.registrasi = conn.registrasi ? conn.registrasi : {};
    if (m.isBaileys) return;
    if (!conn.registrasi[m.chat]?.[m.sender]) return;
    if (!m.text) return;
    
    let { timeout, otp, verified, message, sender, pesan, caption, user, name, age, key } = conn.registrasi[m.chat]?.[m.sender];
    if (m.id === message.id) return;
    if (m.id === key.id) return;

    if (m.text == otp) {
        user.name = name.trim();
        user.age = age;
        user.regTime = +new Date;
        user.registered = true;

        let benar = `🐾 ᴏᴛᴘ ʙᴇɴᴀʀ!\n${m.sender.split('@')[0]} ᴛᴇʟᴀʜ ᴅɪ ᴠᴇʀɪғɪᴋᴀsɪ!\n\n`;
        pesan.sendFile(m.chat, verified, '', benar + caption, m);
        clearTimeout(timeout);
        pesan.sendMessage(m.chat, { delete: key });
        delete conn.registrasi[m.chat]?.[m.sender];

        // Kirim SN kepada pengguna
        let sn = createHash("md5").update(m.sender).digest("hex");
        if (m.isGroup) conn.reply(m.sender, `*🚩 sɴ :* ${sn}\n\n*ᴄᴏᴅᴇ sɴ ᴍᴜ ᴊᴀɴɢᴀɴ sᴀᴍᴘᴇ ʜɪʟᴀɴɢ/ᴋᴇʜᴀᴘᴜs ʏᴀ*`, fkontak);

        // Respons emoji "☑️"
        conn.sendMessage(m.chat, {
            react: {
                text: '☑️',
                key: m.key,
            }
        });

        // Kirim file audio
        await conn.sendFile(m.chat, './vn/daftar.mp3', '', null, m, true);
    } else {
        m.reply(`✖️ ᴏᴛᴘ sᴀʟᴀʜ!\n${m.sender.split('@')[0]} ᴛɪᴅᴀᴋ ᴅɪ ᴠᴇʀɪғɪᴋᴀsɪ!`);
        clearTimeout(timeout);
        pesan.sendMessage(m.chat, { delete: key });
        delete conn.registrasi[m.chat]?.[m.sender];

        // Respons emoji "❎"
        conn.sendMessage(m.chat, {
            react: {
                text: '❎',
                key: m.key,
            }
        });
    }
}
handler.help = ['register', 'daftar']
handler.tags = ['main']

handler.command = /^(reg(ister)?|daftar)$/i

export default handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

function isNumber(x) {
    return !isNaN(x);
}

function generateRandomCharacter() {
    const characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz#$&@*!?';
    return characters[Math.floor(Math.random() * characters.length)];
}

async function createOtpCanvas(avatar) {
    const codetext = Array.from({ length: 4 }, generateRandomCharacter).join('');
    const captchaBuffer = await new canvafy.Captcha()
        .setBackground("image", "https://telegra.ph/file/f1c908e8e76be968e42f3.jpg")
        .setCaptchaKey(codetext.toString())
        .setBorder("#f0f0f0")
        .setOverlayOpacity(0.7)
        .build();
    const securityBuffer = await new canvafy.Security()
        .setAvatar(avatar)
        .setBackground("image", "https://telegra.ph/file/f1c908e8e76be968e42f3.jpg")
        .setCreatedTimestamp(Date.now())
        .setSuspectTimestamp(1)
        .setBorder("#f0f0f0")
        .setLocale("id") // country short code - default "en"
        .setAvatarBorder("#f0f0f0")
        .setOverlayOpacity(0.9)
        .build();
    return {
        image: captchaBuffer,
        otp: codetext,
        verified: securityBuffer
    };
}

function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "Selamat Dini Hari 💤"
  if (time >= 4) {
    res = "Selamat Pagi ⛅"
  }
  if (time >= 10) {
    res = "Selamat Siang ☀️"
  }
  if (time >= 15) {
    res = "Selamat Sore 🌥"
  }
  if (time >= 18) {
    res = "Selamat Malam 🌙"
  }
  return res
}