import axios from 'axios'

const handler = async (m, { conn, args, command }) => {
  if (!args[0]) throw `Contoh: .${command} https://youtu.be/...`

  const vid = args[0]
  await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } })

  try {
    const { data } = await axios.get(`https://api.nazir.my.id/api/ytmp3?apikey=fe401a3e-4eae-4bd4-9583-e9b8459db715&url=${encodeURIComponent(vid)}`)
    
    if (!data.status) throw 'Gagal mengambil data.'

    const { metadata, media, thumbnail } = data.result
    const { title, url, duration, views, ago, author } = metadata

    const caption = `{
  "result": {
    "title": "${title}",
    "channel": "${author}",
    "views": "${views}",
    "duration": "${duration}",
    "upload": "${ago}",
    "url": "${url}"
  }
}`.trim()

    await conn.sendMessage(m.chat, {
      document: {
        url: 'https://wa.me/6282229412573'
      },
      mimetype: 'image/png', // ganti sesuai kebutuhan
      fileName: `${m.name}`,
      jpegThumbnail: await conn.resize(pp, 400, 400),
      fileLength: 10,
      caption: caption,
      footer: `JulxyZ || ytmp3`,
      buttons: [
        {
          buttonId: `.ytmp4 ${vid}`,
          buttonText: { displayText: "Versi Video🎥" },
          type: 1
        }
      ],
      headerType: 6,
      contextInfo: {
        externalAdReply: {
          title: `[ Hello </> ${m.name} </> ]`,
          body: `${author} • ${duration}`,
          thumbnailUrl: thumbnail,
          mediaType: 1,
          sourceUrl: vid,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

    const audioBuffer = await fetch(media).then(res => res.arrayBuffer())

    await conn.sendMessage(m.chat, {
      audio: Buffer.from(audioBuffer),
      mimetype: 'audio/mp4',
      fileName: `${title}.mp3`,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: `🎵 Judul: ${title}\n📺 Channel: ${author}\n⏱️ Durasi: ${duration}`,
          thumbnailUrl: thumbnail,
          mediaType: 1,
          sourceUrl: vid,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: "✅️", key: m.key } })

  } catch (err) {
    console.error(err)
    throw 'Terjadi kesalahan saat memproses permintaan. Pastikan URL valid dan coba lagi.'
  }
}

handler.command = ['ytmp3', 'yta', 'ytaudio']
handler.help = ['ytmp3 <url>']
handler.tags = ['downloader']

export default handler