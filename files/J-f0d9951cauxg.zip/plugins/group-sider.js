//Powered By Kyzryzz * kyzryzz.t.me
let { 
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateWAMessageContent
} = (await import('@adiwajshing/baileys')).default

let handler = async (m, {
    conn,
    text,
    groupMetadata, 
    participants
}) => {
await conn.sendPresenceUpdate('composing', m.chat)
    var lama = 86400000 * 7
    const now = new Date().toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    });
    const milliseconds = new Date(now).getTime();

      let member = participants.map(u => u.id).filter(v => v !== conn.user.jid);
          if (!text) {
        var pesan = "Harap Aktif Di Grup Karena Akan Ada Pembersihan Member Setiap Saat"
    } else {
        var pesan = text
    }
    var sum
    sum = member.length
    var total = 0
    var sider = []
    for (let i = 0; i < sum; i++) {
        let users = m.isGroup ? groupMetadata.participants.find(u => u.id == member[i]) : {}
        if ((typeof global.db.data.users[member[i]] == 'undefined' || milliseconds * 1 - global.db.data.users[member[i]].lastseen > lama) && !users.isAdmin && !users.isSuperAdmin) {
            if (typeof global.db.data.users[member[i]] !== 'undefined') {
                if (global.db.data.users[member[i]].banned == true) {
                    total++
                    sider.push(member[i])
                }
            } else {
                total++
                sider.push(member[i])
            }
        }
    }
    const listSider = sider.map(v => `  • @${v.replace(/@.+/, '')} (${typeof global.db.data.users[v] === "undefined" ? 'Sider' : 'Off ' + msToDate(milliseconds - global.db.data.users[v].lastseen)})`).join('\n');
    
let ppgc = await conn.profilePictureUrl(m.chat, 'image')
    if (total == 0) return conn.reply(m.chat, `*Digrup Ini Tidak Ada Sider.*`, m)
                    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({ text: `*${total}/${sum}* Anggota Grup *${await conn.getName(m.chat)}* Adalah Sider Dengan Alasan :\n1. Tidak Aktif Selama Lebih Dari 7 Hari\n2. Join Tetapi Tidak Pernah Nimbrung\n\n_“${pesan}”_\n\n*List Member Sider:*\n${listSider}` }),
                                footer: proto.Message.InteractiveMessage.Footer.create({ text: '' }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "",
                                    subtitle: "",
                                    hasMediaAttachment: true,
                                    ...(await prepareWAMessageMedia({ image: { url: ppgc }, fileLength: '1000' }, { upload: conn.waUploadToServer }))
                                }),
                                contextInfo: {
                                    forwardingScore: 9999,
                                    isForwarded: true,
                                    mentionedJid: sider,
                                    externalAdReply: {
                                        title: 'Group Sider! ',
                                        body: '',
                                        thumbnailUrl: ppgc,
                                        sourceUrl: '',
                                        mediaType: 1,
                                        renderLargerThumbnail: true
                                    }
                                },
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [{
                                        "name": "cta_url",
                                        "buttonParamsJson": `{\"display_text\":\"${footer}\",\"url\":\"bejirr\",\"merchant_url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\"}`
                                    }]
                                })
                            })
                        }
                    }
                }, { quoted: m });

                await conn.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                });
}
handler.help = ['gcsider']
handler.tags = ['group']
handler.command = /^(gcsider)$/i
handler.group = true

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)


function msToDate(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  if (d == 0 && h == 0 && m == 0) {
        return "Baru Saja"
    } else {
        return [d, 'H ', h, 'J '].map(v => v.toString().padStart(2, 0)).join('')
    }
  
}