let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("[❗] Input url saluran WhatsApp");
  if (!text.includes("https://whatsapp.com/channel/")) throw "Link tautan tidak valid";

  let result = text.split("https://whatsapp.com/channel/")[1];
  let res = await conn.newsletterMetadata("invite", result);

  let teks = `[ ɴᴇᴡsʟᴇᴛᴛᴇʀ ᴍᴇᴛᴀᴅᴀᴛᴀ ]

*ɪᴅ :* ${res.id}
*ɴᴀᴍᴀ :* ${res.name}
*ᴛᴏᴛᴀʟ ᴘᴇɴɢɪᴋᴜᴛ :* ${res.subscribers}
*sᴛᴀᴛᴜs :* ${res.state}
*ᴠᴇʀɪғɪᴇᴅ :* ${res.verification == "VERIFIED" ? "ᴛᴇʀᴠᴇʀɪғɪᴋᴀsɪ ✅" : "ᴛɪᴅᴀᴋ ❌"}
*ʀᴇᴀᴄᴛɪᴏɴ :* ${res.reaction_codes}
*ᴅᴇsᴄʀɪᴘᴛɪᴏɴ :* ${readmore + res.description}`;

  let kopi = {
                 "name": "cta_copy",
                 "buttonParamsJson": `{\"display_text\":\"ᴄoᴘʏ ɪᴅ ɴᴇᴡsʟᴇᴛᴛᴇʀ\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
              };
  conn.sendMessage(m.chat, {text:teks, footer: wm, interactiveButtons: [ kopi ] }, {quoted: m})
};

handler.help = handler.command = ['ci', 'chstalk'];
handler.tags = ['info', 'tools'];
export default handler;