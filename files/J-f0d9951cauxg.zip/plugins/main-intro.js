import { promises } from 'fs'
import canvafy from "canvafy";
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'
const { generateWAMessageFromContent, proto } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {

let intro = `╭‹•━━━━━━━━━━━━━━━━━━━━━━♡
├──「🪩 *K A R T U  I N T R O* 🪩」──
│ *Nama*    : 
│ *Gender*   : 
│ *Umur*     : 
│ *Hobby*    : 
│ *Kelas*     : 
│ *Asal*      : 
│ *Agama*   : 
│ *Status*    : 
└───────────────────╌┄┄╌`

let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: intro
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ""
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "",
            subtitle: "乂 I N T R O",
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                 "name": "cta_copy",
                 "buttonParamsJson": `{\"display_text\":\"Cᴏpʏ ᴋᴀʀᴛᴜ ɪɴᴛʀᴏ 🫧\",\"id\":\"123456789\",\"copy_code\":\"${intro}\"}`
              }
            ],
          })
        })
    }
  }
}, {})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
handler.help = ['intro']
handler.tags = ['main']
handler.command = /^(intro)$/i

handler.register = false

export default handler