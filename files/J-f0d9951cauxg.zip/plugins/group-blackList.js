let handler = async (m, { conn, args, text, command }) => {
    let who = m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0]
        : m.quoted
            ? m.quoted.sender
            : text
                ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                : false;

    let bl = db.data.chats[m.chat].blacklist || [];
    let peserta = await conn.groupMetadata(m.chat);
    
    if (command === "blacklist" || command === "hitamkan") {
    if (!args[0]) {
     return m.reply(`[❗] Input Opsi\n\nEx: \n/${command} 1 _(blakclist opsi kick)_\n/${command} 2 _(blacklist opsi hapus all pesan target)_`) 
    };
        if (args[0] === '1') {
            if (!who) {
                return conn.reply(
                    m.chat,
                    'Tag/reply orangnya untuk Blacklist',
                    m,
                    { contextInfo: { mentionedJid: peserta.participants.map(v => v.id) } }
                );
            }
            try {
                if (bl.find(v => v.id === who)) throw `Nomor ${who.split('@')[0]} sudah ada di BlackList`;
                bl.unshift({ id: who, type: '1' });
                db.data.chats[m.chat].blacklist = bl;
                await conn.reply(
                    m.chat,
                    `Sukses menambahkan @${who.split('@')[0]} ke BlackList (kick)`,
                    m,
                    { contextInfo: { mentionedJid: [who] } }
                );
            } catch (e) {
                throw e;
            }
        }
        if (args[0] === '2') {
            if (!who) {
                return conn.reply(
                    m.chat,
                    'Tag/reply orangnya untuk Blacklist dengan hapus pesan',
                    m,
                    { contextInfo: { mentionedJid: peserta.participants.map(v => v.id) } }
                );
            }
            try {
                if (bl.find(v => v.id === who)) throw `Nomor ${who.split('@')[0]} sudah ada di BlackList`;
                bl.unshift({ id: who, type: '2' });
                db.data.chats[m.chat].blacklist = bl;
                await conn.reply(
                    m.chat,
                    `Sukses menambahkan @${who.split('@')[0]} ke BlackList (hapus pesan)`,
                    m,
                    { contextInfo: { mentionedJid: [who] } }
                );
            } catch (e) {
                throw e;
            }
        }
    }

    if (command === "unblacklist" || command === "putihkan" || command === "unbl") {
        if (!who) throw 'Tag/reply orangnya untuk Unblacklist';
        try {
            let idx = bl.findIndex(v => v.id === who);
            if (idx === -1) throw `Nomor ${who.split('@')[0]} tidak ada di BlackList`;
            bl.splice(idx, 1);
            db.data.chats[m.chat].blacklist = bl;
            await conn.reply(
                m.chat,
                `Sukses menghapus @${who.split('@')[0]} dari BlackList`,
                m,
                { contextInfo: { mentionedJid: [who] } }
            );
        } catch (e) {
            throw e;
        }
    }

    if (command === "listblacklist" || command === "listbl") {
        let txt = `*「 Daftar Nomor Blacklist 」*\n\n*Total:* ${bl.length}\n\n┌─[ BlackList ]\n`;
        for (let i of bl) {
            let label = i.type === '1' ? '(kick)' : '(hapus pesan)';
            txt += `├ @${i.id.split('@')[0]} ${label}\n`;
        }
        txt += '└─•';
        return conn.reply(
            m.chat,
            txt,
            m,
            { contextInfo: { mentionedJid: bl.map(v => v.id) } }
        );
    }
};

handler.help = ['blacklist <1|2> @user', 'unblacklist @user', 'listblacklist'];
handler.tags = ['group'];
handler.command = ['blacklist', 'hitamkan', 'unblacklist', 'putihkan', 'unbl', 'listblacklist', 'listbl'];
handler.admin = handler.group = true;

handler.all = async (m) => {
    let chatData = db.data.chats[m.chat];
    if (!chatData || !chatData.blacklist) return;
    let bl = chatData.blacklist;
    for (let entry of bl) {
        if (entry.type === '2' && m.sender === entry.id) {
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.id,
                    participant: m.key.participant || m.sender
                }
            });
        }
    }
};

handler.before = function (m, { conn, isAdmin }) {
    if (!m.isGroup) return;
    if (m.fromMe) return;
    let bl = db.data.chats[m.chat].blacklist || [];
    let entry = bl.find(v => v.id === m.sender);
    if (entry && entry.type === '1' && !isAdmin) {
        conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
    }
};

export default handler;