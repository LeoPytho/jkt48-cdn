let handler = async (m, { conn }) => {
  const tafsirAyat = [
    { ayat: "Al-Fatiha: 1", clue: "Surah yang dibaca dalam setiap rakaat shalat." },
    { ayat: "Al-Baqarah: 255", clue: "Ayat yang dikenal sebagai Ayat Kursi." },
    { ayat: "Al-Ikhlas: 1", clue: "Surah yang berbicara tentang keesaan Allah." },
    { ayat: "An-Nisa: 1", clue: "Surah yang berbicara tentang hak-hak wanita dalam Islam." },
    { ayat: "Al-An'am: 141", clue: "Ayat yang berbicara tentang hukum makanan halal dan haram." },
    { ayat: "Al-Hujurat: 13", clue: "Ayat yang berbicara tentang persatuan umat manusia." },
    { ayat: "Al-Baqarah: 286", clue: "Ayat yang menyatakan bahwa tidak ada beban yang diberikan kepada seseorang melebihi kemampuannya." },
    { ayat: "Al-Araf: 31", clue: "Ayat yang berbicara tentang bersyukur atas nikmat Allah." },
    { ayat: "At-Tawbah: 51", clue: "Ayat yang berbicara tentang pertolongan dari Allah bagi orang yang beriman." },
    { ayat: "Az-Zumar: 53", clue: "Ayat yang menyatakan bahwa Allah Maha Pengampun bagi hamba-hamba-Nya yang bertaubat." },
    { ayat: "Al-Mulk: 15", clue: "Ayat yang menyatakan bahwa segala sesuatu di bumi adalah milik Allah." },
    { ayat: "Al-Anfal: 60", clue: "Ayat yang berbicara tentang persiapan umat Islam menghadapi musuh." },
    { ayat: "Al-Hadid: 22", clue: "Ayat yang menyatakan bahwa segala sesuatu yang terjadi di dunia sudah tercatat dalam kitab Allah." },
    { ayat: "Al-Furqan: 74", clue: "Ayat yang berbicara tentang karakteristik orang yang beriman." },
    { ayat: "Al-Ahqaf: 13", clue: "Ayat yang berbicara tentang kesetiaan dan ketaatan kepada Allah." },
    { ayat: "Al-Isra: 23", clue: "Ayat yang berbicara tentang berbakti kepada orang tua." },
    { ayat: "Al-Kafirun: 1", clue: "Surah yang berbicara tentang perbedaan keyakinan antara umat Islam dan kafir." },
    { ayat: "Ar-Rum: 21", clue: "Ayat yang berbicara tentang keajaiban penciptaan pasangan hidup." },
    { ayat: "Al-Mumtahanah: 8", clue: "Ayat yang berbicara tentang hubungan baik dengan orang non-Muslim yang tidak memerangi umat Islam." },
    { ayat: "An-Nur: 35", clue: "Ayat yang berbicara tentang Allah sebagai cahaya langit dan bumi." },
    { ayat: "At-Tahrim: 6", clue: "Ayat yang berbicara tentang menjaga diri dan keluarga dari siksa api neraka." },
    { ayat: "Al-Ma'idah: 3", clue: "Ayat yang berbicara tentang hukum makanan dan minuman yang halal." },
    { ayat: "Al-Ahzab: 33", clue: "Ayat yang berbicara tentang perilaku dan sikap wanita-wanita Rasulullah." },
    { ayat: "Al-Baqarah: 177", clue: "Ayat yang berbicara tentang rukun iman dan rukun Islam." },
    { ayat: "Al-Mujadila: 11", clue: "Ayat yang berbicara tentang orang yang diberikan keutamaan dalam hal ilmu." },
    { ayat: "Al-Kahf: 10", clue: "Ayat yang berbicara tentang pemuda yang tidur di gua dalam waktu yang lama." },
    { ayat: "At-Tawbah: 9", clue: "Ayat yang berbicara tentang puasa dan perintahnya." },
    { ayat: "Al-Qamar: 14", clue: "Ayat yang berbicara tentang umat terdahulu yang dihancurkan oleh Allah." },
    { ayat: "Al-Alaq: 1", clue: "Ayat pertama yang diturunkan kepada Nabi Muhammad SAW." },
    { ayat: "Al-Baqarah: 285", clue: "Ayat yang berbicara tentang keimanan terhadap Allah, malaikat, kitab-Nya, rasul-rasul-Nya." },
    { ayat: "Al-Jumu'ah: 9", clue: "Ayat yang berbicara tentang kewajiban shalat Jumat." },
    { ayat: "Al-Qiyamah: 36", clue: "Ayat yang berbicara tentang hari kiamat." },
    { ayat: "Al-Baqarah: 164", clue: "Ayat yang menyebutkan bukti-bukti kekuasaan Allah dalam alam semesta." },
    { ayat: "An-Nisa: 59", clue: "Ayat yang berbicara tentang kewajiban taat kepada Allah, Rasul-Nya, dan ulil amri." },
    { ayat: "Al-Fil: 1", clue: "Surah yang menceritakan peristiwa pasukan bergajah yang dihancurkan oleh Allah." },
    { ayat: "Al-Lail: 1", clue: "Ayat yang berbicara tentang perbedaan malam dan siang sebagai tanda kebesaran Allah." },
    { ayat: "Al-Mumtahanah: 9", clue: "Ayat yang berbicara tentang tidak menjadikan musuh Allah sebagai teman." },
    { ayat: "An-Nisa: 4", clue: "Ayat yang berbicara tentang hak-hak warisan." },
    { ayat: "Al-Mujadila: 2", clue: "Ayat yang berbicara tentang hak wanita dalam Islam." },
    { ayat: "Al-Baqarah: 2", clue: "Ayat pertama dari surah Al-Baqarah yang berbicara tentang petunjuk bagi orang-orang yang bertakwa." },
    { ayat: "Al-Kahf: 110", clue: "Ayat yang berbicara tentang siapa yang beramal shaleh maka amalnya tidak akan sia-sia." },
    { ayat: "Az-Zumar: 39", clue: "Ayat yang berbicara tentang pengampunan Allah bagi orang yang bertaubat." },
    { ayat: "Al-Mujadila: 12", clue: "Ayat yang berbicara tentang meminta izin kepada Nabi." },
    { ayat: "Al-Anfal: 72", clue: "Ayat yang berbicara tentang pertolongan Allah kepada orang yang beriman." },
    { ayat: "At-Tur: 5", clue: "Ayat yang berbicara tentang keindahan surga." },
    { ayat: "Al-Insan: 2", clue: "Ayat yang berbicara tentang penciptaan manusia dari air mani." },
    { ayat: "Al-Imran: 64", clue: "Ayat yang berbicara tentang seruan untuk bersama dalam agama yang benar." },
    { ayat: "Al-Jinn: 1", clue: "Ayat yang berbicara tentang kaum jin yang mendengarkan Al-Qur'an." },
    { ayat: "Al-Mulk: 1", clue: "Surah yang berbicara tentang kerajaan dan kekuasaan Allah." },
    { ayat: "At-Tawbah: 36", clue: "Ayat yang berbicara tentang waktu-waktu tertentu yang dihormati dalam Islam." },
    { ayat: "Al-Fajr: 1", clue: "Ayat yang berbicara tentang waktu subuh." },
    { ayat: "Al-Baqarah: 185", clue: "Ayat yang berbicara tentang bulan Ramadhan sebagai bulan yang penuh berkah." },
    { ayat: "As-Saff: 9", clue: "Ayat yang berbicara tentang kedatangan Isa Al-Masih sebagai penutup para nabi." },
    { ayat: "Al-Hajj: 11", clue: "Ayat yang berbicara tentang manusia yang beriman kepada Allah." },
    { ayat: "Al-Mujadila: 6", clue: "Ayat yang berbicara tentang kehidupan akhirat." },
    { ayat: "Al-Anfal: 9", clue: "Ayat yang berbicara tentang doa dan permohonan kepada Allah." },
    { ayat: "An-Nur: 31", clue: "Ayat yang berbicara tentang kewajiban wanita menjaga auratnya." },
    { ayat: "Al-Isra: 23", clue: "Ayat yang berbicara tentang berbakti kepada kedua orang tua." },
    { ayat: "Al-Mumtahanah: 12", clue: "Ayat yang berbicara tentang hak-hak wanita." },
    { ayat: "Al-Baqarah: 164", clue: "Ayat yang berbicara tentang tanda-tanda kekuasaan Allah." },
    { ayat: "At-Tawbah: 51", clue: "Ayat yang berbicara tentang pertolongan Allah bagi orang-orang yang beriman." },
    { ayat: "Az-Zumar: 53", clue: "Ayat yang menyatakan bahwa Allah Maha Pengampun bagi hamba-hamba-Nya yang bertaubat." },
    { ayat: "Al-Mulk: 15", clue: "Ayat yang menyatakan bahwa segala sesuatu di bumi adalah milik Allah." },
    { ayat: "Al-Anfal: 60", clue: "Ayat yang berbicara tentang persiapan umat Islam menghadapi musuh." },
    { ayat: "Al-Hadid: 22", clue: "Ayat yang menyatakan bahwa segala sesuatu yang terjadi di dunia sudah tercatat dalam kitab Allah." },
    { ayat: "Al-Furqan: 74", clue: "Ayat yang berbicara tentang karakteristik orang yang beriman." },
    { ayat: "Al-Ahqaf: 13", clue: "Ayat yang berbicara tentang kesetiaan dan ketaatan kepada Allah." },
    { ayat: "Al-Isra: 23", clue: "Ayat yang berbicara tentang berbakti kepada orang tua." },
    { ayat: "Al-Kafirun: 1", clue: "Surah yang berbicara tentang perbedaan keyakinan antara umat Islam dan kafir." },
    { ayat: "Ar-Rum: 21", clue: "Ayat yang berbicara tentang keajaiban penciptaan pasangan hidup." },
    { ayat: "Al-Mumtahanah: 8", clue: "Ayat yang berbicara tentang hubungan baik dengan orang non-Muslim yang tidak memerangi umat Islam." },
    { ayat: "An-Nur: 35", clue: "Ayat yang berbicara tentang Allah sebagai cahaya langit dan bumi." },
    { ayat: "At-Tahrim: 6", clue: "Ayat yang berbicara tentang menjaga diri dan keluarga dari siksa api neraka." },
    { ayat: "Al-Ma'idah: 3", clue: "Ayat yang berbicara tentang hukum makanan dan minuman yang halal." },
    { ayat: "Al-Ahzab: 33", clue: "Ayat yang berbicara tentang perilaku dan sikap wanita-wanita Rasulullah." },
    { ayat: "Al-Baqarah: 177", clue: "Ayat yang berbicara tentang rukun iman dan rukun Islam." },
    { ayat: "Al-Mujadila: 11", clue: "Ayat yang berbicara tentang orang yang diberikan keutamaan dalam hal ilmu." },
    { ayat: "Al-Kahf: 10", clue: "Ayat yang berbicara tentang pemuda yang tidur di gua dalam waktu yang lama." },
    { ayat: "At-Tawbah: 9", clue: "Ayat yang berbicara tentang puasa dan perintahnya." },
    { ayat: "Al-Qamar: 14", clue: "Ayat yang berbicara tentang umat terdahulu yang dihancurkan oleh Allah." },
    { ayat: "Al-Alaq: 1", clue: "Ayat pertama yang diturunkan kepada Nabi Muhammad SAW." },
    { ayat: "Al-Baqarah: 285", clue: "Ayat yang berbicara tentang keimanan terhadap Allah, malaikat, kitab-Nya, rasul-rasul-Nya." },
    { ayat: "Al-Jumu'ah: 9", clue: "Ayat yang berbicara tentang kewajiban shalat Jumat." },
    { ayat: "Al-Qiyamah: 36", clue: "Ayat yang berbicara tentang hari kiamat." },
    { ayat: "Al-Baqarah: 164", clue: "Ayat yang menyebutkan bukti-bukti kekuasaan Allah dalam alam semesta." },
    { ayat: "An-Nisa: 59", clue: "Ayat yang berbicara tentang kewajiban taat kepada Allah, Rasul-Nya, dan ulil amri." },
    { ayat: "Al-Fil: 1", clue: "Surah yang menceritakan peristiwa pasukan bergajah yang dihancurkan oleh Allah." },
    { ayat: "Al-Lail: 1", clue: "Ayat yang berbicara tentang perbedaan malam dan siang sebagai tanda kebesaran Allah." },
    { ayat: "Al-Mumtahanah: 9", clue: "Ayat yang berbicara tentang tidak menjadikan musuh Allah sebagai teman." },
    { ayat: "An-Nisa: 4", clue: "Ayat yang berbicara tentang hak-hak warisan." },
    { ayat: "Al-Mujadila: 2", clue: "Ayat yang berbicara tentang hak wanita dalam Islam." },
    { ayat: "Al-Baqarah: 2", clue: "Ayat pertama dari surah Al-Baqarah yang berbicara tentang petunjuk bagi orang-orang yang bertakwa." },
    { ayat: "Al-Kahf: 110", clue: "Ayat yang berbicara tentang siapa yang beramal shaleh maka amalnya tidak akan sia-sia." },
    { ayat: "Az-Zumar: 39", clue: "Ayat yang berbicara tentang pengampunan Allah bagi orang yang bertaubat." },
    { ayat: "Al-Mujadila: 6", clue: "Ayat yang berbicara tentang kehidupan akhirat." },
    { ayat: "Al-Anfal: 9", clue: "Ayat yang berbicara tentang doa dan permohonan kepada Allah." },
    { ayat: "An-Nur: 31", clue: "Ayat yang berbicara tentang kewajiban wanita menjaga auratnya." },
    { ayat: "Al-Isra: 23", clue: "Ayat yang berbicara tentang berbakti kepada kedua orang tua." },
    { ayat: "Al-Mumtahanah: 12", clue: "Ayat yang berbicara tentang hak-hak wanita." },
    { ayat: "Al-Baqarah: 164", clue: "Ayat yang berbicara tentang tanda-tanda kekuasaan Allah." },
    { ayat: "At-Tawbah: 51", clue: "Ayat yang berbicara tentang pertolongan Allah bagi orang-orang yang beriman." },
    { ayat: "Az-Zumar: 53", clue: "Ayat yang menyatakan bahwa Allah Maha Pengampun bagi hamba-hamba-Nya yang bertaubat." },
    { ayat: "Al-Mulk: 15", clue: "Ayat yang menyatakan bahwa segala sesuatu di bumi adalah milik Allah." },
    { ayat: "Al-Anfal: 60", clue: "Ayat yang berbicara tentang persiapan umat Islam menghadapi musuh." },
    { ayat: "Al-Hadid: 22", clue: "Ayat yang menyatakan bahwa segala sesuatu yang terjadi di dunia sudah tercatat dalam kitab Allah." },
    { ayat: "Al-Furqan: 74", clue: "Ayat yang berbicara tentang karakteristik orang yang beriman." },
    { ayat: "Al-Ahqaf: 13", clue: "Ayat yang berbicara tentang kesetiaan dan ketaatan kepada Allah." }
  ];

  if (!conn.tebakTafsir) conn.tebakTafsir = {};

  if (m.sender in conn.tebakTafsir) {
    m.reply("Kamu masih punya pertanyaan yang belum selesai!");
    return;
  }

  const randomClue = tafsirAyat[Math.floor(Math.random() * tafsirAyat.length)];
  conn.tebakTafsir[m.sender] = {
    answer: randomClue.ayat,
    timeout: setTimeout(() => {
      delete conn.tebakTafsir[m.sender];
      m.reply(`Waktu habis! Jawabannya adalah *${randomClue.ayat}*.`);
    }, 30 * 1000), // 30 detik
  };

  m.reply(
    `*Tebakan Tafsir*\n\nClue: ${randomClue.clue}\n\nKetik jawabanmu dalam waktu 30 detik!`
  );
};

handler.before = async (m, { conn }) => {
  if (!conn.tebakTafsir || !(m.sender in conn.tebakTafsir)) return;

  const game = conn.tebakTafsir[m.sender];
  if (m.text.toLowerCase() === game.answer.toLowerCase()) {
    clearTimeout(game.timeout);
    delete conn.tebakTafsir[m.sender];
    m.reply(`Selamat! Jawaban kamu benar: *${game.answer}*.`);
  } else {
    m.reply("Jawaban salah! Coba lagi.");
  }
};

handler.help = ["tebaktafsir"];
handler.tags = ["game"];
handler.command = /^(tebaktafsir|tebakayat)$/i;
handler.limit = false;

export default handler;