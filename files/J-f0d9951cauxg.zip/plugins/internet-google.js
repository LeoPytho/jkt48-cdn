/*
*[Plugins Google]* 
By Fruatre
wa.me/6285817597752
Saluran : https://whatsapp.com/channel/0029VaNR2B6BadmioY6mar3N
*/

import cheerio from "cheerio";
import axios from "axios";

let handler = async (m, { conn, args }) => {
    if (!args[0]) return m.reply("❗ Masukkan kata kunci pencarian!");

    const query = args.join(" ");
    try {
        const results = await google(query);

        if (results.length === 0) return m.reply("❌ Tidak ada hasil ditemukan.");

        let caption = `🔍 *Hasil Pencarian untuk: "${query}"*\n\n`;
        results.forEach((result, index) => {
            caption += `⭐ *${index + 1}. ${result.title}*\n`;
            caption += `🔗 *Link*: ${result.link}\n`;
            caption += `📝 *Deskripsi*: ${result.description || "Deskripsi tidak tersedia."}\n\n`;
        });

        const imageUrl = "https://files.catbox.moe/ggxx14.jpg"; 
        await conn.sendFile(m.chat, imageUrl, "result.jpg", caption.trim(), m);
    } catch (error) {
        console.error("Error:", error.message);
        m.reply("⚠️ Terjadi kesalahan saat mengambil data.");
    }
};

handler.help = handler.command = ['google','googlesearch','gs', 'googles'];
handler.tags = ['internet'];
export default handler;

async function google(query) {
    try {
        const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        const response = await axios.get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
            }
        });
        const html = response.data;
        const $ = cheerio.load(html);

        const results = [];
        $("div.tF2Cxc").each((index, element) => {
            const title = $(element).find("h3").text().trim();
            const link = $(element).find("a").attr("href");
            const description = $(element).find(".VwiC3b").text().trim();

            if (title && link) {
                results.push({ title, link, description });
            }
        });

        return results;
    } catch (error) {
        console.error("Error fetching search results:", error.message);
        throw new Error("Gagal mengambil data pencarian.");
    }
}