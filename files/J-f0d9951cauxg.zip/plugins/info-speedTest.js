// * Code By Nazand Code
// * Fitur Test Kecepatan Internet Anda!(Dibuat Krn Gabut)
// * Hapus Wm Denda 500k Rupiah
// * https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l

import speedTest from 'speedtest-net';

const handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { text: '🔄 Sedang menguji kecepatan internet Anda, tunggu sebentar...' }, { quoted: m });
    
    const test = await speedTest({ acceptLicense: true, acceptGdpr: true });

    const downloadSpeed = (test.download.bandwidth / 125000).toFixed(2);
    const uploadSpeed = (test.upload.bandwidth / 125000).toFixed(2);
    const ping = test.ping.latency;
    const message = `
*📊 Hasil Uji Kecepatan Internet Anda:*

📥 *Kecepatan Download*: ${downloadSpeed} Mbps
📤 *Kecepatan Upload*: ${uploadSpeed} Mbps
🏓 *Ping*: ${ping} ms

⚠️ *Catatan*: Kecepatan dapat bervariasi tergantung pada jaringan dan lokasi Anda.

_Kecepatan internet Anda telah diuji menggunakan Speedtest._
    `;
    const buttonMessage = {
      text: message,
      contextInfo: {
        externalAdReply: {
          title: '⚡ Test Speed Internet ⚡!',
          body: 'Hasil Kecepatan Internet Anda!.',
          thumbnailUrl: 'https://files.catbox.moe/1ny7y8.jpg', // URL gambar
          sourceUrl: 'https://www.instagram.com/',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    };

    await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  } catch (error) {
    console.error('Error saat menguji kecepatan internet:', error);
    await conn.sendMessage(m.chat, { text: `❗ Gagal menguji kecepatan internet: ${error.message}` }, { quoted: m });
  }
};
handler.help = ['speedtest'];
handler.tags = ['info','tools'];
handler.command = /^(speedtest|cekkecepatan|testkecepatan)$/i;
export default handler;