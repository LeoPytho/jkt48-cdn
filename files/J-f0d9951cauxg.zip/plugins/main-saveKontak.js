/*
* 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
* 𝘵𝘦𝘭𝘦: https://t.me/owenssw
* 𝘪𝘯𝘧𝘰: -
* 𝘺𝘵: https://youtube.com/CekGem
* 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
* 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

* 🚨Di Larang Menghapus Wm Ini🚨
* #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

import pkg from '@adiwajshing/baileys';
import PhoneNumber from 'awesome-phonenumber';

const { MessageType } = pkg;

const handler = async (m, { conn, text }) => {
  let name = text ? text : conn.getName(m.sender);
  let number = m.sender.split('@')[0];
  let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${name.replace(/\n/g, '\\n')}
TEL;type=CELL;type=VOICE;waid=${number}:${PhoneNumber('+' + number).getNumber('international')}
END:VCARD`;

  conn.sendMessage(m.chat, {
    contacts: {
      displayName: name,
      contacts: [{ vcard }]
    }
  });
};

handler.help = ['mycontact'];
handler.tags = ['main'];
handler.command = /^(save|saveme|mycontact)$/i;
handler.group = true;
handler.limit = true;
handler.fail = null;

export default handler;