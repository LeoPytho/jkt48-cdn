export async function before(m, { conn, participants }) {
  if (!conn.time_join) conn.time_join = { time: 0 };
  const currentTime = Math.floor(Date.now() / 1000);
  if (!m.isGroup || conn.time_join.time > currentTime) return;
  const isPrems = global.db.data.users[m.sender]?.premium;
  let messageText = "";
  for (let [number, name] of owner) {
    if (m.sender === number + "@s.whatsapp.net") {
      messageText = `[ 📣 DINGG ]\nSambutlah owner terganteng *${name}* joined the chat! 🥳`;
      break;
    }
  }
  if (!messageText && isPrems) {
    messageText = "Selamat datang, User Premium 🌟!";
  }
  if (messageText) {
    await conn.sendMessage(m.chat, { text: messageText }, { quoted: m });
    conn.time_join.time = currentTime + 600;
  }
}