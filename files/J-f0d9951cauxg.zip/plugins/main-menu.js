// Powered By Kyzryzz * kyzryzz.t.me
import moment from 'moment-timezone'
import PhoneNumber from 'awesome-phonenumber'
import { xpRange } from '../lib/levelling.js'
import fs from 'fs'
import fetch from 'node-fetch'
import os from 'os'
let {
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = (await import('@adiwajshing/baileys')).default

let handler = async (m, { conn, usedPrefix, command, args }) => {
  await conn.sendMessage(m.chat, {
  react: {
    text: `⏱️`,
    key: m.key
  } 
});
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.fromMe ? conn.user.jid : m.sender;
      let premiumTime = global.db.data.users[m.sender].premiumTime
    let prem = global.db.data.users[m.sender].premium
    let user = global.db.data.users[m.sender]                      
    if (new Date() - user.premiumTime > 0) {
            user.premiumTime = 0
            user.premium = false
        }
let fitur = Object.values(plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)
let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length
      let d = new Date(new Date + 3600000)
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }

    let _uptime
    if (process.send) {
      process.send('uptime')
      _uptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let totalreg = Object.keys(global.db.data.users).length
    let platform = os.platform()
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
        let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      timeZone: 'Asia/Jakarta'
    })
    let limit = user.premiumTime >= 1 ? 'Unlimited' : user.limit    

  const cmd = args[0] || 'list';
    let thumbnail = 'https://telegra.ph/file/bf29252842366db5ae047.jpg'

  let type = (args[0] || '').toLowerCase()
  let _menu = global.db.data.settings[conn.user.jid]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
  const tagCount = {};
  const tagHelpMapping = {};
  Object.keys(global.plugins)
    .filter(plugin => !plugin.disabled)
    .forEach(plugin => {
      const tagsArray = Array.isArray(global.plugins[plugin].tags)
        ? global.plugins[plugin].tags
        : [];

      if (tagsArray.length > 0) {
        const helpArray = Array.isArray(global.plugins[plugin].help)
          ? global.plugins[plugin].help
          : [global.plugins[plugin].help];

        tagsArray.forEach(tag => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });
    let p = pickRandom([' -', '│・', '│  ◦ ']);
  async function generateDisplay() {
  const countdowns = await displayCountdowns();
  const formattedCountdowns = countdowns
    .split("\n")
    .map(line => `${p} ${line}`)
    .join("\n");
  return `
┌───🌟 *HITUNG MUNDUR* ───
${formattedCountdowns}
└─────────────────
`;
};
  let objek = Object.values(db.data.stats).map(v => v.success)
  let totalHit = 0
   for (let b of objek) {
    totalHit += b
    }
  let docUrl = 'https://telegra.ph/file/bf29252842366db5ae047.jpg'
  let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
    return {
      help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
      tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
      prefix: 'customPrefix' in plugin,
      limit: plugin.limit,
      premium: plugin.premium,
      enabled: !plugin.disabled,
    }
  });

    const ramInGB = os.totalmem() / (1024 * 1024 * 1024);
    const freeRamInGB = os.freemem() / (1024 * 1024 * 1024);
   let data = db.data.users[m.sender];
   let tUser = Object.keys(db.data.users).length;
   let userReg = Object.values(global.db.data.users).filter(user => user.registered == true).length
   let money = data.money
   let exp = data.exp
   let role = data.role
   let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]

  let buttonOld = [
    {
        buttonId: ".sc",
        buttonText: {
            displayText: "[ 💲 sᴄʀɪᴘᴛ ]"
        },
        type: 1
    },
    {
        buttonId: ".donasi",
        buttonText: {
            displayText: "[ ♻️ ᴅᴏɴᴀᴛɪᴏɴs ]"
        },
        type: 1
    }
];

          let quick = [
{
  name: "galaxy_message",
  buttonParamsJson: JSON.stringify({
    flow_action: "navigate",
    flow_action_payload: {
      screen: "Hi i'm OwensDev",
    },
    flow_cta: wm,
    flow_id: "Galaxy_id",
    flow_message_version: "9",
    flow_token: "198028639",
  }),
}
]

let btn = [];
let objekk = Object.keys(tagCount).sort();

for (let pus of objekk) {
  btn.push({
    header: `${kyZ()} Meɴᴜ [ ${pus.toUpperCase()} ]`,
    title: await style(`🕌 View menu ${pus.toLowerCase()} features`, 1), 
    description: await style(`Discover ${pus} features`, 1), 
    id: ".menu " + pus,
  });
}

const datas = {
  title: `[ ${kyZ()} ʟɪsᴛ - ᴍᴇɴᴜ ${kyZ()} ]`,
  sections: [
    {
      title: "[⚡ Powered By OwensDev ]",
      rows: [
        {
          header: `${kyZ()} Menu [ ALL ]`,
          title: await style("🕌 View all features", 1), 
          description: await style("Discover all features", 1), 
          id: ".menu all",
        },
      ],
    },
    {
      title: "✨ Menu - List", 
      highlight_label: "🌟 Mᴏsᴛ ᴘᴏᴘᴜʟᴀʀ",
      rows: [...btn],
    },
  ],
};

let kyz = [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(datas)
              }
];

let isiMenu = [];
for (let mnu of objekk) {
  isiMenu.push(`${p} ${usedPrefix}menu ${mnu.toLowerCase()}`);
} 

let info = await style(`
┌───🌙 *ɪɴғᴏ ᴘᴇɴɢɢᴜɴᴀ* ───
${p} *Nama :* ${user.name || m.pushName || "unknown"}
${p} *Umur :* ${user.age || "unknown"}
${p} *Tag :* @${m.sender.split("@")[0]}
${p} *Terdaftar :* ${user.registered === true ? "✓" : "✘"}
${p} *Exp :* ${exp}
${p} *Limit :* ${limit}
${p} *Saldo :* ${money}
${p} *Bank :* ${data.bank}
${p} *Pasangan :* ${data.pasangan || "Belum ada"}
${p} *Role :* ${role}
${p} *Status :* ${
  who.split`@`[0] == global.nomorwa
    ? "Developer 👑️"
    : user.premiumTime >= 1
    ? "Premium 🌟"
    : user.level >= 1000
    ? "Mastah 🧣"
    : "Pemula 🧢"
}
└─────────────────`, 1);

let headers = await style(`
${kyZ()} *Assalamu'alaikum, ${user.name || m.pushName}!*
> ✨ Selamat datang di Furina AI ✨
> • ${namebot} siap membantu aktivitas Anda!.

${await generateDisplay()}${readmore}${info}
┌───🕌 *INFO BOT* ───
${p} *Nama :* ${namebot}
${p} *Pemilik :* ${nameown}
${p} *Mode :* ${global.opts['self'] ? 'Private' : settings.self ? 'Private' : global.opts['gconly'] ? 'Hanya Grup' : 'Publik'}
${p} *Platform :* ${platform}
${p} *Versi :* ${version}
${p} *Prefix :* ${usedPrefix}
└─────────────────
┌───🌟 *DASHBOARD* ───
${p} *Total Pengguna :* ${totalreg}
${p} *Tanggal Global :* ${botdate}
${p} *Tanggal Islam :* ${dateislamic}
${p} *Waktu Sekarang :* ${time} WIB
${p} *Runtime :* ${muptime}
${p} *Total Fitur :* ${fitur.length}
${p} *Memori :* ${
  freeRamInGB.toFixed(2) + " GB / " + ramInGB.toFixed(2)
} GB
└─────────────────
`, 1);

let simp = await style(`${readmore}
┌───${kyZ()} *DAFTAR PERINTAH* ───
${p} ${usedPrefix}menu
${p} ${usedPrefix}menu all
${isiMenu.join("\n")}
└─────────────────
> ✨ Total Kategori: ${isiMenu.length}
> • Selamat menikmati fitur Furina AI✨!`, 1);

let pp = await conn
  .profilePictureUrl(m.sender, "image")
  .catch((_) => "./src/avatar_contact.png");

  if (cmd === 'list') {
var loadingStages = [
  `*${kyZ()}《 _██_▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒》10%*`,
  `*✨《 _█████_▒▒▒▒▒▒▒▒▒▒▒▒▒》30%*`,
  `*${kyZ()}《 _██████████_▒▒▒▒▒▒▒▒》50%*`,
  `*✨《 _███████████████_▒▒▒▒》80%*`,
  `*${kyZ()}《 _█████████████████_》100%*`,
  "✅ *selamat menggunakan bot✨!*",
];

let { key } = await conn.sendMessage(
  m.chat,
  { text: `${kyZ()} *Memuat menu...*` },
  { quoted: fpayment }
);

for (let stage of loadingStages) {
  await conn.sendMessage(
    m.chat,
    { text: stage, edit: key },
    {
      quoted: {
        key: {
          fromMe: false,
          participant: "0@s.whatsapp.net",
          ...(m.chat
            ? { remoteJid: "0@s.whatsapp.net" }
            : {}),
        },
        message: {
          contactMessage: {
            displayName: `${m.pushName}`,
            vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${m.pushName}\nEND:VCARD`,
          },
        },
      },
    }
  );
}

    const daftarTag = Object.keys(tagCount)
      .sort()
      .join('\n - ' + usedPrefix + command + '  ');
    const more = String.fromCharCode(8206)
    const readMore = more.repeat(4001)
    let _mpt
    if (process.send) {
      process.send('uptime')
      _mpt = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let mpt = clockString(_mpt)
    let name = m.pushName || conn.getName(m.sender)
    let list = await style(`
-─── 「 *🌟 LST MENU 🌟* 」 ───-
 - ${usedPrefix + command}all 🎊
 - ${daftarTag} 🌙✨
-─────────────────────- 

> ✨ *Nikmati Menu Semua Fitur yang telah tersedia!* ✨`, 1) 
    const allTagsAndHelp = Object.keys(tagCount).map(tag => {
      const daftarHelp = tagHelpMapping[tag].map((helpItem, index) => {
        const premiumSign = help[index].premium ? '🅟' : '';
        const limitSign = help[index].limit ? 'Ⓛ' : '';
        return `.${helpItem} ${premiumSign}${limitSign}`;
      })
      .sort()
      .join('\n - ' + ' ');
      return style(`
-─── 「 *🌟 LST MENU 🌟* 」 ───-
 - ${usedPrefix + command}all 🎊
 - ${daftarTag} 🌙✨
-─────────────────────- 

> ✨ *Nikmati Menu Semua Fitur yang telah tersedia!* ✨`, 1);
    }).join('\n');
    let all =  `${info}${readMore}\n${allTagsAndHelp}\n${wm}`

let menu; 

if (_menu.image) {
  menu = await conn.sendMessage(m.chat, {
    text: list,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: footer,
        body: wm,
        thumbnailUrl: media.furina,
        renderLargerThumbnail: true,
      },
    }
  }, { quoted: m });
} else if (_menu.gif) {
  menu = await conn.sendMessage(m.chat, {
    video: { url: "https://telegra.ph/file/ca2d038b71ff86e2c70d3.mp4" },
    gifPlayback: true,
    caption: list,
    jpegThumbnail: await conn.resize((await conn.getFile(docUrl)).data, 180, 72),
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: footer,
        body: wm,
        thumbnailUrl: media.furina,
        renderLargerThumbnail: true,
      },
    }
  }, { quoted: m });
} else if (_menu.teks) {
  menu = await conn.reply(m.chat, list, m);
} else if (_menu.doc) {
  menu = await conn.sendMessage(m.chat, {
    document: fs.readFileSync("./package.json"),
    fileName: namebot,
    fileLength: new Date(), // Pastikan nilai ini sesuai
    pageCount: "2024",
    caption: list,
    jpegThumbnail: await conn.resize((await conn.getFile(docUrl)).data, 180, 72),
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: footer,
        body: wm,
        thumbnailUrl: media.furina,
        renderLargerThumbnail: true,
      },
    }
  }, { quoted: m });
} else if (_menu.footer) {
  let capt = `${headers}`;
  menu = await conn.footerTxt(m.chat, capt, footer, m);
} else if (_menu.footerImg) {
  menu = await conn.footerImg(m.chat, headers + simp, "", media.furina, m);
} else if (_menu.footerVid) {
  menu = await conn.footerVid(m.chat, headers + simp, "", media.gif, m);
} else if (_menu.footerThumbImg) {
  menu = await conn.footerThumbImg(m.chat, headers + simp, "", media.furina, thumb, footer, wm, m);
} else if (_menu.footerThumbVid) {
  menu = await conn.footerThumbVid(m.chat, headers + simp, "", media.gif, thumb, footer, wm, m);
} else if (_menu.buttonV1) {
  menu = await conn.sendListImageButton(m.chat, headers, kyz, "", thumb, quick, m);
} else if (_menu.buttonV2) {
  menu = await conn.sendUrlImageButton(m.chat, headers + simp, quick, "", thumb, m);
} else if (_menu.buttonV3) {
  menu = await conn.sendMessage(m.chat, {
    video: { url: media.gif },
    caption: headers,
    footer: wm,
    viewOnce: true,
    buttons: [
      ...buttonOld,
      {
        buttonId: "ping",
        buttonText: { displayText: "pong" },
        type: 1,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify(datas)
        }
      }
    ],
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterName: wm2,
        newsletterJid: idsal,
        serverMessageId: null
      },
      externalAdReply: {
        title: footer,
        body: wm,
        sourceUrl: "https://chat.whatsapp.com/C9zCqhsLAuwEXkr4xwXEph",
        thumbnailUrl: thumb
      }
    },
    headerType: 5
  }, { quoted: m });
} else if (_menu.buttonV4) {
  menu = await conn.sendButtonProduct(m.chat, thumb, headers, footer, ucapan + name, kyz, m);
}

let kiz = {
  audio: { url: `${pickRandom(vn.menu)}` },
  mimetype: "audio/mpeg",
  ptt: true,
  contextInfo: {
    isForwarded: true,
    mentionedJid: [m.sender],
    businessMessageForwardInfo: {
      businessOwnerJid: wa + jid
    },
    forwardedNewsletterMessageInfo: {
      newsletterName: wm,
      newsletterJid: idsal
    }
  }
};

await conn.sendMessage(m.chat, kiz, { quoted: menu });

  } else if (tagCount[cmd]) {
    const daftarHelp = tagHelpMapping[cmd].map((helpItem, index) => {
      const premiumSign = help[index].premium ? '🅟' : '';
      const limitSign = help[index].limit ? 'Ⓛ' : '';
      return `.${helpItem} ${premiumSign}${limitSign}`;
    })
    .sort()
    .join('\n - '  + ' ');
        let more = String.fromCharCode(8206)
        let readMore = more.repeat(4001)
        
    const list2 =  await style(`${info}${readMore}\n\n-─── 「 *${kyZ()} MENU ${cmd.toUpperCase()} ${kyZ()}* 」 ───-\n - ${daftarHelp}\n-────────────────────-\n\n> • *Total Menu ${cmd}: ${tagHelpMapping[cmd].length}* ✨`, 1
)
    const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
     
if (_menu.image) {
conn.sendMessage(m.chat, {
      text: list2,
      contextInfo: { mentionedJid: [m.sender], 
            externalAdReply: {
            title: footer, 
            body: wm, 
            thumbnailUrl: media.furina, 
            renderLargerThumbnail: true, 
            }, 
      }}, {quoted: m})
      
      } else if (_menu.gif) {
conn.sendMessage(m.chat, {
      video: {url: 'https://telegra.ph/file/3586d0daf888a60520e1f.mp4'},
      gifPlayback: true,
      caption: list2,
      contextInfo: { mentionedJid: [m.sender], 
            externalAdReply: {
            title: footer, 
            body: wm, 
            thumbnailUrl: media.furina, 
            renderLargerThumbnail: true, 
            }, 
      }}, {quoted: m})

} else if (_menu.teks) {
conn.reply(m.chat, list2, m)

} else if (_menu.doc) {
conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            fileName: namebot,
            fileLength: new Date(),
            pageCount: "2024",
            jpegThumbnail: await conn.resize((await conn.getFile(docUrl)).data, 180, 72),
            caption: list2,
            contextInfo: { mentionedJid: [m.sender], 
            externalAdReply: {
            title: footer, 
            body: wm, 
            thumbnailUrl: media.furina, 
            renderLargerThumbnail: true, 
            }, 
            }, 
          }, {quoted: m});
          
          } else if (_menu.footer) {
conn.footerTxt(m.chat, list2, footer, m)

          } else if (_menu.footerImg) {
conn.footerImg(m.chat, list2, footer, media.furina, m)

          } else if (_menu.footerVid) {
conn.footerVid(m.chat, list2, footer, media.gif, m)

          } else if (_menu.footerThumbImg) {
conn.footerThumbImg(m.chat, list2, "", media.furina, thumb, footer, wm, m)

          } else if (_menu.footerThumbVid) {
conn.footerThumbVid(m.chat, list2, "", media.gif, thumb, footer, wm, m)

          } else if (_menu.buttonV1) {
          conn.sendListImageButton(m.chat, list2, kyz, footer, thumb, quick, m)
          
          } else if (_menu.buttonV2) {
          conn.sendUrlImageButton(m.chat, list2, quick, footer, thumb, m)
          
          } else if (_menu.buttonV3) {
          await conn.sendMessage(m.chat, {
        video: { url: media.gif },
        caption: list2,
        footer: wm,
        viewOnce: true,
        buttons: [
            ...buttonOld, 
         {
         	buttonId: "ping", 
         buttonText: {
         	displayText: "pong"
         }, 
         type: 1,
         nativeFlowInfo: {
         	name: "single_select", 
         paramsJson: JSON.stringify(datas) 
         }
         }
        ],
        contextInfo: {
        isForwarded: true, 
        forwardingScore: 999,
        mentionedJid: [m.sender], 
        forwardedNewsletterMessageInfo: { newsletterName: wm2, newsletterJid: idsal, serverMessageId: null }, 
        externalAdReply: {
        title: footer, 
        body: wm, 
        sourceUrl: "https://chat.whatsapp.com/C9zCqhsLAuwEXkr4xwXEph", 
        thumbnailUrl: thumb
        }, 
        }, 
        headerType: 4 
    }, { quoted: m });
        } else if (_menu.buttonV4) {
        conn.sendButtonProduct(m.chat, thumb, headers, footer, ucapan + name, kyz, m)
        }
        } else if (cmd === 'all' || command === 'allmenu') {
    let name = m.pushName || conn.getName(m.sender)
    const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/bf29252842366db5ae047.jpg");
    
          const more = String.fromCharCode(8206)
          const readMore = more.repeat(4001)
          const allTagsAndHelp = Object.keys(tagCount).map(tag => {
         const daftarHelp = tagHelpMapping[tag].map((helpItem, index) => {
        const premiumSign = help[index].premium ? '🅟' : '';
        const limitSign = help[index].limit ? 'Ⓛ' : '';
        return ` .${helpItem} ${premiumSign}${limitSign}`;
      })
      .sort()
      .join('\n -' + ' ');
      return `\n-─── 「 *${kyZ()} MENU ${tag} ${kyZ()}* 」 ───-\n - ${daftarHelp}\n-────────────────────-\n`
    })
    .sort()
    .join('\n');
    let all =  await style(`${info}\n${readMore}${allTagsAndHelp}\n> ✨ *Semoga Anda Puas Dengan Fitur Yang Kami Sediakan* ✨`, 1) 
    
    if (_menu.image) {
conn.sendMessage(m.chat, {
      text: all,
      contextInfo: { mentionedJid: [m.sender], 
            externalAdReply: {
            title: footer, 
            body: wm, 
            thumbnailUrl: media.furina, 
            renderLargerThumbnail: true, 
            }, 
      }}, {quoted: m})
      
      } else if (_menu.gif) {
conn.sendMessage(m.chat, {
      video: {url: 'https://telegra.ph/file/3586d0daf888a60520e1f.mp4'},
      gifPlayback: true,
      caption: all,
      contextInfo: { mentionedJid: [m.sender], 
            externalAdReply: {
            title: footer, 
            body: wm, 
            thumbnailUrl: media.furina, 
            renderLargerThumbnail: true, 
            }
      }}, {quoted: m})

} else if (_menu.teks) {
conn.reply(m.chat, all, m)

} else if (_menu.doc) {
conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            fileName: namebot,
            fileLength: new Date(),
            pageCount: "2024",
            caption: all,
            jpegThumbnail: await conn.resize((await conn.getFile(docUrl)).data, 180, 72),
            contextInfo: { mentionedJid: [m.sender], 
            externalAdReply: {
            title: footer, 
            body: wm, 
            thumbnailUrl: media.furina, 
            renderLargerThumbnail: true, 
            }, 
           }
          }, {quoted: m});
          
          } else if (_menu.footer) {
conn.footerTxt(m.chat, all, footer, m)

          } else if (_menu.footerImg) {
conn.footerImg(m.chat, all, footer, media.furina, m)

          } else if (_menu.footerVid) {
conn.footerVid(m.chat, all, footer, media.gif, m)

          } else if (_menu.footerThumbImg) {
conn.footerThumbImg(m.chat, all, "", media.furina, thumb, footer, wm, m)

          } else if (_menu.footerThumbVid) {
conn.footerThumbVid(m.chat, "\n────< ғᴜʀɪɴᴀ - ᴀsɪssᴛᴀɴᴛ>────\n\n"+all, "", media.gif, thumb, footer, wm, m)

          } else if (_menu.buttonV1) {
          conn.sendListImageButton(m.chat, all, kyz, footer, thumb, quick, m)
          
          } else if (_menu.buttonV2) {
          conn.sendUrlImageButton(m.chat, all, quick, footer, thumb, m)
          
          } else if (_menu.buttonV3) {
          await conn.sendMessage(m.chat, {
        video: { url: media.gif },
        caption: all,
        footer: wm,
        viewOnce: true,
        buttons: [
            ...buttonOld, 
         {
         	buttonId: "ping", 
         buttonText: {
         	displayText: "pong"
         }, 
         type: 1,
         nativeFlowInfo: {
         	name: "single_select", 
         paramsJson: JSON.stringify(datas) 
         }
         }
        ],
        contextInfo: {
        isForwarded: true, 
        forwardingScore: 999,
        mentionedJid: [m.sender], 
        forwardedNewsletterMessageInfo: { newsletterName: wm2, newsletterJid: idsal, serverMessageId: null }, 
        externalAdReply: {
        title: footer, 
        body: wm, 
        sourceUrl: "https://chat.whatsapp.com/C9zCqhsLAuwEXkr4xwXEph", 
        thumbnailUrl: thumb
        }, 
        }, 
        headerType: 4 
    }, { quoted: m });
        } else if (_menu.buttonV4) {
        conn.sendButtonProduct(m.chat, thumb, headers, footer, ucapan + name, kyz, m)
        } else {
  await conn.reply(m.chat, `Mᴇɴᴜ '${cmd}' ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪᴛᴇᴍᴜᴋᴀɴ. ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ '${command}' ᴀᴛᴀᴜ '${command} all' ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴍᴇɴᴜ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ.`,m);
  }
     await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
    }
}
handler.help = ['menu']
handler.tags = ['main']
handler.command = ['menu', 'k']
export default handler

//----------- FUNCTION -------

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, ' H ', m, ' M ', s, ' S '].map(v => v.toString().padStart(2, 0)).join('')
}
function clockStringP(ms) {
  let ye = isNaN(ms) ? '--' : Math.floor(ms / 31104000000) % 10
  let mo = isNaN(ms) ? '--' : Math.floor(ms / 2592000000) % 12
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000) % 30
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [ye, ' *Years 🗓️*\n',  mo, ' *Month 🌙*\n', d, ' *Days ☀️*\n', h, ' *Hours 🕐*\n', m, ' *Minute ⏰*\n', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}
function kyZ() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "🪐"
  if (time >= 4) {
    res = "🌤"
  }
  if (time >= 10) {
    res = "☀"
  }
  if (time >= 15) {
    res = "🌥"
  }
  if (time >= 18) {
    res = "🌙"
  }
  return res
}

async function getIndonesianHolidays(year) {
    return [
        { name: "Tahun Baru Masehi", date: new Date(year, 0, 1) },
        { name: "Hari Raya Nyepi", date: new Date(year, 2, 22) },
        { name: "Hari Buruh Internasional", date: new Date(year, 4, 1) },
        { name: "Hari Raya Waisak", date: new Date(year, 4, 22) },
        { name: "Hari Raya Idul Fitri", date: new Date(year, 2, 32) },
        { name: "Hari Raya Idul Adha", date: new Date(year, 5, 7) }, 
        { name: "Hari Kemerdekaan RI", date: new Date(year, 7, 17) },
        { name: "Hari Raya Natal", date: new Date(year, 11, 25) }
    ];
}

async function countdownTo(date) {
    const now = new Date();
    now.setHours(now.getHours() + 7);
    const diff = date - now;
    if (diff <= 0) return `telah berlalu.`;

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    return `${days} hari lagi`;
}

async function displayNextHoliday() {
    const year = new Date().getFullYear();
    const holidays = await getIndonesianHolidays(year);
    const now = new Date();
    now.setHours(now.getHours() + 7);
    const upcomingHoliday = holidays.find(holiday => holiday.date > now);

    if (upcomingHoliday) {
        return `${upcomingHoliday.name}\n dalam: ${await countdownTo(upcomingHoliday.date)}`;
    } else {
        const nextYearHolidays = await getIndonesianHolidays(year + 1);
        return `${nextYearHolidays[0].name}\n dalam ${await countdownTo(nextYearHolidays[0].date)}`;
    }
}

async function displayCountdowns() {
    const now = new Date();
    const year = new Date().getFullYear();
    const holidays = await getIndonesianHolidays(year);
    let countdownMessages = [];

    for (const holiday of holidays) {
        if (holiday.date < now) {
            holiday.date.setFullYear(holiday.date.getFullYear() + 1);
        }
        countdownMessages.push(`${holiday.name} = ${await countdownTo(holiday.date)}`);
    }

    const nextBirthday = new Date(now.getFullYear(), 4, 18);
    if (now > nextBirthday) nextBirthday.setFullYear(now.getFullYear() + 1);
    countdownMessages.push(`*Ulang Tahun Creator* = ${await countdownTo(nextBirthday)}`);

    return countdownMessages.join("\n");
}