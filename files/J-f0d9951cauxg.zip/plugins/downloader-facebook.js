/* fb downloader
Cjs
*/
import fetch from 'node-fetch';

const handler = async (m, { text, conn }) => {
    if (!text) {
        return m.reply('woi mana link nya');
    }

    try {
        const response = await fetch(`https://api.vreden.web.id/api/fbdl?url=${encodeURIComponent(text)}`);
        const result = await response.json();

        if (!result || !result.data || (!result.data.hd_url && !result.data.sd_url)) {
            return m.reply('error mek😹😹. Cek URL atau coba lagi nanti.');
        }

        const { hd_url, sd_url, title, durasi } = result.data;
        const videoUrl = hd_url || sd_url;

        await conn.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: `🎥 *Judul:* ${title}\n⏳ *Durasi:* ${durasi}`
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        m.reply('ahh error lari.');
    }
};

handler.help = ['fb <url>'];
handler.tags = ['downloader'];
handler.command = /^fb$/i;

export default handler;