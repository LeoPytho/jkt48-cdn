import fetch from 'node-fetch';

const handler = async (m, { conn, text }) => {
let [type, teks] = text.split("|")
if (!type) throw `[❗] Input Type:\nEx: /nulis kanan|Hallo`
if (!teks) throw `[❗] Input Teks:\nEx: /nulis kanan|Hallo`
if (type === "kiri") {
  if (!teks) throw '[❗] Ex:\n/nulis kiri|hai';
  m.reply('Tunggu sebentar...');
  const url = `https://api.zeeoneofc.my.id/api/canvas/nuliskiri?apikey=RCo6vEcS&text=${encodeURIComponent(teks)}`;
  conn.sendFile(m.chat, url, '', '', m);
  }
if (type === "kanan") {
  if (!teks) throw '[❗] Ex:\n/nulis kanan|hai';
  m.reply('Tunggu sebentar...');
  const url = `https://api.zeeoneofc.my.id/api/canvas/nuliskanan?apikey=RCo6vEcS&text=${encodeURIComponent(teks)}`;
  conn.sendFile(m.chat, url, '', '', m);
  }
};

handler.help = ['nulis kanan|hai','nulis kiri|hai'];
handler.tags = ['maker'];
handler.command = /^nulis$/i;
handler.limit = true;

export default handler;
