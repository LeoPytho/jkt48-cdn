/*
𝙆𝙮𝙯𝙍𝙮𝙯𝙯 𝙓𝘿
𝘊𝘳𝘦𝘢𝘵𝘰𝘳 𝘉𝘰𝘵 𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱
𝘵𝘦𝘭𝘦: t.me/kyzoffc
🚨Di Larang Menghapus Wm Ini🚨
*/
const { generateWAMessageFromContent, proto } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {
let header = `⟥⟞⟚━┈┈ ❨  ɪɴғᴏ ᴛqᴛᴏ ❩ ┈┈━⟚⟝⟤

*Rᴇᴄᴏᴅᴇ Bʏ* : OᴡᴇɴꜱDᴇᴠ
*Wᴀ Dᴇᴠᴇʟᴏᴘᴇʀ* : wa.me//6285358977442
*Sᴄ Bᴀsᴇ* : Zyko
*Mʏ Pʀᴏᴊᴇᴄᴛ* : 12 𝑀𝑒𝑖 2024`

let footer = `\n*⫹❰⫺ Bɪɢ Tʜᴀɴᴋs Tᴏ ⫹❱⫺*
> ⭝ OᴡᴇɴꜱDᴇᴠ (ᴍʏ sᴇʟғ) 
> ⭝ Aʟʟᴀʜ Yᴀɴɢ Mᴀʜᴀ Esᴀ
> ⭝ Oʀᴀɴɢ Tᴜᴀ
> ⭝ Tᴇᴍᴇɴ-ᴛᴇᴍᴇɴ Sᴇᴍᴜᴀ
> ⭝ Mᴀsᴛᴀʜ - Mᴀsᴛᴀʜ

*⫹⫺ Tʜᴇ Nᴀᴍᴇ Tʜᴀᴛ Hᴇʟᴘᴇᴅ Mᴇ ⫹⫺*
⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔
> ⭝ FᴜʀɪɴɴTᴇᴀᴍ (ᴛᴇᴀᴍ)
> ⭝ Kᴀɴɢғᴀʀʀᴇʟ (ᴍʏ ғʀɪᴇɴᴅ)
> ⭝ Rᴀғɪᴋᴢ (ᴍʏ ғʀɪᴇɴᴅ)

*⫹❰⫺ Tʜᴀɴᴋs Tᴏᴏ ⫹❱⫺*
> ⭝ Zʏᴋo (sᴄ ʙᴀsᴇ)
> ⭝ Aᴅɪᴡᴀᴊsʜɪɴɢ (ʙᴀɪʟᴇʏs)
> ⭝ Wʜɪsᴋᴇʏ (ʙᴀɪʟᴇʏs sᴜᴘᴘ)
> ⭝ ғᴇʟᴢᴀʀ (ʙᴀɪʟᴇʏs sᴜᴘᴘ)
> ⭝ Bᴏᴄʜɪʟᴛᴇᴀᴍ
> ⭝ Fɢsɪ Dᴇᴠ
> ⭝ Kʏᴜᴜʀᴢʏ
> ⭝ Hᴀɴɴ
> ⭝ Nuʀᴜᴛᴏᴍᴏ
> ⭝ Aʀɪʟ Mᴅ
> ⭝ Lorenzo
> ⭝ Wʜ Mᴏᴅs Dᴇᴠ
> ⭝ Tɪᴏxʏ
> ⭝ Rᴇʏᴢ Hᴀʏᴀɴᴀsɪ
> ⭝ SᴄRᴀPᴇ ᴛᴇᴀᴍ
> ⭝ Uᴅɪɴɴ


*⫹❰⫺ Tʜᴀɴᴋs Fᴏʀ ⫹❱⫺*
> ⭝ sᴇᴍᴜᴀ ʏᴀɴɢ ᴛᴇʟᴀʜ ʙᴇʀᴋᴏɴᴛʀɪʙᴜsɪ ᴘᴀᴅᴀ ᴘᴇɴɢᴇᴍʙᴀɴɢᴀɴ ʙᴏᴛ ɪɴɪ
> ⭝ ᴋᴀʟɪᴀɴ sᴇᴍᴜᴀ ʏɢ ᴜᴅᴀʜ ɢᴜɴᴀɪɴ ʙᴏᴛɴʏᴀ🤗
`

let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: footer,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "\n© ғᴜʀɪɴᴀ - ᴀɪ ᴘʀᴏᴊᴇᴄᴛs ʙʏ OᴡᴇɴꜱDᴇᴠ",
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: header,
            subtitle: "",
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
             ],
          })
        })
    }
  }
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: '*Thank You To Everyone Who Has Contributed To The Development Of This Bot 🥰* - OᴡᴇɴꜱDᴇᴠ '}}})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}               
handler.help = ['tqto','credit']
handler.tags = ['info']
handler.command = /^(tqto|credit|cr)$/i

export default handler