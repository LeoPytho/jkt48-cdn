let { getDevice } = (await import("@adiwajshing/baileys"));

let handler = async(m, { conn }) => {
  let target;
  if (m.quoted) {
  target = m.quoted;
 } else {
  target = m;
}
  if (!target) throw "[❗] tidak ada id yg bisa dideteksi";
  try {
    let { key } = await m.reply(wait);
    await conn.sendMessage(m.chat, { text: `[📌] Target: ${target?.id || 'unknown'}\n[👤] User: ${target?.sender.split("@")[0] || 'undefined'} ~${await conn.getName(target.sender) || 'unknown'}\n[🖥] TheDevice: ${getDevice(target?.id) ||'unknown'}\n`, edit: key }, { quoted: m });
  } catch (e) {
    return e.message;
  };
};
handler.help = handler.command = ["getdevice"];
handler.tags = ["info"];
handler.limit = true;

export default handler;