/**
 * By: KyzRyzz XD
 * 𝘁𝗲𝗹𝗲: https://t.me/kyzryzz
 * 𝘪𝘯𝘧𝘰: https://s.id/kyzzxd
 * 𝘺𝘁: https://youtube.com/KyzXD
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗽𝗲𝗺𝗯𝘂𝗮𝘁  
**/

import axios from 'axios';
let { proto, prepareWAMessageMedia, generateWAMessageFromContent } = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
if (!text) throw m.reply(`[❗] Masukan Query! 
Contoh: ${usedPrefix + command} jj furina`)
    m.reply(wait);
    try {
        const result = await tiktoks(text);
        let cap = result.title;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: cap
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: wm
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            ...(await prepareWAMessageMedia({ video: { url: result.no_watermark } }, { upload: conn.waUploadToServer })),
                            title: '*🫧 T i k T o k - S E A R C H*',
                            gifPlayback: true,
                            subtitle: '',
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{
                                "name": "quick_reply",
                                "buttonParamsJson": `{\"display_text\":\"Nᴇxᴛ ᴠɪᴅᴇᴏ 🎥\",\"id\":\".ttsearch ${text}\"}`
                            },
                            {
            name: "cta_url",
            buttonParamsJson: `{"display_text":"Sᴏᴜɴᴅ 🎶","url":"${result.music}","merchant_url":"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q"}`
                            }]
                        }),
                        contextInfo: {
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363247149539361@newsletter',
                                newsletterName: '🔮 Powered By KyzRyzz',
                                serverMessageId: null
                            }
                        }
                    })
                }
            }
        }, { quoted: m });

        await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    } catch (err) {
        m.reply(eror);
    }
}

handler.help = ['ttiktoksearch2'];
handler.tags = ['downloader'];
handler.command = /^(ttsearch2|tiktoksearch2|ttsrc)$/i;
handler.limit = true;
handler.register = true;

export default handler;

async function tiktoks(query) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios({
                method: 'POST',
                url: 'https://tikwm.com/api/feed/search',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Cookie': 'current_language=en',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                },
                data: new URLSearchParams({
                    keywords: query,
                    count: 10,
                    cursor: 0,
                    HD: 1
                }).toString()
            });

            const videos = response.data.data.videos;
            if (videos.length === 0) {
                reject("Tidak Ada, Video yang Anda Cari Tidak Ditemukan.");
            } else {
                const gywee = Math.floor(Math.random() * videos.length);
                const videorndm = videos[gywee];

                const result = {
                    title: videorndm.title,
                    cover: videorndm.cover,
                    origin_cover: videorndm.origin_cover,
                    no_watermark: videorndm.play,
                    watermark: videorndm.wmplay,
                    music: videorndm.music
                };
                resolve(result);
            }
        } catch (error) {
            reject(error.message || 'An error occurred');
        }
    });
}