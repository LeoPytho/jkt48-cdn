import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix, command }) => {
    let text;
    if (args.length >= 1) {
        text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        throw 'Input teks atau reply teks!';
    }

    await m.reply("Processing...");

    try {
        let response = await axios.get(`https://widipe.com/bingimg?text=${encodeURIComponent(text)}`);
        let img = response.data; // Adjust based on actual API response structure
        
        if (!img || img.length === 0) {
            throw 'No images found.';
        }

        for (let i = 0; i < img.length; i++) {
            await conn.sendFile(
                m.chat,
                img[i],
                '',
                `Image *(${i + 1}/${img.length})*\n\n*Prompt*: ${text}`,
                m,
                false,
                {
                    mentions: [m.sender],
                }
            );
        }
    } catch (error) {
        console.error(`Error sending file: ${error.message}`);
        await m.reply(`Failed to send images: ${error.message}`);
    }
};

handler.help = ["bing-img *[query]*"];
handler.tags = ["ai","premium"];
handler.command = /^(bing(img|-img|-image|image)?)$/i;
handler.premium = true;

export default handler;