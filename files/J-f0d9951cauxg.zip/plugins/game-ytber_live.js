let handler = async (m, { conn, args, text }) => {
    let user = global.db.data.users[m.sender]
    let name = user.name
    let aku = user.subscriber

    if (user.subscriber === 0) {
        return conn.reply(m.chat, `[❗] Kamu tidak memiliki akun YouTube, silahkan buat terlebih dahulu,\n\nKetik: .buatyt`, m)
    }

    let timie = (new Date() - (user.lastlive * 1)) * 1
    if (timie < 500000) {
        return m.reply(`[❗] Hari ini kamu sudah live YouTube, silahkan Beristirahat\n\nSelama ${clockString(500000 - timie)}`)
    }
    if (!text) {
        return conn.reply(m.chat, `[🔴] Judul Live nya apa?\nContoh: .live Mandi bareng alya`, m)
    }
    if (text.split('').length > 25) {
        return conn.reply(m.chat, `[❗] Panjang Judul Maximal 25 Karakter`, m)
    }

    let money = 0, subs = 0, like = 0, donate = 0;
    // Subscriber thresholds and rewards
    if (user.subscriber > 10000000) {
        money = Math.floor(Math.random() * 5000000);
        subs = Math.floor(Math.random() * 10000);
        like = Math.floor(Math.random() * 600000);
        donate = Math.floor(Math.random() * 1500000);
        if (user.diamondplaybutton < 1) {
            user.diamondplaybutton = 1;
            conn.reply(m.chat, `[❗] *Selamat ${name}*\nkamu mendapatkan Diamond Play Button atas kenaikan ${aku.toLocaleString()} subscriber! 🎉💎`, m);
        }
    } else if (user.subscriber > 1000000) {
        money = Math.floor(Math.random() * 500000);
        subs = Math.floor(Math.random() * 6000);
        like = Math.floor(Math.random() * 300000);
        donate = Math.floor(Math.random() * 5500000);
        if (user.goldplaybutton < 1) {
            user.goldplaybutton = 1;
            conn.reply(m.chat, `[❗] *Selamat ${name}*\nkamu mendapatkan Gold Play Button atas kenaikan ${aku.toLocaleString()} subscriber! 🎉🥇`, m);
        }
    } else if (user.subscriber > 500000) {
        money = Math.floor(Math.random() * 230000);
        subs = Math.floor(Math.random() * 2000);
        like = Math.floor(Math.random() * 5000);
        donate = Math.floor(Math.random() * 250000);
    } else if (user.subscriber > 100000) {
        money = Math.floor(Math.random() * 150000);
        subs = Math.floor(Math.random() * 1000);
        like = Math.floor(Math.random() * 30000);
        donate = Math.floor(Math.random() * 150000);
        if (user.silverplaybutton < 1) {
            user.silverplaybutton = 1;
            conn.reply(m.chat, `[❗] *Selamat ${name}*\nkamu mendapatkan Silver Play Button atas kenaikan ${aku.toLocaleString()} subscriber! 🎉🥈`, m);
        }
    } else if (user.subscriber > 50000) {
        money = Math.floor(Math.random() * 80000);
        subs = Math.floor(Math.random() * 500);
        like = Math.floor(Math.random() * 3000);
        donate = Math.floor(Math.random() * 90000);
    } else if (user.subscriber > 10000) {
        money = Math.floor(Math.random() * 60000);
        subs = Math.floor(Math.random() * 200);
        like = Math.floor(Math.random() * 2000);
        donate = Math.floor(Math.random() * 70000);
    } else if (user.subscriber > 1000) {
        money = Math.floor(Math.random() * 30000);
        subs = Math.floor(Math.random() * 130);
        like = Math.floor(Math.random() * 1000);
        donate = Math.floor(Math.random() * 45000);
    } else if (user.subscriber > 100) {
        money = Math.floor(Math.random() * 15000);
        subs = Math.floor(Math.random() * 90);
        like = Math.floor(Math.random() * 500);
        donate = Math.floor(Math.random() * 25000);
    } else {
        money = Math.floor(Math.random() * 5000);
        subs = Math.floor(Math.random() * 50);
        like = Math.floor(Math.random() * 100);
        donate = Math.floor(Math.random() * 15000);
    }

    user.money += money;
    user.subscriber += subs;
    user.like += like;
    user.liketotal += like;
    user.bank += donate;
    user.lastlive = new Date() * 1;

    let totlike = user.liketotal.toLocaleString();
    let subse = user.subscriber.toLocaleString();
    let mentionedJid = [m.sender];
    let str = `[ 🔴 *LIVE YOUTUBE* ]

┌──[ *Hasil Dari Streaming* ]
│👤 *Streamer:* @${m.sender.replace(/@.+/, '')}
│📹 *Judul Live:* ${text}
│💸 *Money:* +${money.toLocaleString()}      
│💳 *Donasi:* +${donate.toLocaleString()}
│👥 *New Subscriber:* +${subs.toLocaleString()}       
│👍🏻 *New Like:* +${like.toLocaleString()}
└┬───⬤
  │📊 *Total Like:* ${totlike}
  │📈 *Total Subscriber:* ${subse}
  └──────⬤

Cek akun YouTubemu
ketik _.akunyt_`;

    conn.reply(m.chat, str, m, { contextInfo: { mentionedJid } });
    setTimeout(() => {
        conn.reply(m.chat, `[❗] Heii @${m.sender.replace(/@.+/, '')}, Subscribersmu menunggumu, Ayo live kembali..`, m, { contextInfo: { mentionedJid: m.sender } })
    }, 600000);
}

handler.tags = ['rpg', 'game'];
handler.help = ['live','streaming'];
handler.command = /^(live|streaming)$/i;
handler.register = true;
handler.group = true;

export default handler;

function clockString(ms) {
    let h = Math.floor(ms / 3600000) % 60;
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}