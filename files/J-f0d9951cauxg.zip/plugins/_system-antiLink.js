const handler = m => m;

const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;

handler.before = async function(m, { user, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;
  
  const chat = global.db.data.chats[m.chat];
  const isGroupLink = linkRegex.exec(m.text);

  if (chat.antiLink && isGroupLink) {
    await m.reply(`*「 ANTI LINK 」*\n\nTerdeteksi *${await conn.getName(m.sender)}* Anda telah mengirimkan tautan grup!\n\nMaaf anda akan di kick dari grup`);
    
    if (isAdmin) return m.reply('*Admin mah bebas ye kan..*');
    if (!isBotAdmin) return m.reply('*Yah Gk Bisa Kick bot bukan Admin*');
    
    const linkGC = ('https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat));
    const isLinkconnGc = new RegExp(linkGC, 'i');
    const isgclink = isLinkconnGc.test(m.text);
    
    if (isgclink) return m.reply('*「 ANTI LINK 」*\n\nPesanan ditolak, bot tidak akan menendang Anda.\nKarena tautan grup itu sendiri');
    
    await conn.sendMessage(m.chat, { delete: m.key });
    await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
  }
  
  return true;
};

export default handler;

export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}