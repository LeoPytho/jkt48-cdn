let handler = async (m, { conn, text, args, command, usedPrefix }) => {
    if (!text) throw 'Mana Kak Linknya?'
    try {
        const { data } = await axios.get(`${APIs.ft}/download/tiktok?url=${url}`);
        const { metadata } = data.result;
        const slide = metadata.download.slide;
        const audio = metadata.download.audio;

        if (slide.length > 0) {
            for (let i = 0; i < slide.length; i++) {
                await conn.sendMessage(
                    m.chat,
                    { image: { url: slide[i] }, caption: `` },
                    { quoted: m }
                );
            }
        }
        if (audio) {
                await conn.sendAudio(
                    m.chat,
                    audio, false,
                    m
                );
            }
        m.reply(`Tetap support terus ${global.namebot}\njangan lupa donasi dibawah nomer bot ini ${global.nomorown}`)
    } catch (error) {
        m.reply('Ada yang error, hubungi owner untuk memperbaikinya');
        console.error(error); 
    }
}

handler.help = ['tiktokimg / ttimg <url>']
handler.tags = ['downloader']
handler.command = /^(ttimg|tiktokimg)$/i

export default handler
