import axios from 'axios';

let timeout = 120000;
let poin = 4999;

let handler = async (m, { conn, command, usedPrefix }) => {
  conn.tebaklogo = conn.tebaklogo || {};
  let id = m.chat;

  if (id in conn.tebaklogo) {
    conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebaklogo[id][0]);
    return;
  }

  let res = await axios.get("https://raw.githubusercontent.com/orderku/db/main/dbbot/game/tebakapp.json");
  let data = res.data;
  let item = pickRandom(data).data;
  let image = item.image;
  let jawaban = item.jawaban;

  let caption = `*TEBAK LOGO*\nLogo apakah ini?\n\n🕒 Timeout: *${(timeout / 1000)} detik*\n📌 Ketik *${usedPrefix}hlog* untuk bantuan\n🎁 Bonus: *${poin} XP*\n\nBalas pesan ini untuk menjawab!`;

  let sentMsg = await conn.sendMessage(m.chat, {
    image: { url: image },
    caption,
  }, { quoted: m });

  conn.tebaklogo[id] = [
    sentMsg,
    jawaban.toLowerCase().trim(),
    poin,
    setTimeout(() => {
      if (conn.tebaklogo[id]) {
        conn.reply(m.chat, `⏰ Waktu habis!\nJawabannya adalah *${jawaban}*`, conn.tebaklogo[id][0]);
        delete conn.tebaklogo[id];
      }
    }, timeout)
  ];
};

handler.before = async (m, { conn }) => {
  conn.tebaklogo = conn.tebaklogo || {};
  let id = m.chat;

  if (!(id in conn.tebaklogo)) return;
  let [soalMsg, jawaban, poin, timeoutObj] = conn.tebaklogo[id];

  // Hanya jika membalas pesan soal
  if (!m.quoted || m.quoted.id !== soalMsg.key.id) return;

  let text = m.text.toLowerCase().trim();
  if (text === jawaban) {
    global.db.data.users[m.sender].exp += poin;
    clearTimeout(timeoutObj);
    conn.reply(m.chat, `✅ *Benar!*\nKamu mendapatkan +${poin} XP!`, m);
    delete conn.tebaklogo[id];
  } else if (isAlmostCorrect(text, jawaban)) {
    conn.reply(m.chat, `🤏 *Hampir benar!* Coba lagi ya.`, m);
  } else {
    conn.reply(m.chat, `❌ *Salah!* Coba lagi.`, m);
  }
};

function isAlmostCorrect(user, correct) {
  let minLen = Math.min(user.length, correct.length);
  let match = 0;
  for (let i = 0; i < minLen; i++) {
    if (user[i] === correct[i]) match++;
  }
  return match / correct.length >= 0.6;
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

handler.help = ['tebaklogo'];
handler.tags = ['game'];
handler.command = /^tebaklogo$/i;

export default handler;