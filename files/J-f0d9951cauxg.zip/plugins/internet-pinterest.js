import fetch from 'node-fetch';
import axios from 'axios';
const { proto, generateWAMessageFromContent, generateWAMessageContent } = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, text, args, usedPrefix: _p, command }) => {
  if (!text) return m.reply(`❕ Wrong Input\nExample: ${_p + command} furina`);
  let [query, count] = text.split('|').map(v => v.trim());
  count = Math.min(parseInt(count) || 1, 10);
  
  if (command === "pin" || command === "pinterest") {
    m.reply("[ ⏱️ Process ]");
    let result = await pinterest(text);
    let cmd = _p + command + ' ' + text;
    let sections = [{
      highlight_label: 'New 🔥',
      rows: [
        { title: "Pinterest Album", description: `Search: ${query}`, id: `${_p}album1 ${text}` },
        { title: "Pinterest Slide", description: `Search: ${query}`, id: `${_p}slide1 ${text}` }
      ]
    }];
    let listMessage = { title: "[ ᴄᴏᴍᴍᴀɴᴅ ʟᴀɪɴɴʏᴀ ]", sections };
    const buttons = [
      { buttonId: cmd, buttonText: { displayText: 'ɴᴇxᴛ 🔍' } },
      {
        buttonId: 'audio_dummy',
        buttonText: { displayText: "🎶 ᴀᴜᴅɪᴏ" },
        nativeFlowInfo: { name: "single_select", paramsJson: JSON.stringify(listMessage) }
      }
    ];
    conn.sendMessage(m.chat, {
      image: { url: pickRandom(result) },
      caption: "pinterest result: " + query,
      footer: global.wm || "Powered by OwensDev",
      viewOnce: true, 
      buttons,
      headerType: 4
    }, { quoted: m });

  } else if (command === "album1") {
    let numbers = Array.from({ length: 15 }, (_, i) => i + 1);
    let sections = numbers.map(num => ({
      rows: [{ title: `Count: ${num}`, id: `${_p}album ${text}|${num}` }]
    }));
    let listMessage = { title: "[ pilih count image ]", sections };
    conn.sendMessage(m.chat, {
      text: "berapa banyak image pinterest versi album yang ingin kamu inginkan.",
      title: "Pilih count image",
      footer: "> Maksimal 15 count",
      interactiveButtons: [{
        name: "single_select",
        buttonParamsJson: JSON.stringify(listMessage)
      }]
    }, { quoted: m });

  } else if (command === "album") {
    let json = await pinterest(query);
    shuffleArray(json);
    let p = json.slice(0, count);
    let medias = [];
    for (let imageUrl of p) {
      medias.push({
        image: { url: imageUrl },
        caption: text + '\n\n' + '> ' + wm
      });
    }
    await conn.sendAlbumMessage(m.chat, medias, { quoted: m });

  } else if (command === "slide1") {
    let numbers = Array.from({ length: 15 }, (_, i) => i + 1);
    let sections = numbers.map(num => ({
      rows: [{ title: `Count: ${num}`, id: `${_p}slide ${text}|${num}` }]
    }));
    let listMessage = { title: "[ pilih count image ]", sections };
    conn.sendMessage(m.chat, {
      text: "berapa banyak image pinterest versi slide yang ingin kamu inginkan",
      title: "Pilih count image",
      footer: global.wm || "",
      interactiveButtons: [{
        name: "single_select",
        buttonParamsJson: JSON.stringify(listMessage)
      }]
    }, { quoted: m });

  } else if (command === "slide") {
    let resArr = await pinterest(query);
    shuffleArray(resArr);
    let ult = resArr.slice(0, count);

    if (!count) throw `❗ masukkan number\nEx: /${command} furina|3`;

    let i = 1;
    let card = [];
    for (let pus of ult) {
      card.push({
        image: { url: pus },
        title: `${query}`,
        caption: `🔖Result ke - ${i++}`,
        footer: `> ${wm}`,
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "🔍 Source",
              url: pus
            })
          }
        ]
      });
    }

    await conn.sendMessage(
      m.chat,
      {
        text: "[ P i n t e r e s t - S l i d e ]",
        footer: `> 🔮 Prompt: ${query}`,
        cards: card
      },
      { quoted: m }
    );
  }
};

handler.help = ['pinterest'];
handler.tags = ['downloader'];
handler.command = /^(pinterest|pin|pinalbum|album|album1|pinslide|slide|slide1)$/i;
handler.limit = true;
handler.register = true;

export default handler;

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function createImage(url) {
  const { imageMessage } = await generateWAMessageContent({ image: { url } }, { upload: conn.waUploadToServer });
  return imageMessage;
}

async function pinterest(query) {
  let url = `${APIs.ft}/search/pinterest?q=${encodeURIComponent(query)}`;
  let res = await fetch(url);
  let json = await res.json();

  if (!json || !json.result || json.result.length === 0) {
    throw new Error(`Query "${query}" tidak ditemukan.`);
  }

  return json.result.map(furinn => furinn.imageUrl);
}

async function getBuffer(url) {
  let res = await axios.get(url, { responseType: 'arraybuffer' });
  return res.data;
}