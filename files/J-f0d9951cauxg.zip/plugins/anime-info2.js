/*
 • Fitur By Anomaki Team
 • Created : Nazand Code
 • Anime picture search & download
 • Jangan Hapus Wm
 • https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l
  req by :+62 ***-****-4739
*/

import axios from "axios";
import * as cheerio from "cheerio";
const BASE_URL = "https://anime-pictures.net";
const HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:117.0) Gecko/20100101 Firefox/117.0",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://anime-pictures.net/",
    "Cookie": "time_zone=Asia/Jakarta; sitelang=en; animepictures_gdpr={\"choices\":{\"necessary\":true,\"tracking\":true,\"analytics\":true,\"marketing\":true}}; _ga=GA1.1.2120781408.1735557636; aigentx=cookie709bc929fb31400f938c29a26bcb1c6d; _ga_CGRN7Q26LC=GS1.1.1735726375.2.1.1735727209.0.0.0"
};
async function searchImagePages(query, page = 1) {
    const url = `${BASE_URL}/posts?page=${page}&search_tag=${encodeURIComponent(query)}&order_by=date&lang=en`;
    try {
        const {
            data
        } = await axios.get(url, {
            headers: HEADERS
        });
        const $ = cheerio.load(data);
        const results = [];
        $("a[title^='Anime picture']").each((_, el) => {
            let relativeUrl = $(el).attr("href");
            if (relativeUrl) {
                relativeUrl = BASE_URL + relativeUrl;
                relativeUrl = relativeUrl.replace(".//");
                results.push(relativeUrl);
            }
        });
        return results.slice(0, 5);
    } catch (error) {
        console.error("Error saat mencari halaman gambar:", error.message);
        throw new Error("gagal search.");
    }
}

async function getImageFromPage(pageUrl) {
    try {
        const {
            data
        } = await axios.get(pageUrl, {
            headers: HEADERS
        });
        const $ = cheerio.load(data);
        const imgSrc = $("#big_preview").attr("src");
        if (!imgSrc) throw new Error("Gambar tidak ditemukan di halaman!");
        return imgSrc.startsWith("http") ? imgSrc : `https:${imgSrc}`;
    } catch (error) {
        console.error("Error saat mengambil gambar:", error.message);
        throw new Error("url yang valid!.");
    }
}
async function downloadAndSendImage(imgUrl, conn, m) {
    try {
        const response = await axios.get(imgUrl, {
            responseType: "arraybuffer"
        });
        const imageBuffer = Buffer.from(response.data, "binary");

        await conn.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `done ✅`,
        });
    } catch (error) {
        console.error("emror diunfuh:", error.message);
        throw new Error("gagal unduh.");
    }
}
const handler = async (m, {
    conn,
    text
}) => {
    const args = text.split(" ");
    const command = args[0].toLowerCase();
    const queryOrUrl = args.slice(1).join(" ");

    try {
        if (command === "search") {
            const [query, pageStr] = queryOrUrl.split(" ").slice(-2);
            const page = parseInt(pageStr) || 1;
            const queryTerm = queryOrUrl.replace(pageStr, "").trim() || "Miku";

            const searchResults = await searchImagePages(queryTerm, page);
            if (searchResults.length === 0) return m.reply("Tidak ada hasil yang ditemukan!");

            const resultText = searchResults
                .map((url, index) => `${index + 1}. ${url}`)
                .join("\n");

            await conn.sendMessage(m.chat, {
                text: `🔍 Hasil pencarian untuk "${queryTerm}" halaman ${page}:\n\n${resultText}\n\n*Jika hasil Url gak biru hapus saja titik pada bagian (net'.'/post)*`,
            });
        } else if (command === "download") {
            const pageUrl = queryOrUrl.trim();
            if (!pageUrl.startsWith(BASE_URL)) return m.reply("Harap masukkan URL halaman dari anime-pictures.net!");

            const imgUrl = await getImageFromPage(pageUrl);
            await downloadAndSendImage(imgUrl, conn, m);
        } else {
            m.reply("Gunakan perintah `anim search` untuk mencari atau `anim download` untuk mengunduh.");
        }
    } catch (error) {
        console.error(error);
        m.reply(error.message);
    }
};

handler.help = ["anime2 <search query halaman>", "anim <download url halaman>"];
handler.tags = ["anime"];
handler.command = /^(anime2|anim)$/i;
export default handler;