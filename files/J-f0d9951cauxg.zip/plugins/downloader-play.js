/*
Created by KyzRyzz
© kyzryzz.t.me
https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q

TITENONO LEK KO HAPUS😹
*/

import axios from 'axios';
import yts from 'yt-search';

let handler = async function (m, { conn, text, usedPrefix:_p, command }) {
    if (!text) return m.reply('[❗] Masukkan link atau judul YouTube!');
    conn.play = { text }
    try {
        let search = await yts(text);
        if (!search || !search.videos.length) throw '[❗] Video tidak ditemukan, coba judul lain.';
        
        let vid = search.videos[0];
        let { title, thumbnail, timestamp, description, views, ago, url } = vid;
        
        let anu = (await yts(text)).all
        let video = anu.filter(v => v.type === 'video') 
        let channel = anu.filter(v => v.type === 'channel') 

let sections = []

video.forEach(async(data) => {
sections.push({
    title: data.title, 
    highlight_label: 'Pᴏᴘᴜʟᴀʀ ⭐', 
    rows: [{
    header: 'TYPE AUDIO 🔊', 
	title: `${data.title}`,
	description: `${data.timestamp}`, 
	id: `.ytmp3 ${data.url}`
	},
	{
		header: 'TYPE VIDEO 🎥', 
		title: `${data.title}`,
		description: `${data.timestamp}`,
		id: `.ytmp4 ${data.url}`
		}]
	})
})

let listMessage = {
    title: `[ ${video.length} ʀᴇsᴜʟᴛ ʟᴀɪɴɴʏᴀ ]`, 
    sections
};

        const loadingMessages = [
            "Searching Video URL...",
            "Getting data...",
            "Data successfully downloaded ✔..."
        ];

        let { key } = await conn.sendMessage(m.chat, { text: 'Loading...' }, { quoted: m });

        for (let i = 0; i < loadingMessages.length; i++) {
            await delay(1000);
            await conn.sendMessage(m.chat, { text: loadingMessages[i], edit: key }, { quoted: m });
        }

        let caption = `[ URL FOUND ]\n` +
                      `* Title: ${title}\n` +
                      `* Upload At: ${ago}\n` +
                      `* Views: ${views}\n` +
                      `* Duration: ${timestamp}\n` +
                      `* Url: ${url}` + `\n\nUntuk mendownload url YouTube, Reply pesan ini dengan mengetik */audio* untuk download audio atau */video* untuk video.`;
                      
        let btn = [
{
             buttonId: `gada`,
             buttonText: {
                              displayText: "🎶 ᴀᴜᴅɪᴏ",
               }, 
         nativeFlowInfo: {
                "name": "single_select",
                "paramsJson": JSON.stringify(listMessage) 
             }
         }, 
         {
             buttonId: `${_p}yta ${url}`,
             buttonText: {
                              displayText: "🎶 ᴀᴜᴅɪᴏ",
               }
         },
         {
             buttonId: `${_p}ytv ${url}`,
             buttonText: {
                              displayText: "🎥 ᴠɪᴅᴇᴏ",
               }
         }
]; 

        await conn.bubbleThumbImg(m.chat, thumbnail, caption, "atau pilih salah satu tombol dibawah ini", btn, title, description, thumbnail, m)
    } catch (error) {
        console.error(error);
        m.reply(error.message || '[❗] Terjadi kesalahan, coba lagi.');
    }
    delete conn.play
};
handler.help = ['play', 'song', 'lagu'].map(v => v + ' <judul>');
handler.tags = ['downloader'];
handler.command = /^(play|song|lagu)$/i;

export default handler;

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}