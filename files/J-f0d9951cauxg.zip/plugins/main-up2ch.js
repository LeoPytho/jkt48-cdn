let handler = async (m, { conn, text, args, usedPrefix: _p, command }) => {
  let quoted = m.quoted
  if (!text) return m.reply(`🚩 Balas Media dengan ${_p + command} <caption> [untuk mengirim media dengan teks]
Ketik ${_p+command} <teks> [untuk mengirim hanya teks tanpa media]
        
daftar media type yang diizinkan:
1. Text
2. Audio
3. Image
4. Video
5. Sticker`);
        let pp = await conn.profilePictureUrl(m.sender, "image")

    if (!quoted) {
    conn.sendMessage(idsal, {
            text: text, 
            contextInfo: {
                forwardingScore: 9999,
                isForwarded: true,
                externalAdReply: {
                    title: `${text}`,
                    body: `Sender: ${m.pushName}`,
                    thumbnailUrl: pp,
                    sourceUrl: '',
                    mediaType: 1,
                },
            }});
    return m.reply(" ✔ done, cek disini 👇") 
    };
    let mime = quoted.mimetype || '';    
    let dl = await quoted.download()
    if (!/webp/.test(mime) && !/video/.test(mime) && !/image/.test(mime) && !/audio/.test(mime)) {
        return m.reply(`🚩 Balas Media dengan ${_p + command} <caption>
        
daftar media type yang diizinkan:
1. Text
2. Audio
3. Image
4. Video
5. Sticker`);
    }
    m.react("⏱️")
        let caption = text || "No Caption";
        let message = { 
            contextInfo: {
                forwardingScore: 9999,
                isForwarded: true,
                externalAdReply: {
                    title: `${caption}`,
                    body: `Sender: ${m.pushName}`,
                    thumbnailUrl: pp,
                    sourceUrl: '',
                    mediaType: 1,
                },
            },
        };
        if (/webp/.test(mime)) {
            message.sticker = dl;
        } else if (/audio/.test(mime)) {
            message.audio = dl;
            message.mimetype = 'audio/mpeg';
            message.ptt = true;
        } else if (/video/.test(mime)) {
            message.video = dl;
            message.caption = `${caption}`;
        } else if (/image/.test(mime)) {
            message.image = dl;
            message.caption = `${caption}`;
        } else {
            message.text = caption;
        }

        await conn.sendMessage(idsal, {
            ...message,
        });

        await conn.delay(2000);
        await m.react('✅');
        m.reply("Done, Cek dsini 👇");
};

handler.help = ['upch'];
handler.tags = ['main'];
handler.command = /^(upch|uch)$/i;

export default handler;