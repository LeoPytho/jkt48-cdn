import uploadImage from "../lib/uploadImage.js";
import uploadFile from "../lib/uploadFile.js";
import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { pipeline } from 'stream/promises';
import fetch from 'node-fetch';

const genAI = new GoogleGenerativeAI("AIzaSyBt0A8wKTIbOvN6Bl9PBkF_PLrG4621VUw");
const systemPrompt = "kamu adalah ai.";
const chatSessions = new Map();
const geminiModel = genAI.getGenerativeModel({ 
  model: "gemini-2.0-flash",
  systemInstruction: systemPrompt
});

async function saveTempFile(buffer, mimeType, fileType = 'audio') {
  const tempDir = path.join(__dirname, '../tmp');
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
  let extension = 'bin';
  if (fileType === 'audio') {
    switch(mimeType) {
      case 'audio/wav': extension = 'wav'; break;
      case 'audio/mp3': extension = 'mp3'; break;
      case 'audio/aiff': extension = 'aiff'; break;
      case 'audio/aac': extension = 'aac'; break;
      case 'audio/ogg': extension = 'ogg'; break;
      case 'audio/flac': extension = 'flac'; break;
      default: extension = 'mp3';
    }
  } else if (fileType === 'document') {
    switch(mimeType) {
      case 'application/pdf': extension = 'pdf'; break;
      case 'application/msword': extension = 'doc'; break;
      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': extension = 'docx'; break;
      case 'application/vnd.ms-excel': extension = 'xls'; break;
      case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': extension = 'xlsx'; break;
      case 'application/vnd.ms-powerpoint': extension = 'ppt'; break;
      case 'application/vnd.openxmlformats-officedocument.presentationml.presentation': extension = 'pptx'; break;
      case 'text/plain': extension = 'txt'; break;
      case 'text/csv': extension = 'csv'; break;
      case 'application/rtf': extension = 'rtf'; break;
      default: extension = 'pdf';
    }
  }
  const filename = `${fileType}_${Date.now()}_${Math.floor(Math.random() * 10000)}.${extension}`;
  const filepath = path.join(tempDir, filename);
  const readable = new Readable();
  readable._read = () => {};
  readable.push(buffer);
  readable.push(null);
  await pipeline(readable, fs.createWriteStream(filepath));
  return { filepath, filename };
}

function cleanupTempFile(filepath) {
  try {
    if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
  } catch (error) {
    console.error("Error cleaning up temp file:", error);
  }
}

async function processAudioOrDocument(filepath, mimeType, text) {
  const fileContent = fs.readFileSync(filepath);
  const fileBase64 = Buffer.from(fileContent).toString("base64");
  const filePart = { inlineData: { data: fileBase64, mimeType: mimeType } };
  const prompt = text || (mimeType.startsWith('audio/') ? "Tolong jelaskan tentang audio ini" : "Tolong analisis dokumen ini");
  const parts = [filePart, prompt];
  const result = await geminiModel.generateContent(parts);
  return result.response.text();
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (command.toLowerCase() === "resetgemini") {
    const userId = m.sender;
    if (chatSessions.has(userId)) {
      chatSessions.delete(userId);
      return m.reply("[✔] Chat history kamu sudah direset.");
    }
    return m.reply("[❗] Kamu belum memiliki chat history.");
  }
  let text;
  if (args.length >= 1) {
    text = args.join(" ");
  } else if (m.quoted && m.quoted.text) {
    text = m.quoted.text;
  } else {
    return m.reply("[❗] Input query!\nEx: .gemini selamat pagi");
  }
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  try {
    const userId = m.sender;
    let chatSession;
    if (!chatSessions.has(userId)) {
      chatSession = geminiModel.startChat({ history: [], generationConfig: { maxOutputTokens: 1000 } });
      chatSessions.set(userId, chatSession);
    } else {
      chatSession = chatSessions.get(userId);
    }
    if (!mime) {
      const result = await chatSession.sendMessage(text);
      const response = result.response.text();
      if (!response) throw new Error("[❗] Response tidak valid dari API");
      await conn.sendMessage(m.chat, {
        text: response,
        contextInfo: {
          externalAdReply: {
            title: '✨ G E M I N I - P R O',
            body: 'model supp: vision', 
            thumbnailUrl: 'https://telegra.ph/file/4bae3d5130aabcbe94588.jpg',
            sourceUrl: 'https://gemini.google.com',
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m });
    } else if (mime.startsWith('audio/')) {
      await m.reply("Processing audio, mohon tunggu sebentar...");
      let media = await q.download();
      const { filepath, filename } = await saveTempFile(media, mime, 'audio');
      try {
        const response = await processAudioOrDocument(filepath, mime, text);
        if (!response) throw new Error("[❗] Response tidak valid dari API");
        await conn.sendMessage(m.chat, {
          text: response,
          contextInfo: {
            externalAdReply: {
              title: '✨ G E M I N I - P R O',
              body: 'model supp: media mp3', 
              thumbnailUrl: 'https://telegra.ph/file/4bae3d5130aabcbe94588.jpg',
              sourceUrl: 'https://gemini.google.com',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: m });
      } finally {
        cleanupTempFile(filepath);
      }
    } else if (mime.startsWith('image/') || mime.startsWith('video/')) {
      let media = await q.download();
      let isImage = mime.startsWith('image/');
      let isVideo = mime.startsWith('video/');
      let isTele = isImage && /image\/(png|jpe?g)/.test(mime);
      let link;
      if (isImage) {
        link = await uploadImage(media);
      } else {
        const { filepath, filename } = await saveTempFile(media, mime, 'video');
        try {
          const fileContent = fs.readFileSync(filepath);
          const fileBase64 = Buffer.from(fileContent).toString("base64");
          const videoPart = { inlineData: { data: fileBase64, mimeType: mime } };
          const parts = [videoPart, text || "Tolong jelaskan tentang video ini"];
          const result = await geminiModel.generateContent(parts);
          const response = result.response.text();
          if (!response) throw new Error("[❗] Response tidak valid dari API");
          await conn.sendMessage(m.chat, {
            text: response,
            contextInfo: {
              externalAdReply: {
                title: '✨ G E M I N I - P R O',
                body: 'model supp: media mp4', 
                thumbnailUrl: 'https://telegra.ph/file/4bae3d5130aabcbe94588.jpg',
                sourceUrl: 'https://gemini.google.com',
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          }, { quoted: m });
          cleanupTempFile(filepath);
          return;
        } catch (error) {
          cleanupTempFile(filepath);
          throw error;
        }
      }
      if (isImage) {
        const imageResp = await fetch(link).then(response => response.arrayBuffer());
        const imageBase64 = Buffer.from(imageResp).toString("base64");
        const mimeType = mime || "image/jpeg";
        const imagePart = { inlineData: { data: imageBase64, mimeType: mimeType } };
        const parts = [imagePart, text];
        const result = await chatSession.sendMessage(parts);
        const response = result.response.text();
        if (!response) throw new Error("[❗] Response tidak valid dari API");
        await conn.sendMessage(m.chat, {
          text: response,
          contextInfo: {
            externalAdReply: {
              title: '✨ G E M I N I - P R O',
              body: 'model supp: vision', 
              thumbnailUrl: link,
              sourceUrl: 'https://gemini.google.com',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: m });
      }
    } else if (
      mime.startsWith('application/') || 
      mime.startsWith('text/') ||
      mime === 'application/pdf' ||
      mime === 'application/msword' ||
      mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      mime === 'application/vnd.ms-excel' ||
      mime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      mime === 'application/vnd.ms-powerpoint' ||
      mime === 'application/vnd.openxmlformats-officedocument.presentationml.presentation' ||
      mime === 'text/plain' ||
      mime === 'text/csv'
    ) {
      await m.reply("⏱️ Processing dokumen, mohon tunggu sebentar...");
      let media = await q.download();
      const { filepath, filename } = await saveTempFile(media, mime, 'document');
      try {
        const response = await processAudioOrDocument(filepath, mime, text);
        if (!response) throw new Error("[❗] Response tidak valid dari API");
        await conn.sendMessage(m.chat, {
          text: response,
          contextInfo: {
            externalAdReply: {
              title: '✨ G E M I N I - P R O',
              body: 'model supp: media doc', 
              thumbnailUrl: 'https://telegra.ph/file/4bae3d5130aabcbe94588.jpg',
              sourceUrl: 'https://gemini.google.com',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: m });
      } finally {
        cleanupTempFile(filepath);
      }
    } else {
      return m.reply("Format file tidak didukung. Gunakan text, gambar, audio, atau dokumen.");
    }
    setTimeout(() => {
      if (chatSessions.has(userId)) {
        chatSessions.delete(userId);
      }
    }, 30 * 60 * 1000);
  } catch (e) {
    console.error(e);
    m.reply(`[❗] Terjadi kesalahan saat memproses permintaan: ${e.message}`);
  }
};

handler.help = ["gemini <text>", "resetgemini"];
handler.tags = ["ai"];
handler.command = /^(gemini|resetgemini)$/i;
handler.limit = true;
handler.register = true;

export default handler;