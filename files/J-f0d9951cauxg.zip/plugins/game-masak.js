/*
SCRIPT BY © Yousoo
•• recode kasih credit
•• FITUR RPG RESTORAN
•• Foll ch aku dong kak hehe: https://whatsapp.com/channel/0029VakAg04545umLWxbWa0i
• KALAU MAU TEMPEL LINK CH SILAHKAN, TAPI LINK CHKU JANGAN DIHAPUS YA. MAKASIH
*/
let yoso = async (m, { conn, command, args }) => {
  const { sender } = m
  const user = db.data.users[sender]

  if (command === 'restoran' && args.length > 0) {
    if (user.restoran) return conn.reply(m.chat, 'Kamu sudah memiliki restoran!', m)
    
    const namaResto = args.join(' ')
    user.restoran = {
      nama: namaResto,
      uang: 7000,
      reputasi: 0,
      level: 1,
      stokBahan: {
        nasi: 3, ayam: 2, mie: 2, bumbu: 4, sate: 1, air: 5,
        telur: 3, sosis: 2, tepung: 2, keju: 1, roti: 2, daging: 1, kentang: 3, sayur: 3,
        ikan: 0, rumputLaut: 0, udang: 0
      },
      stokMasakan: {},
      masakHarian: 0,
      maxMasak: 5,
      tempat: 5,
      iklan: 1,
      hari: 1,
      event: null,
      pelangganVIP: 0
    }
    acakEvent(user.restoran)
    return conn.reply(m.chat, `🍽️ Restoran "${namaResto}" berhasil didirikan! Semoga sukses!\nKetik *.restoraninfo* untuk melihat status`, m)
  }

  if (!user.restoran) {
    return conn.reply(m.chat, 'Kamu belum memiliki restoran! Buat dengan command: .restoran [nama_resto]', m)
  }

  const restoran = user.restoran
  const resep = {
    'nasi goreng': { level: 1, bahan: {nasi: 1, bumbu: 1} },
    'ayam bakar': { level: 1, bahan: {ayam: 1, bumbu: 1} },
    'mie goreng': { level: 1, bahan: {mie: 1, bumbu: 1} },
    'sate ayam': { level: 1, bahan: {sate: 1, bumbu: 1} },
    'sop ayam': { level: 2, bahan: {ayam: 1, air: 1, bumbu: 1} },
    'telur dadar': { level: 2, bahan: {telur: 2, bumbu: 1} },
    'sosis goreng': { level: 2, bahan: {sosis: 2, bumbu: 1} },
    'ayam crispy': { level: 3, bahan: {ayam: 1, tepung: 1, bumbu: 1} },
    'roti keju': { level: 3, bahan: {roti: 1, keju: 1} },
    'burger': { level: 4, bahan: {roti: 1, daging: 1, sayur: 1} },
    'kentang goreng': { level: 4, bahan: {kentang: 2, bumbu: 1} },
    'omelette': { level: 5, bahan: {telur: 2, keju: 1} },
    'sup sayur': { level: 5, bahan: {sayur: 2, air: 1, bumbu: 1} },
    'spaghetti': { level: 6, bahan: {mie: 1, daging: 1, bumbu: 1} },
    'steak daging': { level: 7, bahan: {daging: 1, bumbu: 1} },
    'sushi': { level: 8, bahan: {nasi: 1, ikan: 1, rumputLaut: 1} },
    'udang tempura': { level: 9, bahan: {udang: 2, tepung: 2, bumbu: 1} },
    'seafood platter': { level: 10, bahan: {ikan: 1, udang: 2, rumputLaut: 1} }
  }

  const hargaJual = {
    'nasi goreng': 1500, 'ayam bakar': 2000, 'mie goreng': 1400, 'sate ayam': 1800,
    'sop ayam': 1600, 'telur dadar': 1300, 'sosis goreng': 1200, 'ayam crispy': 2200,
    'roti keju': 1400, 'burger': 2500, 'kentang goreng': 1300, 'omelette': 1500,
    'sup sayur': 1400, 'spaghetti': 2600, 'steak daging': 3000,
    'sushi': 5000, 'udang tempura': 4500, 'seafood platter': 8000
  }

  const eventList = {
    'normal': 'Hari biasa, semua berjalan stabil.',
    'ramai': 'Pelanggan membludak! +reputasi tiap pesanan.',
    'sepi': 'Pelanggan jarang datang. Hanya 50% kemungkinan dilayani.',
    'hujan': 'Makanan hangat lebih laku seperti sop dan omelette.',
    'libur': 'Semua makanan laku keras!',
    'pasar murah': 'Harga beli bahan 50% lebih murah!',
    'badai': 'Stok masakan berkurang 1 acak karena kerusakan!',
    'pesta kuliner': 'Semua makanan dijual 50% lebih mahal!',
    'musim dingin': 'Makanan dingin kurang laku (burger, sosis)',
    'musim panas': 'Minuman dan makanan segar lebih laku!',
    'kunjungan kritikus': 'Peluang besar kedatangan VIP!'
  }

  const menu = Object.keys(resep)

  if (command === 'topresto') {
    const allUsers = Object.values(db.data.users)
      .filter(u => u.restoran)
      .sort((a, b) => (b.restoran.reputasi + b.restoran.level * 100 + b.restoran.pelangganVIP * 500) - 
                      (a.restoran.reputasi + a.restoran.level * 100 + a.restoran.pelangganVIP * 500))
      .slice(0, 10)
    
    let teks = '🏆 TOP 10 RESTORAN 🏆\n\n'
    allUsers.forEach((u, i) => {
      const r = u.restoran
      teks += `${i+1}. ${r.nama} - Level ${r.level}\n   💵 Rp${r.uang.toLocaleString()} | 🌟 ${r.reputasi} | 👑 VIP: ${r.pelangganVIP}\n`
    })
    
    return conn.reply(m.chat, teks, m)
  }
  
  let teks = `🍽️ RESTORAN ${restoran.nama.toUpperCase()} 🍽️\n\n`
  teks += `📆 Hari ke-${restoran.hari}\n🎯 Event: ${restoran.event.toUpperCase()} - ${eventList[restoran.event]}\n\n`
  teks += `👨‍🍳 Level: ${restoran.level}\n💰 Uang: Rp${restoran.uang.toLocaleString()}\n🌟 Reputasi: ${restoran.reputasi}\n`
  teks += `🔥 Masak: ${restoran.masakHarian}/${restoran.maxMasak}\n💺 Tempat: ${restoran.tempat} orang\n📢 Iklan: Level ${restoran.iklan}\n👑 Pelanggan VIP: ${restoran.pelangganVIP}\n\n`

  teks += "🍛 Stok Masakan:\n"
  for (let mkn of menu) {
    if (restoran.stokMasakan[mkn] > 0) {
      teks += `- ${mkn}: ${restoran.stokMasakan[mkn] || 0}\n`
    }
  }

  teks += "\n🧂 Stok Bahan:\n"
  for (let [bahan, jml] of Object.entries(restoran.stokBahan)) {
    if (jml > 0) teks += `- ${bahan}: ${jml}\n`
  }

  teks += "\n📌 Perintah Game:\n"
  teks += "- .masak [menu]\n- .layani\n- .belibahan [nama] [jumlah]\n"
  teks += "- .haribaru\n- .upgrade [dapur|tempat|iklan]\n- .topresto\n"

  conn.reply(m.chat, teks, m)
}

yoso.before = async (m, { conn, command, args }) => {
  const user = db.data.users[m.sender]
  if (!user?.restoran) return
  
  const restoran = user.restoran
  const resep = {
    'nasi goreng': { level: 1, bahan: {nasi: 1, bumbu: 1} },
    'ayam bakar': { level: 1, bahan: {ayam: 1, bumbu: 1} },
    'mie goreng': { level: 1, bahan: {mie: 1, bumbu: 1} },
    'sate ayam': { level: 1, bahan: {sate: 1, bumbu: 1} },
    'sop ayam': { level: 2, bahan: {ayam: 1, air: 1, bumbu: 1} },
    'telur dadar': { level: 2, bahan: {telur: 2, bumbu: 1} },
    'sosis goreng': { level: 2, bahan: {sosis: 2, bumbu: 1} },
    'ayam crispy': { level: 3, bahan: {ayam: 1, tepung: 1, bumbu: 1} },
    'roti keju': { level: 3, bahan: {roti: 1, keju: 1} },
    'burger': { level: 4, bahan: {roti: 1, daging: 1, sayur: 1} },
    'kentang goreng': { level: 4, bahan: {kentang: 2, bumbu: 1} },
    'omelette': { level: 5, bahan: {telur: 2, keju: 1} },
    'sup sayur': { level: 5, bahan: {sayur: 2, air: 1, bumbu: 1} },
    'spaghetti': { level: 6, bahan: {mie: 1, daging: 1, bumbu: 1} },
    'steak daging': { level: 7, bahan: {daging: 1, bumbu: 1} },
    'sushi': { level: 8, bahan: {nasi: 1, ikan: 1, rumputLaut: 1} },
    'udang tempura': { level: 9, bahan: {udang: 2, tepung: 2, bumbu: 1} },
    'seafood platter': { level: 10, bahan: {ikan: 1, udang: 2, rumputLaut: 1} }
  }

  const hargaJual = {
    'nasi goreng': 1500, 'ayam bakar': 2000, 'mie goreng': 1400, 'sate ayam': 1800,
    'sop ayam': 1600, 'telur dadar': 1300, 'sosis goreng': 1200, 'ayam crispy': 2200,
    'roti keju': 1400, 'burger': 2500, 'kentang goreng': 1300, 'omelette': 1500,
    'sup sayur': 1400, 'spaghetti': 2600, 'steak daging': 3000,
    'sushi': 5000, 'udang tempura': 4500, 'seafood platter': 8000
  }

  const menu = Object.keys(resep)

  switch (command) {
    case 'masak':
      let mkn = args.join(' ').toLowerCase()
      if (!resep[mkn]) return conn.reply(m.chat, `🍳 Menu tidak dikenal. Pilih: ${menu.join(', ')}`, m)
      if (restoran.masakHarian >= restoran.maxMasak) return conn.reply(m.chat, '🔥 Kapasitas masak penuh. Ketik .haribaru untuk lanjut.', m)
      if (resep[mkn].level > restoran.level) return conn.reply(m.chat, `❌ Level restoran kurang! Butuh level ${resep[mkn].level}`, m)
      
      let bahan = resep[mkn].bahan
      for (let b in bahan) {
        if ((restoran.stokBahan[b] || 0) < bahan[b]) return conn.reply(m.chat, `❌ Bahan ${b} kurang.`, m)
      }
      
      for (let b in bahan) restoran.stokBahan[b] -= bahan[b]
      restoran.stokMasakan[mkn] = (restoran.stokMasakan[mkn] || 0) + 1
      restoran.masakHarian++
      return conn.reply(m.chat, `✅ Berhasil masak ${mkn}!`, m)

    case 'layani':
      if (Object.keys(restoran.stokMasakan).filter(k => restoran.stokMasakan[k] > 0).length === 0) {
        return conn.reply(m.chat, '❌ Belum ada makanan untuk dilayani.', m)
      }
      
      let baseOrders = 1
      for (let i = 0; i < restoran.tempat - 1; i++) {
        if (Math.random() < (0.1 + restoran.iklan * 0.05)) {
          baseOrders++
        }
      }
      baseOrders = Math.min(5, baseOrders)

      if (restoran.event === 'sepi') {
        let actualOrders = 0
        for (let i = 0; i < baseOrders; i++) {
          if (Math.random() < 0.5) actualOrders++
        }
        baseOrders = actualOrders
      }
      
      if (baseOrders === 0) {
        return conn.reply(m.chat, '😴 Hari sepi, tidak ada pelanggan yang datang.', m)
      }

      let weights = {}
      for (let dish of menu) weights[dish] = 1

      if (restoran.event === 'hujan') {
        ['sop ayam', 'omelette', 'sup sayur'].forEach(d => weights[d] = 5)
      } else if (restoran.event === 'musim panas') {
        ['sop ayam', 'sup sayur', 'sate ayam'].forEach(d => weights[d] = 3)
      } else if (restoran.event === 'musim dingin') {
        ['burger', 'sosis goreng'].forEach(d => weights[d] = 0.2)
      } else if (restoran.event === 'kunjungan kritikus') {
        ['steak daging', 'sushi', 'seafood platter'].forEach(d => weights[d] = 3)
      }

      let dishPool = []
      for (let dish of menu) {
        for (let i = 0; i < (weights[dish] || 1); i++) {
          dishPool.push(dish)
        }
      }

      let successOrders = []
      let failedOrders = []
      let totalIncome = 0
      let totalRep = 0
      let vipCount = 0

      for (let i = 0; i < baseOrders; i++) {
        let dish = dishPool[Math.floor(Math.random() * dishPool.length)]
        
        if ((restoran.stokMasakan[dish] || 0) > 0) {
          restoran.stokMasakan[dish]--
          
          let price = hargaJual[dish]
          if (restoran.event === 'pesta kuliner') price *= 1.5
          if (restoran.event === 'musim dingin' && ['burger', 'sosis goreng'].includes(dish)) price *= 0.7
          
          let isVIP = false
          let vipChance = 0.05 + restoran.iklan * 0.02
          if (restoran.event === 'kunjungan kritikus') vipChance *= 2
          
          if (price >= 2000 && Math.random() < vipChance) {
            isVIP = true
            price *= 3
            vipCount++
          }
          
          totalIncome += Math.floor(price)
          successOrders.push(dish + (isVIP ? " (VIP)" : ""))
          
          let repGain = 1
          if (isVIP) repGain += 5
          if (restoran.event === 'ramai' || restoran.event === 'libur') repGain += 1
          totalRep += repGain
        } else {
          failedOrders.push(dish)
          totalRep -= 1
        }
      }
      
      restoran.uang += totalIncome
      restoran.reputasi += totalRep
      if (restoran.reputasi < 0) restoran.reputasi = 0
      restoran.pelangganVIP += vipCount
      
      if (restoran.reputasi >= restoran.level * 10) {
        restoran.level++
        restoran.maxMasak += 3
        restoran.reputasi = 0
        conn.reply(m.chat, `🎉 Level up! Restoran naik ke Level ${restoran.level}`, m)
      }
      
      let resultMsg = `📊 Layanan untuk ${baseOrders} pelanggan:\n`
      if (successOrders.length > 0) {
        resultMsg += `✅ Sukses: ${successOrders.join(', ')}\n`
      }
      if (failedOrders.length > 0) {
        resultMsg += `❌ Gagal: ${failedOrders.join(', ')} (stok habis)\n`
      }
      resultMsg += `\n💵 Pendapatan: Rp${totalIncome.toLocaleString()}\n`
      resultMsg += `🌟 Reputasi: ${totalRep > 0 ? '+' : ''}${totalRep}\n`
      if (vipCount > 0) {
        resultMsg += `👑 ${vipCount} pelanggan VIP!\n`
      }
      
      return conn.reply(m.chat, resultMsg, m)

    case 'belibahan':
      let [nama, jumlahStr] = args
      let jumlah = parseInt(jumlahStr)
      if (!nama || isNaN(jumlah) || jumlah <= 0) return conn.reply(m.chat, 'Format: .belibahan [nama] [jumlah]', m)
      
      let biaya = 200 * jumlah
      if (restoran.event === 'pasar murah') biaya = Math.floor(biaya / 2)
      if (restoran.uang < biaya) return conn.reply(m.chat, `Uang kurang. Butuh Rp${biaya.toLocaleString()}`, m)
      
      restoran.uang -= biaya
      if (!restoran.stokBahan[nama]) restoran.stokBahan[nama] = 0
      restoran.stokBahan[nama] += jumlah
      return conn.reply(m.chat, `🛒 Beli ${jumlah} *${nama}* sukses!`, m)

    case 'haribaru':
      restoran.hari++
      restoran.masakHarian = 0
      acakEvent(restoran)
      return conn.reply(m.chat, `📆 Hari ke-${restoran.hari} dimulai.\n🎯 Event: *${restoran.event.toUpperCase()}*`, m)

    case 'upgrade':
      const fasilitas = args[0]?.toLowerCase()
      if (!['dapur', 'tempat', 'iklan'].includes(fasilitas)) {
        return conn.reply(m.chat, 'Pilih fasilitas: dapur, tempat, atau iklan', m)
      }
      
      const upgradeCost = restoran.level * (fasilitas === 'dapur' ? 3500 : fasilitas === 'tempat' ? 2500 : 2000)
      
      if (restoran.uang < upgradeCost) {
        return conn.reply(m.chat, `💸 Uang kurang! Butuh Rp${upgradeCost.toLocaleString()}`, m)
      }
      
      restoran.uang -= upgradeCost
      
      if (fasilitas === 'dapur') {
        restoran.maxMasak += 3
        conn.reply(m.chat, `🏗️ Kapasitas dapur ditingkatkan! Sekarang ${restoran.maxMasak} masakan/hari`, m)
      } 
      else if (fasilitas === 'tempat') {
        restoran.tempat += 5
        conn.reply(m.chat, `💺 Kapasitas tempat duduk ditingkatkan! Sekarang ${restoran.tempat} kursi`, m)
      } 
      else if (fasilitas === 'iklan') {
        restoran.iklan += 1
        conn.reply(m.chat, `📢 Level iklan ditingkatkan! Sekarang level ${restoran.iklan}`, m)
      }
      break
  }
}

function acakEvent(restoran) {
  const eventAcak = [
    'normal', 'ramai', 'sepi', 'hujan', 'libur',
    'pasar murah', 'badai', 'pesta kuliner', 'musim dingin', 'musim panas',
    'kunjungan kritikus'
  ]
  restoran.event = eventAcak[Math.floor(Math.random() * eventAcak.length)]

  if (restoran.event === 'badai') {
    let semuaMasakan = Object.keys(restoran.stokMasakan).filter(k => restoran.stokMasakan[k] > 0)
    if (semuaMasakan.length > 0) {
      let acak = semuaMasakan[Math.floor(Math.random() * semuaMasakan.length)]
      restoran.stokMasakan[acak] -= 1
    }
  }
}

yoso.command = /^(restoran|masak|layani|belibahan|haribaru|upgrade|topresto|restoraninfo)$/i
yoso.register = true
export default yoso
/*
SCRIPT BY © Yousoo
•• recode kasih credit
•• FITUR RPG RESTORAN
•• Foll ch aku dong kak hehe: https://whatsapp.com/channel/0029VakAg04545umLWxbWa0i
• KALAU MAU TEMPEL LINK CH SILAHKAN, TAPI LINK CHKU JANGAN DIHAPUS YA. MAKASIH
*/