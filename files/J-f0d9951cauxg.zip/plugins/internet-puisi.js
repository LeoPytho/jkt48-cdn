/*   
Base : KaryaKarsa Puisi Scraper  
Telegram : t.me/kayzuMD  
WhatsApp Channel : https://whatsapp.com/channel/0029Vb2OwWCElagtreIoke17  
Sumber Case : https://whatsapp.com/channel/0029Vb9vAP3AjPXKqBBuwv2s  
Type : Plug-in CJS  
Created by : Kayzu MD 🐦‍⬛  
Thanks to : Kayzy Hosting & Karyakarsa  
*/


import cheerio from "cheerio";

const BASE = "https://karyakarsa.com/sigota/kumpulan-puisi-random-2";

async function puisi() {
    try {
        let { data } = await axios.get(BASE);
        let $ = cheerio.load(data);

        let puisiList = [];
        
        $(".content-lock p").each((i, el) => {
            let text = $(el).text().trim();
            if (text) puisiList.push(text);
        });

        let puisiFormatted = [];
        let currentPuisi = [];

        for (let line of puisiList) {
            if (line === "-----------") {
                if (currentPuisi.length) {
                    puisiFormatted.push(currentPuisi);
                    currentPuisi = [];
                }
            } else {
                currentPuisi.push(line);
            }
        }

        if (currentPuisi.length) puisiFormatted.push(currentPuisi);

        if (puisiFormatted.length === 0) return null;

        let randomIndex = Math.floor(Math.random() * puisiFormatted.length);
        return puisiFormatted[randomIndex].join("\n");
    } catch (error) {
        return `Error: ${error.message}`;
    }
}

let handler = async (m, { conn }) => {
    let puisiText = await puisi();
    if (!puisiText) return m.reply('[❗] Tidak ada puisi yang bisa diambil.');

    let caption = `*[📃 Puisi Random Karyakarsa.com ]*\n\n${puisiText}`;

    await conn.sendMessage(m.chat, { text: caption }, { quoted: m });
};

handler.command = /^(puisi|puisiacak)$/i;
handler.help = ['puisi'];
handler.tags = ['internet','quotes'];

export default handler;