let handler = async (m, { conn, text }) => {
  if (!text) throw '[❗] Input Twitter URL'
  await m.reply(wait)
  let urls = text.split(/\s+/)
  for (let url of urls) {
    const { type, title, duration, thumbnail, download } = await twt(url)
    if (type === 'video') {
      let quality = download[0].quality.split('(')[0]
      conn.sendFile(
        m.chat,
        download[0].link,
        title + '.mp4',
        '[ X - DOWNLOADER ]\n' +
          '*Title :* ' +
          title +
          '\n*Duration :* ' +
          duration +
          '\n*Quality :* ' +
          quality +
          '\n*Thumbnail :* ' +
          thumbnail,
        m
      )
    } else if (type === 'photo') {
      if (Array.isArray(download)) {
        for (let imgUrl of download) {
          await conn.sendMessage(
            m.chat,
            { image: { url: imgUrl }, caption: '' },
            { quoted: m }
          )
        }
      } else {
        await conn.sendMessage(
          m.chat,
          { image: { url: download }, caption: '' },
          { quoted: m }
        )
      }
    }
  }
}
handler.help = ['twitter']
handler.tags = ['downloader']
handler.command = /^((twt|twitter)(dl)?)$/i
handler.limit = handler.register = true
export default handler

async function twt(url) {
  let { data } = await axios.get(`${APIs.ft}/download/twitter?url=${url}`)
  let { type, title, duration, thumbnail, download } = data.result
  return { type, title, duration, thumbnail, download }
}