var handler = async (m, { text }) => {
  let user = global.db.data.users[m.sender]
  user.afk = + new Date
  user.afkReason = text
  m.reply(`
${conn.getName(m.sender)} AFK dengan alasan: ${text ? ': ' + text : ''}
`)
}
handler.help = ['afk [alasan]']
handler.tags = ['group', 'main']
handler.command = /^afk$/i

export default handler
