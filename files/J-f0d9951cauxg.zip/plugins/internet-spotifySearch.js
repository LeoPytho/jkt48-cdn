import fetch from 'node-fetch';
import { delay } from '@adiwajshing/baileys';

let handler = async function (m, { conn, text, usedPrefix: _p, command }) {
  if (!text) return m.reply(`[❗] Masukkan judul lagu untuk dicari di Spotify!\n\nContoh: ${_p}${command} Starboy`);

  try {
    if (text.startsWith('https://open.spotify.com/track/')) {
      return m.reply(`[📥] Gunakan command ${_p}spotifydl ${text} untuk download langsung`);
    }

    const loadingMessages = [
      "🔍 Mencari lagu di Spotify...",
      "🎵 Mengumpulkan data lagu...",
      "✅ Data berhasil ditemukan..."
    ];

    let { key } = await conn.sendMessage(m.chat, { text: 'Loading...' }, { quoted: m });
    for (let i = 0; i < loadingMessages.length; i++) {
      await delay(1000);
      await conn.sendMessage(m.chat, { text: loadingMessages[i], edit: key }, { quoted: m });
    }

    let {data} = await axios.get(APIs.jl +`/search/spotifysearch?query=${encodeURIComponent(text)}`);
    let jul = data.result

    if (!jul || !jul.data || jul.data.length === 0) {
      return conn.sendMessage(m.chat, {
        text: 'lagu nya ga ada bree,coba cari yang lain',
        edit: key
      }, { quoted: m });
    }

    const maxSongs = Math.min(jul.data.length, 10);
    const firstSong = jul.data[0];
    const duration = firstSong.duration || '0:00';
    const thumbnailUrl = 'https://files.catbox.moe/ywahb9.jpg';

    let caption = `*[ SPOTIFY TRACK FOUND ]*\n\n` +
                  `◦ *Judul:* ${firstSong.title}\n` +
                  `◦ *Popularitas:* ${firstSong.popularity || 'Unknown'}\n` +
                  `◦ *Durasi:* ${duration}\n` +
                  `◦ *URL:* ${firstSong.url}\n\n` +
                  `Silakan pilih opsi di bawah untuk mendownload atau melihat hasil lainnya.`;

    let sections = [];
    for (let i = 0; i < maxSongs; i++) {
      const jul2 = jul.data[i];
      sections.push({
        title: `${i + 1}. ${jul2.title}`,
        rows: [{
          header: 'TYPE AUDIO 🔊',
          title: `${jul2.title}`,
          description: `Durasi: ${jul2.duration} - Popularitas: ${jul2.popularity || 'Unknown'}`,
          id: `.spotifydl ${jul2.url}`
        }]
      });
    }

    let listMessage = {
      title: `[ ${maxSongs} HASIL SPOTIFY ]`,
      sections
    };

    let btn = [
      {
        buttonId: `gada`,
        buttonText: {
          displayText: "🔍 Hasil Lain"
        },
        nativeFlowInfo: {
          "name": "single_select",
          "paramsJson": JSON.stringify(listMessage)
        }
      },
      {
        buttonId: `${_p}spotifydl ${firstSong.url}`,
        buttonText: {
          displayText: "🎵 Audio"
        }
      },
      {
        buttonId: `.donasi`,
        buttonText: {
          displayText: "💲Donate Me"
        }
      }
    ];

    if (typeof conn.bubbleThumbImg === 'function') {
      await conn.bubbleThumbImg(
        m.chat,
        thumbnailUrl,
        caption,
        "Pilih opsi di bawah ini:",
        btn,
        firstSong.title,
        "Spotify Track",
        thumbnailUrl,
        m
      );
    } else {
      await conn.sendMessage(m.chat, {
        image: { url: thumbnailUrl },
        caption: caption,
        footer: "Pilih opsi di bawah ini:",
        buttons: btn
      }, { quoted: m });
    }

  } catch (e) {
    console.error('Error detail:', e);
    m.reply(`❌ eror nih bree:\n${e.message}`);
  }
};

handler.help = ['spotifys'].map(v => v + ' <judul lagu>');
handler.tags = ['downloader'];
handler.command = /^(spotifys|spotifysearch)$/i;

export default handler;