import axios from 'axios'
import fs from 'fs'
import path from 'path'
import os from 'os'
import FormData from 'form-data'

async function pollinations(prompt) {
  try {
    const encodedPrompt = encodeURIComponent(prompt)
    const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?nologo=true`
    const response = await axios.get(imageUrl, { responseType: 'stream' })

    const tempPath = path.join(os.tmpdir(), 'temp_image.jpg')
    const writer = fs.createWriteStream(tempPath)
    response.data.pipe(writer)

    await new Promise((resolve, reject) => {
      writer.on('finish', resolve)
      writer.on('error', reject)
    })

    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', fs.createReadStream(tempPath))

    const upload = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    })

    fs.unlinkSync(tempPath)
    return upload.data
  } catch (err) {
    throw new Error(err.message)
  }
}

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('[❗] Input Prompt\n\nContoh: .text2img kucing di atas pohon');

  let { key } = await conn.sendMessage(m.chat, { text: '[⏱️] Membuat gambar, mohon tunggu...' }, { quoted: m });

  try {
    const imageUrl = await pollinations(text)

    await conn.delay(3000)
    let a = await conn.sendMessage(m.chat, { text: `✔ Gambar berhasil dibuat...`, edit: key })

    let hoh = await conn.sendMessage(m.chat, {
      text: `🔁 Mengirim gambar hasil, mohon bersabar...`,
      edit: a.key
    })

    await conn.delay(3000)
    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: "*[🔍] Prompt:* " + text
    }, { quoted: m })

    await conn.delay(3000)
    await conn.sendMessage(m.chat, { delete: hoh })
    m.react("✅")
  } catch (err) {
    m.reply('[❗] Gagal membuat gambar:\n\n' + err.message)
  }
}

handler.help = ['text2img <prompt>']
handler.command = ['texttoimg', 'text2img', 'aiimg', 'txt2img']
handler.tags = ['ai']

export default handler