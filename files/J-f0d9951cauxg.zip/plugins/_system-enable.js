/**
 * 𝙆𝙮𝙯𝙍𝙮𝙯𝙯 𝙓𝘿
 * 𝘵𝘦𝘭𝘦: https://t.me/kyzryzz
 * 𝘪𝘯𝘧𝘰: https://s.id/kyzzxd
 * 𝘺𝘵: https://youtube.com/@Always-Kyzx
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
**/

let handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
  let isEnable = /true|enable|(turn)?on|1/i.test(command)
  let chat = global.db.data.chats[m.chat]
  let user = global.db.data.users[m.sender] || {}
  let bot = global.db.data.settings[conn.user.jid] || {}
  let type = (args[0] || '').toLowerCase()
  let isAll = false, isUser = false
  switch (type) {
    case 'welcome':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      if (chat.welcome === isEnable) return m.reply(`weʟᴄᴏᴍᴇ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.welcome = isEnable
      break
    case 'bye':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      if (chat.bye === isEnable) return m.reply(`ʙʏᴇ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.bye = isEnable
      break
    case 'detect':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      if (chat.detect === isEnable) return m.reply(`deᴛᴇᴄᴛ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.detect = isEnable
      break
    case 'antidelete':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.delete === isEnable) return m.reply(`anᴛɪᴅᴇʟᴇᴛᴇ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.delete = isEnable
      break
    case 'autodelvn':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.autodelvn === isEnable) return m.reply(`auᴛᴏᴅᴇʟᴠɴ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.autodelvn = isEnable
      break
    case 'public':
      isAll = true
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (global.opts['self'] === !isEnable) return m.reply(`puʙʟɪᴄ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['self'] = !isEnable
      break
    case 'bcjoin':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.bcjoin === isEnable) return m.reply(`ʙcᴊᴏɪɴ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.bcjoin = isEnable
      break
    case 'antilink':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiLink === isEnable) return m.reply(`anᴛɪʟɪɴᴋ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiLink = isEnable
      break
    case 'antilink2':
    case 'antilinkv2':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiLink2 === isEnable) return m.reply(`anᴛɪʟɪɴᴋᴠ2 sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiLink2 = isEnable
      break
    case 'antichannel':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiChannel === isEnable) return m.reply(`anᴛɪᴄʜᴀɴɴᴇʟ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiChannel = isEnable
      break
    case 'antifoto':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiFoto === isEnable) return m.reply(`ᴀɴᴛɪғᴏᴛᴏ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiFoto = isEnable
      break
    case 'antipromosi':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiPromosi === isEnable) return m.reply(`anᴛɪᴘʀᴏᴍᴏsɪ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiPromosi = isEnable
      break
    case 'antiaudio':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiAudio === isEnable) return m.reply(`aɴᴛɪᴀᴜᴅɪᴏ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiAudio = isEnable
      break
    case 'antivideo':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiVideo === isEnable) return m.reply(`anᴛɪᴠɪᴅᴇᴏ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiVideo = isEnable
      break
    case 'antibot':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiBot === isEnable) return m.reply(`anᴛɪʙᴏᴛ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiBot = isEnable
      break
    case 'acc':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.acc === isEnable) return m.reply(`aᴜᴛᴏᴀcc sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.acc = isEnable
      break
    case 'anticall':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (bot.antiCall === isEnable) return m.reply(`anᴛɪᴄᴀll sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.antiCall = isEnable
      break
    case 'autoai':
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (chat.autoAi === isEnable) return m.reply(`auᴛᴏᴀɪ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.autoAi = isEnable
      break
    case 'autosticker':
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (chat.autoSticker === isEnable) return m.reply(`auᴛᴏsᴛɪᴄᴋᴇʀ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.autoSticker = isEnable
      break
    case 'antisticker':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiSticker === isEnable) return m.reply(`anᴛɪsᴛɪᴄᴋᴇʀ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiSticker = isEnable
      break
    case 'onlyprem':
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.onlyprem === isEnable) return m.reply(`onlʏᴘʀᴇᴍ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.onlyprem = isEnable
      break
    case 'autojoin':
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (chat.autoJoin === isEnable) return m.reply(`auᴛᴏᴊᴏɪɴ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.autoJoin = isEnable
      break
    case 'antitoxic':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiToxic === isEnable) return m.reply(`anᴛɪᴛᴏxɪᴄ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiToxic = isEnable
      break
    case 'antibadword':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiBadword === isEnable) return m.reply(`anᴛɪᴛᴏxɪᴄ2 sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiBadword = isEnable
      break
    case 'antispam':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      if (chat.antiSpam === isEnable) return m.reply(`anᴛɪsᴘᴀᴍ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiSpam = isEnable
      break
    case 'autolevelup':
      isUser = true
      if (user.autolevelup === isEnable) return m.reply(`auᴛᴏʟᴇᴠᴇʟᴜᴘ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      user.autolevelup = isEnable
      break
    case 'restrict':
      isAll = true
      if (!isOwner) {
        global.dfail('owner', m, conn)
        throw false
      }
      if (global.opts['restrict'] === isEnable) return m.reply(`ʀᴇsᴛʀɪᴄᴛ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['restrict'] = isEnable
      break
    case 'nyimak':
      isAll = true
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (global.opts['nyimak'] === isEnable) return m.reply(`nyɪᴍᴀᴋ sᴜᴅᴀʜ ${isEnable ? 'ᴅɪᴀᴋᴛɪғᴋᴀɴ' : 'ᴅɪɴᴏɴ-ᴀᴋᴛɪғᴋᴀɴ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['nyimak'] = isEnable
      break
    case 'autoread':
      isAll = true
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (global.opts['autoread'] === isEnable) return m.reply(`auᴛᴏʀᴇᴀᴅ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['autoread'] = isEnable
      break
    case 'pconly':
    case 'privateonly':
      isAll = true
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (global.opts['pconly'] === isEnable) return m.reply(`pcᴏɴʟʏ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['pconly'] = isEnable
      break
    case 'gconly':
    case 'grouponly':
      isAll = true
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (global.opts['gconly'] === isEnable) return m.reply(`ɢcoɴlʏ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['gconly'] = isEnable
      break
    case 'viewstory':
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.viewStory === isEnable) return m.reply(`vɪᴇᴡsᴛᴏry sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.viewStory = isEnable
      break
    case 'autobio':
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.autoBio === isEnable) return m.reply(`auᴛᴏʙɪᴏ sᴜᴅᴀʜ ${isEnable ? 'ᴀᴋᴛɪғ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.autoBio = isEnable
      break
    case "autobackupsc":
    case "autobsc":
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.backupSC === isEnable) return m.reply(`auᴛᴏʙᴀᴄᴋᴜᴘsᴄ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.backupSC = isEnable
      break
    case "autodesc":
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.gcDesc === isEnable) return m.reply(`auᴛᴏᴅᴇsᴄ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.gcDesc = isEnable
      break
    case "groupupdate":
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.notifyGroupUpdate === isEnable) return m.reply(`grouᴘᴜᴘᴅᴀᴛᴇ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.notifyGroupUpdate = isEnable
      break
    case "animeupdate":
      if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      if (chat.animeUpdate === isEnable) return m.reply(`aniᴍᴇᴜᴘᴅᴀᴛᴇ sᴜᴅᴀʜ ${isEnable ? 'ᴀᴋᴛɪғ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.animeUpdate = isEnable
      break
    case "joinfirst":
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (bot.joinFirst === isEnable) return m.reply(`ᴊᴏɪɴғɪʀsᴛ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      bot.joinFirst = isEnable
      break
    case 'swonly':
    case 'statusonly':
      isAll = true
      if (!isROwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      if (global.opts['swonly'] === isEnable) return m.reply(`swonly sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      global.opts['swonly'] = isEnable
      break
    case 'antibrat':
      if (!isROwner) { global.dfail('rowner', m, conn) }
      if (db.data.antibrat === isEnable) return m.reply(`anᴛɪʙʀᴀᴛ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      db.data.antibrat = isEnable
      break
    case 'aipc':
      if (user.aipc === isEnable) return m.reply(`aᴜᴛᴏᴀɪ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      user.aipc = isEnable
      break
    case 'antiht':
    case 'antihidetag':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      if (chat.antiHt === isEnable) return m.reply(`ᴀɴᴛɪʜɪᴅᴇᴛᴀɢ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiHt = isEnable
      break
      case 'antinsfw':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      if (chat.antiNsfw === isEnable) return m.reply(`ᴀɴᴛɪɴsғᴡ sᴜᴅᴀʜ ${isEnable ? 'ᴏɴ' : 'ᴏғғ'} sᴇʙᴇʟᴜᴍɴʏᴀ`)
      chat.antiNsfw = isEnable
      break
      default:
      const stt = await style(`Lɪsᴛ Oᴘᴛɪᴏɴ :

${cmenut} *${kyzryzz}For Group/Admin Group${kyzryzz}* ${cmenuh}
┊${chat.welcome ? '✅' : '❌'} welcome
┊${chat.bye ? '✅' : '❌'} bye
┊${chat.autodelvn ? '✅' : '❌'} autodelvn
┊${chat.antiAudio ? '✅' : '❌'} antiaudio
┊${chat.antiBadword ? '✅' : '❌'} antibadword
┊${chat.antiBot ? '✅' : '❌'} antibot
┊${chat.antiLink ? '✅' : '❌'} antilink
┊${chat.antiLink2 ? '✅' : '❌'} antilink2 (no kick)
┊${chat.antiChannel ? '✅' : '❌'} antichannel
┊${chat.antiPromosi ? '✅' : '❌'} antipromosi
┊${chat.delete ? '✅' : '❌'} antidelete
┊${chat.antiSpam ? '✅' : '❌'} antispam
┊${chat.antiSticker ? '✅' : '❌'} antisticker
┊${chat.antiToxic ? '✅' : '❌'} antitoxic
┊${chat.antiFoto ? '✅' : '❌'} antifoto
┊${chat.antiVideo ? '✅' : '❌'} antivideo
┊${chat.autoSticker ? '✅' : '❌'} autosticker
┊${chat.alarmSahur ? '✅' : '❌'} alarmsahur
┊${chat.antiHt ? '✅' : '❌'} antihidetag
┊${chat.antiNsfw ? '✅' : '❌'} antinsfw
${cmenuf}

${cmenut} *${kyzryzz}For Owner${kyzryzz}* ${cmenuh}
┊${bot.notifyGroupUpdate ? '✅' : '❌'} groupupdate
┊${bot.antiCall ? '✅' : '❌'} anticall
┊${bot.gcDesc ? '✅' : '❌'} autodesc
┊${bot.animeUpdate ? '✅' : '❌'} animeupdate
┊${db.data.antibrat ? '✅' : '❌'} antibrat
┊${bot.autoBio ? '✅' : '❌'} autobio
┊${bot.backupSC ? '✅' : '❌'} autobackupsc
┊${bot.joinFirst ? '✅' : '❌'} joinfirst
┊${bot.onlyprem ? '✅' : '❌'} onlyprem
┊${global.opts['self'] ? '✅' : '❌'} public
┊${chat.simi ? '✅' : '❌'} simi
┊${chat.autoAi ? '✅' : '❌'} autoai
┊${chat.autoJoin ? '✅' : '❌'} autojoin
┊${user.autolevelup ? '✅' : '❌'} autolevelup
┊${chat.bcjoin ? '✅' : '❌'} bcjoin
┊${chat.detect ? '✅' : '❌'} detect
┊${global.opts['restrict']  ? '✅' : '❌'} restrict
┊${global.opts['nyimak']  ? '✅' : '❌'} nyimak
┊${global.opts['pconly']  ? '✅' : '❌'} pconly
┊${global.opts['gconly']  ? '✅' : '❌'} gconly
┊${global.opts['swonly']  ? '✅' : '❌'} swonly
┊${bot.viewStory ? '✅' : '❌'} viewstory
${cmenuf}

*Exᴀᴍᴘʟᴇ ғᴏʀ ᴜsɪɴɢ:*
> *${kyzryzz}.on welcome${kyzryzz}* <To ᴀᴄᴛɪᴠᴀᴛᴇ>
> *${kyzryzz}.off welcome${kyzryzz}* <To ᴅᴇᴀᴄᴛɪᴠᴀᴛᴇ>\n`, 1)
      if (!/[01]/.test(command)) return conn.footerTxt(m.chat, stt, footer, m)
      throw false
  }
  m.reply(await style(`${type} sukses ${isEnable ? 'aktif' : 'non-aktif'} untuk ${isAll ? 'bot ini' : isUser ? '' : 'chat ini'} \n\n> ${wm}`, 1))
}
handler.help = ['enable', 'disable']
handler.tags = ['group', 'owner']
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?o(n|ff)|[01])$/i
export default handler