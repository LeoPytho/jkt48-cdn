import { canLevelUp, xpRange } from '../lib/levelling.js';
import can from 'knights-canvas';

export async function before(m) {
    let user = global.db.data.users[m.sender];
    let { min, xp, max } = xpRange(user.level, global.multiplier);
    if (!user.autolevelup) return true;

    let before = user.level;
    while (canLevelUp(user.level, user.exp, global.multiplier)) user.level++;

    const roles = [
        'Newbie ㋡', 'Beginner Grade 1 ⚊¹', 'Beginner Grade 2 ⚊²', 'Beginner Grade 3 ⚊³', 'Beginner Grade 4 ⚊⁴',
        'Private Grade 1 ⚌¹', 'Private Grade 2 ⚌²', 'Private Grade 3 ⚌³', 'Private Grade 4 ⚌⁴', 'Private Grade 5 ⚌⁵',
        'Corporal Grade 1 ☰¹', 'Corporal Grade 2 ☰²', 'Corporal Grade 3 ☰³', 'Corporal Grade 4 ☰⁴', 'Corporal Grade 5 ☰⁵',
        'Sergeant Grade 1 ≣¹', 'Sergeant Grade 2 ≣²', 'Sergeant Grade 3 ≣³', 'Sergeant Grade 4 ≣⁴', 'Sergeant Grade 5 ≣⁵',
        'Staff Grade 1 ﹀¹', 'Staff Grade 2 ﹀²', 'Staff Grade 3 ﹀³', 'Staff Grade 4 ﹀⁴', 'Staff Grade 5 ﹀⁵',
        'Sergeant Grade 1 ︾¹', 'Sergeant Grade 2 ︾²', 'Sergeant Grade 3 ︾³', 'Sergeant Grade 4 ︾⁴', 'Sergeant Grade 5 ︾⁵',
        '2nd Lt. Grade 1 ♢¹', '2nd Lt. Grade 2 ♢²', '2nd Lt. Grade 3 ♢³', '2nd Lt. Grade 4 ♢⁴', '2nd Lt. Grade 5 ♢⁵',
        '1st Lt. Grade 1 ♢♢¹', '1st Lt. Grade 2 ♢♢²', '1st Lt. Grade 3 ♢♢³', '1st Lt. Grade 4 ♢♢⁴', '1st Lt. Grade 5 ♢♢⁵',
        'Major Grade 1 ✷¹', 'Major Grade 2 ✷²', 'Major Grade 3 ✷³', 'Major Grade 4 ✷⁴', 'Major Grade 5 ✷⁵',
        'Colonel Grade 1 ✷✷¹', 'Colonel Grade 2 ✷✷²', 'Colonel Grade 3 ✷✷³', 'Colonel Grade 4 ✷✷⁴', 'Colonel Grade 5 ✷✷⁵',
        'Brigadier Early ✰', 'Brigadier Silver ✩', 'Brigadier Gold ✯', 'Brigadier Platinum ✬', 'Brigadier Diamond ✪',
        'Major General Early ✰', 'Major General Silver ✩', 'Major General Gold ✯', 'Major General Platinum ✬', 'Major General Diamond ✪',
        'Lt. General Early ✰', 'Lt. General Silver ✩', 'Lt. General Gold ✯', 'Lt. General Platinum ✬', 'Lt. General Diamond ✪',
        'General Early ✰', 'General Silver ✩', 'General Gold ✯', 'General Platinum ✬', 'General Diamond ✪',
        'Commander Early ★', 'Commander Intermediate ⍣', 'Commander Elite ≛', 'The Commander Hero ⍟', 'Legends 忍'
    ];

    user.role = roles[Math.min(user.level / 2, roles.length - 1) | 0] || 'Legends 忍';

    if (before !== user.level) {
        let ini_txt = `🎉  [  *L  E  V  E  L   U  P*  ] \n\n` +
            `┌  ◦ *Level Up* : [ Lv.${before} ] ➠ [ Lv.${user.level} ]\n` +
            `│  ◦ *Role Up* : ${user.role}\n` +
            `└  ◦ *Your Exp* : ${user.exp}\n\n` +
            `> teruslah berinteraksi dengan bot agar exp mu bertambah`;

        let nama = user.name || m.pushName || conn.getName(m.sender);
        let btn = [
            { buttonId: `/me`, buttonText: { displayText: "👤 ᴍʏ ᴘʀᴏғɪʟᴇ" } },
            { buttonId: `/menu`, buttonText: { displayText: "📜 ᴍᴇɴᴜ" } }
        ];

        try {
            let pp = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://i.ibb.co/m53WF9N/avatar-contact.png');
            let image = await new can.Rank()
                .setAvatar(pp)
                .setUsername(nama.replaceAll('\n', ''))
                .setBg('https://telegra.ph/file/a4cfa00b74e7745aea098.jpg')
                .setNeedxp(xp)
                .setCurrxp(user.exp - min)
                .setLevel(user.level)
                .setRank('https://i.ibb.co/Wn9cvnv/FABLED.png')
                .toAttachment();
            let data = await image.toBuffer();
            await conn.bubbleImg(m.chat, data, ini_txt, wm, btn, m).catch(() => conn.sendFile(m.chat, data, "levelup.jpg", ini_txt, m));
        } catch (e) {
            console.error(e);
        }
    }
}

export const disabled = false;
