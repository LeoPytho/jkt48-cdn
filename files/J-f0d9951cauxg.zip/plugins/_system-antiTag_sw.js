/*
- Fitur: Anti @Grub ini disebut
- Info: Kode Plugins Ini Blum 99% Work Karena Masih Di Uji Coba Namun Silahkan Di Coba Dulu Jika Eror Chat Admin ya wa.me/66962130137
- Type: Plugins
- By: HamzDxD

- [ `Source`]
- https://whatsapp.com/channel/0029Vb1NWzkCRs1ifTWBb13u
*/

import fs from 'fs'
import path from 'path'

const antiTagSWPath = path.join('./database/antitagsw.json');

if (!fs.existsSync(antiTagSWPath)) {
    fs.writeFileSync(antiTagSWPath, '{}', 'utf-8');
}

const loadAntiTagSW = () => JSON.parse(fs.readFileSync(antiTagSWPath, 'utf-8'));
const saveAntiTagSW = (data) => fs.writeFileSync(antiTagSWPath, JSON.stringify(data, null, 4), 'utf-8');

let antiTagSWGroup = loadAntiTagSW();

let handler = async (m, { conn, args, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya bisa digunakan di grup.");
    if (!(isAdmin || isOwner)) return m.reply("❌ Hanya admin yang bisa mengaktifkan fitur ini.");

    if (!args[0]) return m.reply("⚠️ Gunakan: .antitagsw on/off");

    if (args[0] === "on") {
        antiTagSWGroup[m.chat] = true;
        saveAntiTagSW(antiTagSWGroup);
        return m.reply("✅ *Anti Tag Status WhatsApp AKTIF di grup ini!*");
    } else if (args[0] === "off") {
        delete antiTagSWGroup[m.chat];
        saveAntiTagSW(antiTagSWGroup);
        return m.reply("❌ *Anti Tag Status WhatsApp DIMATIKAN di grup ini!*");
    } else {
        return m.reply("⚠️ Pilih: on/off");
    }
};

handler.before = async (m, { conn }) => {
    if (!m.isGroup || !m.chat) return;
    if (!antiTagSWGroup[m.chat]) return;
    if (!m.message?.groupStatusMentionMessage) return;

    let groupId = m.chat;
    let senderId = m.sender;
    let groupMetadata = await conn.groupMetadata(groupId);
    let botNumber = conn.user.jid;
    let isBotAdmin = groupMetadata.participants.some(p => p.id === botNumber && p.admin);

    if (!isBotAdmin) return;

    await conn.sendMessage(groupId, { delete: m.key });
    await conn.groupParticipantsUpdate(groupId, [senderId], "remove");
};

handler.command = ['antitagsw'];
handler.group = true;
handler.admin = true

export default handler