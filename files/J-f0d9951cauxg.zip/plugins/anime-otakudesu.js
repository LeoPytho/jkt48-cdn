import cheerio from 'cheerio';
const {
searchAnime, 
opsidownloadanime,
getAnimeDetails,
otakupdate,
fetchUpdates,
getEpisodeLinks
} = await import('../scraper/otakudesu.js');

let handler = async(m, { conn, text }) => {

    const episodeRegex = /^https:\/\/otakudesu\.cloud\/episode\/.+/;
    if (!text) {
        fetchUpdates();
    } else if (episodeRegex.test(text)) {
        let response = await getEpisodeLinks(text);
        m.reply(response);
    } else if (text.startsWith('http')) {
        let response = await getAnimeDetails(text);
        if (response.length === 0) return m.reply(`Gagal Mendapatkan Respon Api.`);

        const detailanime = `*📰 Anime Details Otakudesu*\n` +
            `Judul: ${response[0].judul}\n` +
            `Skor: ${response[0].skor}\n` +
            `Produser: ${response[0].produser}\n` +
            `Tipe: ${response[0].tipe}\n` +
            `Status: ${response[0].status}\n` +
            `Studio: ${response[0].studio}\n` +
            `Rilis: ${response[0].rilis}\n` +
            `Episode: ${response[0].episode}\n` +
            `Genre: ${response[0].genre}\n\n` +
            `*📖 Sinopsis:*\n\n${response[0].sinopsis}\n\n` +
            `*🔗 Episode Link:*\n${response[0].downanime.join('\n')}`;

        conn.sendMessage(m.chat, {
            image: {
                url: response[0].thumbnail
            },
            caption: detailanime
        }, {
            quoted: m
        });
    } else {
        let searchResults = await searchAnime(text);
        if (searchResults.length === 0) return m.m.reply(`Anime tidak ditemukan.`);

        let responseMessage = `*Hasil Pencarian untuk "${text}":*\n\n`;
        searchResults.forEach((anime, index) => {
            responseMessage += `${index + 1}. *${anime.title}*\n`;
            responseMessage += ` Link: ${anime.link}\n`;
            responseMessage += ` Image: ${anime.image}\n`;
            responseMessage += ` Genre: ${anime.genres.join(', ')}\n`;
            responseMessage += ` Status: ${anime.status}\n`;
            responseMessage += ` Skor: ${anime.rating}\n\n`;
        });

        m.reply(responseMessage);
    }
}

handler.command = handler.help = ["otakudesu"];
handler.tags = ["anime"];
handler.limit = handler.register = true;

export default handler;