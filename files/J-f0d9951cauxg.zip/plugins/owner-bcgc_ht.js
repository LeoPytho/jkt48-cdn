import fs from 'fs'
import fetch from 'node-fetch'
let handler = async(m, { conn, text, participants }) => {
    const delay = time => new Promise(res => setTimeout(res, time)) 

const feriv = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: '0@s.whatsapp.net'
  },
  message: { conversation: '_Kyz Project. Terverifikasi Oleh WhatsApp_' }
}
    let getGroups = await conn.groupFetchAllParticipating()
    let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
    let anu = groups.map(v => v.id)
    for (let i of anu) {
    await delay(500)
    conn.sendMessage(i, { text: text, mentions: participants.map(a => a.id) }, {quoted:feriv}).catch(_ => _)
    }
}
handler.help = ['bcgcht']
handler.tags = ['owner']
handler.command = /^(bcgcht)$/i

handler.group = true
handler.owner = true

export default handler