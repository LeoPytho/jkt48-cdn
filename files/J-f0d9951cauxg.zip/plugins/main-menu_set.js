/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus

 * Recode By: KyzRyzz XD
 * 𝘵𝘦𝘭𝘦: https://t.me/kyzryzz
 * 𝘪𝘯𝘧𝘰: https://s.id/kyzzxd
 * 𝘺𝘵: https://youtube.com/@Always-Kyzx
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
**/
/*
set template by tioo
*/
const handler = async (m, { conn, text, args, usedPrefix, command }) => {

let _p = usedPrefix
let cmd = command
    // Database 
    const menu = global.db.data.settings[conn.user.jid];
        
    // Type 
    const type = (args[0] || '').toLowerCase();
    
    let isiMenu = [];
        for (const pus of menus) {
        isiMenu.push({
            header: `Template ${pus}`,
            title: `Tampilan Menu ${pus}`,
            description: "",
            id: `.template ${pus.toLowerCase()}`,
        });
    }
    
    // Command 
    switch (type) {
        case 'image':
            menu.image = true;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Image*');
            break;
        case 'gif':
            menu.image = false;
            menu.gif = true;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Gif*');
            break;
        case 'teks':
        case 'text':
            menu.image = false;
            menu.gif = false;
            menu.teks = true;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Text*');
            break;
        case 'doc': 
        case 'document':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = true;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Document*');
            break;
        case 'footer':
        case 'ftr':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = true;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Footer*');
            break;
        case 'footerImg':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = true;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Footer Image*');
        break;
        case 'footerVid':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = true;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Footer Video*');
        break;
        case 'fthumbimg':
        case 'ftimg':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = true;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change template *Footer Thumbnail Image*');
        break;
        case 'ftumbvid':
        case 'ftvid':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = true;
            menu.buttonV1 = false
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change menu *Footer Thumbnail Video*');
            break;
        case 'buttonv1':
        case 'btnv1':
        case 'v1':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = true
            menu.buttonV2 = false
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change menu *Button V1*');
            break;
        case 'buttonv2':
        case 'btnv2':
        case 'v2':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false
            menu.buttonV2 = true
            menu.buttonV3 = false;
            menu.buttonV4 = false;
            m.reply('Success change menu *Button V2*');
            break;
        case 'buttonv3':
        case 'btnv3':
        case 'v3':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false;
            menu.buttonV2 = false;
            menu.buttonV3 = true;
            menu.buttonV4 = false;
            m.reply('Success change menu *Button V3*');
            break;
        case 'buttonv4':
        case 'btnv4':
        case 'v4':
            menu.image = false;
            menu.gif = false;
            menu.teks = false;
            menu.doc = false;
            menu.footer = false;
            menu.footerImg = false;
            menu.footerVid = false;
            menu.footerThumbImg = false;
            menu.footerThumbVid = false;
            menu.buttonV1 = false;
            menu.buttonV2 = false;
            menu.buttonV3 = false;
            menu.buttonV4 = true;
            m.reply('Success change menu *Button V4*');
            break;
            default:
        
 const data = {
    title: "ᴘɪʟɪʜ ᴛᴇᴍᴘʟᴀᴛᴇ ᴍᴇɴᴜ!",
    sections: [{
            title: "⚡ Powered By Kyzryzz",
            rows: [...isiMenu],
        }
    ]
};
const kyz = `Silahkan pilih salah satu template menu:

${_p + cmd} ${menus[0]}
${_p + cmd} ${menus[1]}
${_p + cmd} ${menus[2]}
${_p + cmd} ${menus[3]}
${_p + cmd} ${menus[4]}
${_p + cmd} ${menus[5]}
${_p + cmd} ${menus[6]}
${_p + cmd} ${menus[7]}
${_p + cmd} ${menus[8]}
${_p + cmd} ${menus[9]}
${_p + cmd} ${menus[10]}
${_p + cmd} ${menus[11]}
${_p + cmd} ${menus[12]}
`
return conn.sendListButton(m.chat, "[🍽] Template tampilan menu", data,
    kyz + "\n" + wm)
    }
};
    const menus = ['teks', 'document', 'image', 'gif', 'footer', 'footerImg', 'footerVid', 'fthumbimg', 'fthumbvid', 'buttonV1', 'buttonV2', 'buttonV3', 'buttonV4'];

handler.help = menus.map(v => `template ${v}`);
handler.tags = ['owner','main'];
handler.command = /^(template|setmenu)$/i;

handler.group = false;
handler.rowner = true;

export default handler;