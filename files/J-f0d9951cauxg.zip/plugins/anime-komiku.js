import axios from 'axios';
import cheerio from 'cheerio';

let handler = async(m, { conn, text }) => {

if(!text) throw '[❗] *Ex:*\n\n> Search\n.komiku <query>\n\nDetail\n.komiku <link>'

if (/komiku.id/.test(text)) {
const komide = await detail(text)

  let ya = `[ *Komiku Search* ]\n\n`
     ya += `*Judul:* ${komide.title}\n`
     ya += `*Deskripsi:* ${komide.description}\n`
     ya += `*Genre:* ${komide.genres}\n`
     ya += ``

    conn.sendMessage(m.chat, {
         image: {
                 url: komide.coverImage
         },
          caption: ya
         }, {
            quoted: m
         })
    } else {
       const komi = await komiku("manga", text)

       let ya = `[ *Komiku Search* ]\n\n`
       for (let i of komi) {
            ya += `\n`
            ya += `*Judul:* ${i.title}\n`
            ya += `*Genre:* ${i.genre}\n`
            ya += `*Deskripsi:* ${i.description}\n`
            ya += `*Url:* ${i.url}\n\n`
            ya += `---\n\n`
   }
       m.reply(ya)
    }
  }

handler.help = handler.command = ["komiku"]
handler.tags = ["anime"]
export default handler;

async function komiku(type = "manga", name) {
  try {
    const { data } = await axios.get(`https://api.komiku.id/?post_type=${type}&s=${name}&APIKEY=undefined`);
    const $ = cheerio.load(data);

    const mangaList = [];
    
    $('.bge').each((i, elem) => {
      const title = $(elem).find('h3').text().trim();
      const genre = $(elem).find('.tpe1_inf b').text().trim();
      const description = $(elem).find('p').text().trim();
      const imageUrl = $(elem).find('img').attr('src');
      const mangaUrl = $(elem).find('a').attr('href');
      
      mangaList.push({
        title,
        genre,
        description,
        img: imageUrl,
        url: "https://komiku.id/" + mangaUrl
      });
    });

    return mangaList;
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    return { error: error.message };
  }
}

async function detail(url) {
   const { data } = await axios.get(url);
   
   let $ = cheerio.load(data);

   const title = $('span[itemprop="name"]').text().trim();
   const description = $('p[itemprop="description"]').text().trim();
   const awalChapter = $('a[title*="Chapter 01"]').text().trim();
   const terbaruChapter = $('a[title*="Chapter 165"]').text().trim();
   const coverImage = $('img[itemprop="image"]').attr('src');
   const genres = [];
   $('ul.genre li').each((i, el) => {
      genres.push($(el).text().trim());
   });

   return {
      title,
      description,
      awalChapter,
      newChapter: terbaruChapter,
      coverImage,
      genres
   };
}