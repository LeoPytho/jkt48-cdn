import axios from 'axios';
import yts from 'yt-search';

let handler = async(m, { conn, text, usedPrefix, command }) => {
  let urls = m.quoted?.text?.match(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|playlist\?list=)?)([a-zA-Z0-9_-]{11})/gi) || text?.match(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|playlist\?list=)?)([a-zA-Z0-9_-]{11})/gi);
  if (!urls) return m.reply('Pesan yang Anda reply tidak mengandung URL YouTube atau teks pencarian.');
  
  m.reply('Tunggu sebentar ya kak ^^')
  m.react("⏱️");

  let search = await yts(urls[0]);
  let vid = search.videos[0];
  if (!vid) return m.reply('Video tidak ditemukan.');

  let durationParts = vid.timestamp.split(':').map(Number);
  let totalSeconds = durationParts.length === 3 ? durationParts[0] * 3600 + durationParts[1] * 60 + durationParts[2] : durationParts[0] * 60 + durationParts[1];

  if (totalSeconds > 1800) return m.reply('⏱️ Maaf, durasi video melebihi 30 menit. Unduhan dibatalkan.');

  try {
    let res = await axios.get(`https://api.nazir.my.id/api/ytmp4?apikey=fe401a3e-4eae-4bd4-9583-e9b8459db715&url=${encodeURIComponent(vid.url)}`);
    let anu = res.data.result;

    let Apsijir = `*[  YT VIDEO DOWNLOAD ]*

*🔖 Judul:* ${anu.metadata.title}
*⏳ Durasi:* ${anu.metadata.duration}
*🕰 Waktu Unggah:* ${anu.metadata.ago}
*👀 Jumlah Tayang:* ${anu.metadata.views}
*👤 Penerbit:* ${anu.metadata.author}
*🌐 URL:* ${anu.metadata.url}
*🖼 Thumbnail:* ${anu.thumbnail}`
    
      await conn.sendMessage(m.chat, {
      video: { url: anu.dl },
      mimetype: 'video/mp4',
      caption: Apsijir,
      footer: '',
      buttons: [
        {
          buttonId: `.ytmp3 ${anu.metadata.url}`,
          buttonText: { displayText: '🎵 Audio' },
          type: 1
        }
      ],
      viewOnce: true,
      contextInfo: {
        externalAdReply: {
          title: anu.metadata.title,
          body: 'YouTube Video Downloader',
          thumbnailUrl: anu.thumbnail,
          sourceUrl: anu.metadata.url,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })
  } catch (e) {
    throw e;
  }

  m.react("✅");
}

handler.help = ['ytmp4'];
handler.tags = ['downloader'];
handler.command = /^(ytmp4|ytv|ytvideo|video)$/i;
handler.limit = true;

export default handler;