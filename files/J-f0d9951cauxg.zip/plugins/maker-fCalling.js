/*
📌 Nama Fitur: fake calling by velyn api
🏷️ Type : Plugin ESM
🔗 Sumber : https://whatsapp.com/channel/0029VaxvdhJ6buMSjkRBNR2d
✍️ Convert By ZenzXD
*/

const handler = async (m, { conn, text }) => {
  if (!text.includes('|')) {
    return m.reply(`Format salah!\n\nContoh:\n.fcalling pacar aku|11:22|https://telegra.ph/file/xxxxx.jpg`)
  }

  let [name, duration, avatar] = text.split('|').map(v => v.trim())
  if (!name || !duration || !avatar) return m.reply('Semua parameter wajib diisi!')

  const api = `https://velyn.biz.id/api/maker/calling?name=${encodeURIComponent(name)}&duration=${encodeURIComponent(duration)}&avatar=${encodeURIComponent(avatar)}&apikey=velyn`

  try {
    const res = await fetch(api)
    if (!res.ok) throw await res.text()

    const buffer = await res.arrayBuffer()
    await conn.sendFile(m.chat, Buffer.from(buffer), 'calling.jpg', 'done cuyy', m)
  } catch (err) {
    console.error(err)
    m.reply('❌ Gagal membuat fake calling. Pastikan parameter valid atau coba lagi nanti.')
  }
}

handler.command = ['fcalling']
handler.help = ['fcalling <name>|<duration>|<avatar>']
handler.tags = ['maker']
handler.limit = true

export default handler