var handler = async (m, { args, conn, usedPrefix, command }) => {
    if (!args[0]) throw `Ex:\n${usedPrefix}${command} https://www.instagram.com/reel/C0EEgMNSSHw/?igshid=MzY1NDJmNzMyNQ==`;
    try {
        let res = (await axios.get(APIs.ft+"/download/instagram?url="+args[0])).data;
        let media = res.result.url[0];
        let isPhoto = media.ext === 'jpg';
        const sender = m.sender.split(`@`)[0];

        let { key } = conn.sendMessage(m.chat, {text: `🔁 Sedang mengunduh ${isPhoto ? 'image...' : 'video...'}` }, { quoted:m });
       m.react("⏱️") 
        let {
        username: uploader, 
        title: title, 
        source: source, 
        comment_count: commentCount, 
        like_count: likeCount, 
        taken_at: uploadAt
        } = res.result.meta;
        let yy = ` "title": "${title || ''}", 
 "uploader": "${uploader || 'unknown'}",
 "commentCount": "${func.format.count(commentCount) || '0'}", 
 "likeCount": "${func.format.count(likeCount) || '0'}", 
 "uploadAt": "${func.format.date(uploadAt) || 'unknown'}", 
 "duration": "${func.format.time(res.result.timestamp) || '0'}",
 "source": "${source || 'unknown'}"`;
        let meta = `{
 ${yy}
}
`;
        if (!res) throw 'Can\'t download the post';
        let hm = conn.sendMessage(m.chat, { text: "✅ Selesai, video berhasil diunduh..", edit: key }, { quoted: m })
        let yeah = conn.sendMessage(m.chat, { text: "_Media sedang dikirim_", edit: hm.key })

        if (isPhoto) {
         await conn.sendMessage(m.chat, { image: { url: media.url }, caption: meta }, { quoted: m });
        } else {
        let hore = await conn.sendMessage(m.chat, { video: { url: media.url }, fileName: `${title}.mp4`, caption: meta, contextInfo: { isForwarded: true, forwardedNewsletterMessageInfo: { newsletterName: "⏱️ Duration: " + func.format.time(res.result.timestamp), newsletterJid: idch, serverMessageId: -1 }}}, {quoted:m});
      
      await conn.sendMessage(m.chat, { 
        document: { url: media.url }, 
        mimetype: 'video/mp4', 
        fileName: `${title || '(ig)no_title'}.mp4`,
        caption: `ini kak videonya @${sender} versi dokumen, agar jernih`, mentions: [m.sender]
      }, {quoted: hore})
      
      conn.sendMessage(m.chat, { delete: yeah })
      m.react("✅")
      m.react("") 
      }
    } catch (e) {
          console.log(e);
          conn.reply(m.chat, 'Gagal mengunduh video', m);
      }
};

handler.help = ['instagram'];
handler.tags = ['downloader'];
handler.command = /^(ig(dl)?|instagram(dl)?)$/i;

export default handler;