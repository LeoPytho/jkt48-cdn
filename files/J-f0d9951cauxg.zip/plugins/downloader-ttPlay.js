import axios from 'axios'

let handler = async function (m, { conn, text, usedPrefix: _p, command }) {
  if (!text) return m.reply('[❗] Masukkan atau judul tiktok!')
  try {
        let results = await tiktokSearch(text);
        if (!results || results.length === 0) return m.reply("❌ Tidak ada video ditemukan.");
        let vidnya = results[0].download
        let audionya = results[0].audio
        let title = results[0].title

    await conn.sendMessage(m.chat, {
      video: { url: vidnya },
      caption: title,
      buttons: [
        {
          buttonId: ".menu",
          buttonText: { displayText: "[ Menu ]" }
        },
        {
          buttonId: `.ttsearch ${text}`,
          buttonText: { displayText: "[ More results ]" }
        }
      ],
      viewOnce: true,
      headerType: 6,
      contextInfo: {
        externalAdReply: {
          title: ` [ </> Tiktok Play </> ]`,
          body: `${title}`,
          thumbnailUrl: results[0].thumbnail,
          sourceUrl: saluran,
          mediaType: 1,
          mentionedJid: [m.sender],
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

 await conn.sendMessage(m.chat, { 
audio: { url: audionya },
mimetype: "audio/mp4",
ptt: false,
}, { quoted: m})

  } catch (error) {
    m.reply(`[❗] Terjadi kesalahan, coba lagi.: ${eror}`)
  }
}

handler.help = ['ttplay', 'tiktokplay'].map(v => v + ' <judul>')
handler.tags = ['downloader']
handler.command = /^(ttplay|tiktokplay)$/i

export default handler

async function tiktokSearch(query) {
    try {
        const response = await axios.get(`https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(query)}&count=7`);
        
        const videos = response.data.data.videos;
        if (!videos || videos.length === 0) return [];

        return videos.slice(0, 7).map(video => {
            let url = `https://www.tiktok.com/@${video.author.unique_id}/video/${video.video_id}`;
            return {
                title: video.title || "Video TikTok",
                url: url, // URL TikTok asli
                download: video.play,  // Video tanpa watermark
                audio: video.music,  // Link audio
                thumbnail: video.cover
            };
        });
    } catch (error) {
        console.error("Error fetching TikTok search:", error);
        return [];
    }
}