/* 𝘐𝘯𝘪 𝘞𝘮
Plugin sfiledl type=esm
Tqto penyedia api😘
𝘚𝘶𝘮𝘣𝘦𝘳?
𝘊𝘩: https://whatsapp.com/channel/0029VagEmD96hENqH9AdS72V/306
*/

import fetch from 'node-fetch';

const fetchSfileData = async (url) => {
    const response = await fetch(`https://restapi.apibotwa.biz.id/api/sfiledl?url=${url}`);
    if (!response.ok) throw new Error(`Failed to fetch data (HTTP ${response.status})`);
    const result = await response.json();
    if (result.status !== 200 || !result.data.response.success) throw new Error('Invalid response from API');
    return result.data.response;
};

const downloadFile = async (url) => {
    const response = await fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        },
    });
    if (!response.ok) throw new Error(`File download failed (HTTP ${response.status})`);
    return response.buffer();
};

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('🚫 *Error:* Please provide a valid Sfile link.');

    try {
        const file = await fetchSfileData(text);

        const caption = `🎉 *File Details:*\n\n📂 *Name:* ${file.filename}\n📦 *Type:* ${file.mimetype}\n\n⏳ *Downloading...*`;
        await conn.sendMessage(m.chat, { text: caption }, m);

        const fileBuffer = await downloadFile(file.downloadLink);
        await conn.sendMessage(m.chat, {
            document: fileBuffer,
            mimetype: file.mimetype,
            fileName: file.filename,
        }, m);
    } catch (error) {
        console.error('Error:', error.message);
        m.reply(`❌ *Error:* ${error.message}`);
    }
};

handler.help = ['sfile'];
handler.tags = ['downloader'];
handler.command = /^(sfile|sfiledl)$/i;

export default handler;