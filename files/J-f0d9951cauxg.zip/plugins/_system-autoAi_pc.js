import natural from 'natural'
import yts from 'yt-search'

export async function all(m) {
  if (!settings.ai) return
  if (m.chat.endsWith('@newsletter') || m.chat.endsWith('@broadcast')) return
  if (m.fromMe) return
  if (m.isGroup) return

  const text = m.text || ''
  if (!text) return
  
  try {
  const q = m.quoted || m
  const mime = (q.msg || q).mimetype || q.mediaType || ''
  this.sendPresenceUpdate(['composing'], m.chat)

  const prefix = /^[°zZ#$+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(text)
    ? text.match(/^[°zZ#$+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/)[0]
    : '.'
  if (text.startsWith(prefix)) return

  const { data } = await axios.get(`${APIs.ft}/ai/furina?content=${text}&user=${name.split(" ")[0] || name || "user"}`)

  const playKeywords = ['putar','putarkan','putarlagu','lagu','cariin','carikan','mainkan','mainkanlagu','play','playmusic','playasong']
  const hasPlay = playKeywords.some(k => text.toLowerCase().includes(k))
  if (hasPlay) {
    try {
      const urls = q.text?.match(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/.*?v=|shorts\/)([A-Za-z0-9_-]{11})/gi)
      const tokenizer = new natural.WordTokenizer()
      const tokens = tokenizer.tokenize(text.toLowerCase())
      const keyword = tokens.find(t => playKeywords.includes(t))
      const songName = keyword ? tokens.slice(tokens.indexOf(keyword) + 1).join(' ') : text
      let huh = await conn.sendMessage(m.chat, { text: `Oke, tunggu sebentar ya~ Furina sedang mencari "${songName}" untukmu! 😉`, contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }
      }, { quoted: m })

      let audioUrl, title
      if (urls) {
        audioUrl = await b(urls[0])
        title = songName
      } else {
        const search = await yts(songName)
        const video = search.videos[0]
        audioUrl = await b(video.url)
        title = video.title
      }
            
      const sent = await conn.sendAudio(m.chat, audioUrl.url, false, huh)

      await conn.sendMessage(m.chat, {text: `Berikut adalah lagu yang kamu minta: ${title}`, contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }}, { quoted: sent })
    } catch (e) {
      await conn.sendMessage(m.chat, {text: e.message, contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }}, { quoted: m })
    }
    return
  }

  const imgKeywords = ['poto','foto','gambar']
  const hasImg = imgKeywords.some(k => text.toLowerCase().includes(k))
  if (hasImg) {
    try {
      const tokenizer = new natural.WordTokenizer()
      const tokens = tokenizer.tokenize(text.toLowerCase())
      const keyword = tokens.find(t => imgKeywords.includes(t))
      const query = keyword ? tokens.slice(tokens.indexOf(keyword) + 1).join(' ') : text
      const result = await pinterest(query)
      await conn.sendMessage(m.chat, { image: { url: result }, fileName: `${query}.jpg`, caption: `Nih dari foto: ${query}😉`, contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }}, m)
    } catch {
      await conn.sendMessage(m.chat, {text:`Maaf, Furina tidak bisa memberikan foto "${text}"`, contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }}, { quoted: m })
    }
    return
  }

  if (!/image/.test(mime)) {
    const response = data.result.message
    await conn.sendMessage(m.chat, {
      text: response,
      ai: true,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }
    }, { quoted: m })
  } else {
    const media = await q.download()
    const link = await func.toUrl(media)
    const response = data.result.message
    await conn.sendMessage(m.chat, {
      text: response,
      ai: true,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '✨ F U R I N A - A I',
          body: 'Powered By 𝖮𝗐𝖾𝗇𝗌𝖣𝖾𝗏',
          mediaType: 1,
          thumbnailUrl: thumb,
          showAdAttribution: true
        }
      }
    }, { quoted: m })
  }
 } catch (e) {
   conn.reply(owner[0][0]+jid, e.stack, m) 
 }
}

async function b(videoUrl) {
  try {
    const { data } = await axios.get(APIs.ft + '/download/youtube', {
      params: { url: videoUrl }
    });
    return data.result.download.mp3;
  } catch (err) {
    if (err.response?.status === 403) throw new Error('Error 403: Akses ditolak oleh server API');
    throw err;
  }
}

async function pinterest(q) {
  const { data } = await axios.get(`${APIs.ft}/search/pinterest?q=`+q)
  return pickRandom(data.result)
}