/*
- PLUGINS LYRICS
- Scrape by: ZErvida
- Soure: https://whatsapp.com/channel/0029VakezCJDp2Q68C61RH2C
*/
import axios from "axios";
import cheerio from "cheerio";
const { googleLyrics } = await import("../scraper/lirik.js");

const handler = async (m, { conn, text, command }) => {
    if (!text) return m.reply(`[❗] Input query\nEx: /${command} blue yung kai`);

    m.reply(wait);

    try {
        const result = await googleLyrics(text);

        if (!result.lyrics) {
            return m.reply("[❗] Lirik tidak ditemukan atau tidak tersedia.");
        }

        const { title, lyrics, subtitle } = result;

        const pesan = `🎵 *LIRIK LAGU*\n\n` +
                      `• *Judul:* ${title || "-"}\n` +
                      `• *Artis:* ${subtitle || "-"}\n\n` +
                      `📖 *Lirik:*\n${lyrics}`;

        await conn.sendMessage(m.chat, { text: pesan }, { quoted: m });

    } catch (error) {
        console.error("Error:", error);
        m.reply(`[❗] Terjadi kesalahan saat mencari lirik. ${error}`);
    }
};

handler.help = ["lirik"];
handler.tags = ["internet"];
handler.command = /^(lirik|lyrics)$/i;
handler.limit = 3;
handler.register = true;

export default handler;