let handler = async (m, { conn, text }) => {
   if (!text) return m.reply('[❗] Input query!');

   m.react('⏱️') 

   let { data: result } = await axios.get(APIs.ft+"/internet/resep?q="+text);
   if (!result.length) return m.reply('[❗] Resep tidak ditemukan!');

   let caption = `*[ 📖 Hasil Pencarian Resep: ${text} ]*\n\n`;
   result.slice(0, 5).forEach((res, i) => {
      caption += `🍽️ Resep {res.title}:*\n🔗 [Lihat Resep](${res.link})\n\n`;
   });

   m.react("✅") 

   await conn.sendMessage(m.chat, { text: caption }, { quoted: m });
};

handler.command = /^(resep|dapurumami)$/i;
handler.help = ['resep <nama masakan>'];
handler.tags = ['internet'];

export default handler;