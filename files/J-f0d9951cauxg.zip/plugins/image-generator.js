let handler = async (m, {conn, text}) => {
    if (!text.includes('|')) return m.reply('[❗] Masukkan judul dan slogan\nEx:\n*/logo <title> | <desc>*\nContoh: */logo Cat | Beauty and Happy*');
    
    let [title, slogan] = text.split('|').map(t => t.trim());

    if (!title) return m.reply('[❗] Judul tidak boleh kosong!');

    m.reply('⏳ Sedang membuat logo...');

    try {
        let payload = {
            ai_icon: [333276, 333279],
            height: 300,
            idea: `A Icon ${title}`,
            industry_index: "N",
            industry_index_id: "",
            pagesize: 4,
            session_id: "",
            slogan: slogan || "",
            title: title,
            whiteEdge: 80,
            width: 400
        };

        let { data } = await axios.post("https://www.sologo.ai/v1/api/logo/logo_generate", payload);

        if (!data || !data.data || !data.data.logoList.length) {
            return m.reply('🚫 Gagal membuat logo.');
        }

        const logoUrls = data.data.logoList.map(logo => logo.logo_thumb);

        let caption = `🎨 *Logo Generator*\n\n`;
        caption += `📌 *Judul*: ${title}\n`;
        caption += `📝 *Slogan*: ${slogan || "-"}\n`;

        await comm.sendMessage(m.chat, { 
            image: { url: logoUrls[0] }, 
            caption: caption 
        }, { quoted: m });

        for (let i = 1; i < logoUrls.length; i++) {
            await conn.sendMessage(from, { 
                image: { url: logoUrls[i] }
            }, { quoted: m });
        }

    } catch (error) {
        reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
}
handler.command = handler.help = ["logo", "logomaker"];
handler.tags = ["image","internet"];
export default handler;