import uploadImage from "../lib/uploadImage.js"

let handler = async (m, { conn, text }) => {
async function load() {
 await m.react(`🕐`)
 await conn.delay(1500)
 await m.react(`🕑`)
 await conn.delay(1500)
 await m.react(`🕓`)
 await conn.delay(1500)
 await m.react(`🕖`)
 await conn.delay(1500)
 await m.react(`🕘`)
 await conn.delay(1500)
 await m.react(`🕙`) 
 await conn.delay(1500)
 await m.react(`🕛`)
}
  const q = m.quoted ? m.quoted : m;
  if (!q) throw `[❗] Kirim/reply foto waifu kamu yang ingin di hijabkan dengan caption */hijabkan*`;
  if (q.mtype !== "imageMessage") throw "[❗] Media hanya mendukung image saja!.";
  
  let image = await q.download();
  
  load() 
  
  let imageUrl = await uploadImage(image);
  const prompt = "edit karakter ini mengenakan hijab dan semua aurat seperti dada/payudara, paha hingga mata kaki, pundak hingga lengan serta leher(jika ada) tertutup oleh hijab atau pakaian!";

    let results = [];
    let anu = 1
    for (let i = 0; i < 5; i++) {
    let { data: { result } } = await axios.get(
      APIs.ft + `/ai/genai?imageUrl=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`
    );

    let buf = Buffer.from(result.image, 'base64');      results.push({
        image: buf,
        caption: `${text} ✅ Success meng-Hijabkan ${anu++}\n\n> ${global.wm || "Powered by Kyzryzz"}`
      });
    }
    if (results.length > 0) {
      await conn.sendAlbumMessage(m.chat, results, { quoted: m });
    }
    setTimeout(async() => {
    await m.react(`✅`)
    }, 2500);
    await m.react(``)
};

handler.command = handler.help = ["hijabkan"];
handler.tags = ["image", "ai", "tools"];
handler.limit = true;

export default handler;