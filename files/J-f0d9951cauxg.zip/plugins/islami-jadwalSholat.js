import axios from 'axios';
import cheerio from 'cheerio';

let handler = async (m, { conn, text }) => {
    const city = text.trim();
    if (!city) {
        m.reply('Silakan sebutkan nama kota. Contoh: .jadwalsholat Jakarta');
        return;
    }

    const jadwal = await getJadwalSholat(city);
    const imageUrls = await googleImg(`masjid terkenal di ${city}`);
    const imageUrl = imageUrls[0] || 'https://via.placeholder.com/150';

    if (typeof jadwal === 'string') {
        m.reply(`Terjadi kesalahan: ${jadwal}`);
    } else {
        let pesan = `Jadwal Sholat untuk kota ${city} pada tahun ${jadwal.tahunSekarang}\n\n`;
        jadwal.hariIni.forEach((item) => {
            pesan += `${item.sholat}: ${item.jadwal}\n`;
        });

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: pesan,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: "[ J a d w a l - S h o l a t ]",
                    body: `Jadwal sholat daerah: ${city}`,
                    thumbnailUrl: imageUrl,
                    renderLargerThumbnail: true,
                }
            }
        });
    }
};

handler.command = handler.help = ["jadwalsholat"];
handler.tags = ["islami"];

export default handler;

async function getJadwalSholat(city) {
    try {
        const url = `https://prayer-times.muslimpro.com/en/find?country_code=ID&country_name=Indonesia&city_name=${encodeURIComponent(city)}`;
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        const tahunSekarang = $('li.monthpicker .display-month').text().trim();
        const jadwalShalat = [];
        $('table.prayer-times tbody tr').each((index, element) => {
            const tanggal = $(element).find('td.prayertime-1').text().trim();
            const imsak = $(element).find('td.prayertime').eq(0).text().trim();
            const shubuh = $(element).find('td.prayertime').eq(1).text().trim();
            const duhur = $(element).find('td.prayertime').eq(2).text().trim();
            const asar = $(element).find('td.prayertime').eq(3).text().trim();
            const magrib = $(element).find('td.prayertime').eq(4).text().trim();
            const isya = $(element).find('td.prayertime').eq(5).text().trim();

            if (tanggal) {
                jadwalShalat.push({ tanggal, imsak, shubuh, duhur, asar, magrib, isya });
            }
        });

        const hariIni = [];
        $('div.prayer-daily-table ul li').each((index, element) => {
            const sholat = $(element).find('.waktu-solat').text().trim();
            const jadwal = $(element).find('.jam-solat').text().trim();
            hariIni.push({ sholat, jadwal });
        });

        return { tahunSekarang, jadwalShalat, hariIni };
    } catch (error) {
        return error.message;
    }
}

async function googleImg(query) {
    try {
        const { data: html } = await axios.get(`https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`);
        const $ = cheerio.load(html);

        const imageUrls = [];
        $('img').each((i, el) => {
            let imgUrl = $(el).attr('src') || $(el).attr('data-src');
            if (imgUrl && imgUrl.startsWith('http')) {
                imageUrls.push(imgUrl);
            }
        });

        return imageUrls;
    } catch (error) {
        return [];
    }
}