export async function before(m, { isAdmin, isBotAdmin }) {
  if (m.isBaileys && m.fromMe) return true;
  let chat = global.db.data.chats[m.chat];
  let isFoto = m.mtype;
  let q = m.quoted ? m.quoted : m;
  if (isFoto !== "imageMessage") return true;
  let y = await func.toUrl(await q.download());
  let { data: { result } } = await axios.get(`${APIs.ft}/tools/nsfwchecker?imageUrl=${y}`);
  let { isNsfw } = result;
  let participant = m.key.participant;
  let messageId = m.key.id;
  if (chat.antiNsfw && isNsfw) {
    if (!isAdmin && isBotAdmin) {
      await m.reply('*⚠️ NSFW TERDETEKSI!*\nFoto yang kamu kirim akan dihapus karena grup ini melarang konten NSFW.');
      await this.sendMessage(
        m.chat,
        {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: messageId,
            participant
          }
        }
      );
      return false;
    }
  }
  return true;
}
