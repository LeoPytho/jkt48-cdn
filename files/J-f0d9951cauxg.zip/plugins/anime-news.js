import axios from 'axios';
import cheerio from 'cheerio';

async function listAnimeNews() {
    try {
        const response = await axios.get('https://www.greenscene.co.id/category/otaku/anime-news/');
        const $ = cheerio.load(response.data);
        const newsArticles = [];

        $('.td-block-span6').each((i, element) => {
            const title = $(element).find('.entry-title a').text().trim();
            const link = $(element).find('.entry-title a').attr('href');
            const date = $(element).find('.td-post-date').text().trim();
            const thumbnail = $(element).find('.td-module-thumb img').attr('src');

            if (title && link && date && thumbnail) {
                newsArticles.push({
                    title,
                    link,
                    date,
                    thumbnail
                });
            }
        });

        return newsArticles;
    } catch (error) {
        return `Error: ${error.message}`;
    }
}

var handler = async (m, { conn }) => {
    conn.reply(m.chat, 'Sedang mencari berita anime... Silahkan tunggu', m);

    let newsList = await listAnimeNews();
    if (newsList.length === 0) {
        return conn.reply(m.chat, 'Tidak Ditemukan Berita Anime!', m);
    }

    let randomArticle = newsList[Math.floor(Math.random() * newsList.length)];

    let newsMessage = `*Berita Anime Terbaru:*\n\n`;
    newsMessage += `🔹 *Judul*: ${randomArticle.title}\n`;
    newsMessage += `📅 *Tanggal*: ${randomArticle.date}\n`;
    newsMessage += `🔗 *Link*: ${randomArticle.link}\n\n`;

    conn.sendFile(m.chat, randomArticle.thumbnail, 'thumbnail.jpg', newsMessage, m);

    conn.reply(m.chat, 'Semoga Membantu! 🙂', m);
}

handler.help = ['animenews'];
handler.tags = ['anime'];
handler.command = /^(animenews)$/i;

export default handler;
