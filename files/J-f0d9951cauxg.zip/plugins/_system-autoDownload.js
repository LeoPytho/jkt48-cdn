import axios from "axios";
import cheerio from "cheerio";
import qs from "qs";
import fetch from "node-fetch";

export async function before(m, { conn }) {
  if (m.isCommand) return;
  const commandRegex = [".tt", ".fb", ".ig", ".twit", ".twitter", ".instagram", ".facebook", ".tiktok", ". tiktok", ". tt"];
  if (commandRegex.some(cmd => m.text.startsWith(cmd))) return;
  const prefix = ["#", "$", ">", ",", "_"]
  if (prefix.some(p => m.text.startsWith(p))) return;
  const fbRegex = /^https?:\/\/(?:www\.)?facebook\.com\/?.*$/;
  const igRegex = /(https?:\/\/(?:www\.)?instagram\.[a-z\.]{2,6}\/[\w\-\.]+(\/[^\s]*)?)/g;
  const tiktokRegex = /(http(?:s)?:\/\/)?(?:www\.)?(?:tiktok\.com\/@[^\/]+\/video\/(\d+))|(http(?:s)?:\/\/)?vm\.tiktok\.com\/([^\s&]+)|(http(?:s)?:\/\/)?vt\.tiktok\.com\/([^\s&]+)/g;
  const twitRegex = /https:\/\/twitter\.com\/[^/]+\/status\/(\d+)/;
  let user = db.data.users[m.sender];
  if (!user.limit || user.limit === 0) {
    await m.reply("[❗] Limit kamu habis\n\n*.claim* atau *.buylimit* untuk mendapatkan limit");
    return;
  }
  try {
    if (fbRegex.test(m.text.trim())) {
      user.limit -= 1;
      m.reply("✔ Limit kamu berkurang 1");
      const fbUrl = m.text.trim().match(fbRegex)[0];
      const { description, urls } = await facebook(fbUrl);
      await conn.sendFile(m.chat, urls[0].url, "", description, m);
    } else if (igRegex.test(m.text.trim())) {
      user.limit -= 1;
      m.reply("✔ Limit kamu berkurang 1");
      const igUrl = m.text.match(igRegex)[0];
      const { data } = await axios.get("https://api.tioxy.my.id/api/igdl?url=" + igUrl);
      for (let i of data.data.media) {
        await conn.sendFile(m.chat, i, "", "✔ Done", m);
      }
    } else if (twitRegex.test(m.text.trim())) {
      user.limit -= 1;
      m.reply("✔ Limit kamu berkurang 1");
      const twitUrl = m.text.trim().match(twitRegex)[0];
      const { data: ress } = await twitter(twitUrl);
      await conn.sendFile(m.chat, ress[0].url, "", "✔ Done", m);
    } else if (tiktokRegex.test(m.text)) {
      user.limit -= 1;
      m.reply("✔ Limit kamu berkurang 1");
      const tiktokUrl = m.text.trim().match(tiktokRegex)[0];
      const { download, stats, uniqueId, username } = await slide(tiktokUrl);
      let hasil = Object.values(download).filter(v => v.type === "slide");
      const tt = await tiktok(tiktokUrl);
      let tiktokData = tt.data;
      let y = "✔ Done, silakan cek private chat wa.me/" + conn.user.jid.split("@")[0];
      if (hasil.length === 0) {
        let kyz = await conn.sendFile(
          m.sender,
          download[0].link,
          "",
          `📃 Judul: *${tiktokData.title || "Tidak Ada"}*
> *[ STATS ]*
> 📲 Unggah: ${format.time(tiktokData.create_time) || "Tidak Diketahui"}
> ♥ Suka: ${format.count(tiktokData.digg_count)}
> 💬 Komen: ${format.count(tiktokData.comment_count)}
> ↪️ Bagikan: ${format.count(tiktokData.share_count)}
> 👀 Penonton: ${format.count(tiktokData.play_count)}
> 📤 Simpan: ${format.count(tiktokData.download_count)}`,
          m
        );
        conn.reply(m.chat, y, kyz, { contextInfo: { mentionedJid: conn.parseMention(y) } });
      } else {
        let medias = [];
        for (let i of hasil) {
          medias.push({
            image: { url: i.link },
            caption: `📃 Judul: *${tiktokData.title || "Tidak Ada"}*
> *[ STATS ]*
> 📲 Unggah: ${format.time(tiktokData.create_time) || "Tidak Diketahui"}
> ♥ Suka: ${format.count(tiktokData.digg_count)}
> 💬 Komen: ${format.count(tiktokData.comment_count)}
> ↪️ Bagikan: ${format.count(tiktokData.share_count)}
> 👀 Penonton: ${format.count(tiktokData.play_count)}
> 📤 Simpan: ${format.count(tiktokData.download_count)}`
          });
        }
        let kyz = await conn.sendAlbumMessage(m.sender, medias, { quoted: m });
        conn.reply(m.chat, y, kyz, { contextInfo: { mentionedJid: conn.parseMention(y) } });
      }
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
}

export const disabled = false;

async function twitter(url) {
  return new Promise((resolve, reject) => {
    let params = new URLSearchParams();
    params.append("URL", url);
    fetch("https://twdown.net/download.php", { method: "POST", body: params })
      .then(res => res.text())
      .then(res => {
        const $ = cheerio.load(res);
        let data = [];
        $("div.container").find("tbody > tr > td").each(function (index, element) {
          let x = $(this).find("a").attr("href");
          if (x && x !== "#") {
            data.push({ url: x });
          }
        });
        if (data.length === 0) return resolve({ status: false });
        resolve({ status: true, data });
      })
      .catch(reject);
  });
}

async function facebook(url) {
  try {
    let { data } = await axios.post(
      "https://getmyfb.com/process",
      qs.stringify({ id: url, locale: "en" }),
      {
        headers: {
          Accept: "*/*",
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Cookie:
            "PHPSESSID=k3eqo1f3rsq8fld57fgs9ck0q9; _token=1AHD0rRsiBSwwh7ypRad; __cflb=04dToeZfC9vebXjRcJCMjjSQh5PprejvCpooJf5xhb; _ga=GA1.2.193364307.1690654540; _gid=GA1.2.326360651.1690654544; _gat_UA-3524196-5=1; _ga_96G5RB4BBD=GS1.1.1690654539.1.0.1690654555.0.0.0",
          Origin: "https://getmyfb.com",
          Referer: "https://getmyfb.com/",
          "Hx-Current-Url": "https://getmyfb.com",
          "Hx-Request": "true",
          "Hx-Target": "target",
          "Hx-Trigger": "form",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188"
        }
      }
    );
    let $ = cheerio.load(data);
    let urls = [];
    $("ul > li").each((index, element) => {
      let quality = $(element).text().trim();
      let url = $(element).find("a").attr("href");
      if (url) {
        urls.push({ quality, url });
      }
    });
    let result = {
      description: $("div.results-item > div.results-item-text").text().trim(),
      urls
    };
    if (urls.length === 0) return $("h4").text();
    return result;
  } catch (e) {
    throw e;
  }
}

async function slide(url) {
  try {
    const response = await axios.post(
      "https://ttsave.app/download",
      { query: url, language_id: "2" },
      {
        headers: {
          Accept: "application/json, text/plain, */*",
          "Content-Type": "application/json"
        }
      }
    );
    const html = response.data;
    const $ = cheerio.load(html);
    const uniqueId = $("#unique-id").val();
    const username = $("h2.font-extrabold.text-xl.text-center").text();
    const thumbnail = $('a[target="_blank"]').attr("href");
    const profile = $("img.h-24.w-34.rounded-full").attr("src");
    const description = $("p.text-gray-600.px-2.text-center.break-all.w-3/4.oneliner").text();
    const stats = {
      views: $("svg.h-5.w-5.text-gray-500 + span").text(),
      likes: $("svg.h-5.w-5.text-red-500 + span").text(),
      comments: $("svg.h-5.w-5.text-green-500 + span").text(),
      shares: $("svg.h-5.w-5.text-yellow-500 + span").text(),
      downloads: $("svg.h-5.w-5.text-blue-500 + span").text()
    };
    const download = [];
    $('a[onclick="bdl(this, event)"]').each((i, elem) => {
      const link = $(elem).attr("href");
      const type = $(elem).attr("type");
      const title = $(elem).text().trim();
      download.push({ link, type, title });
    });
    return {
      uniqueId,
      username,
      thumbnail,
      profile,
      description,
      stats,
      download
    };
  } catch (error) {
    console.error(error);
    throw error;
  }
}

async function tiktok(url) {
  let tikwm = `https://www.tikwm.com/api/?url=${url}?hd=1`;
  let response = await (await fetch(tikwm)).json();
  return response;
}

const format = {
  count: (count) => {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    } else if (count >= 1000) {
      return (count / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    } else {
      return count.toString();
    }
  },
  time: (timestamp) => {
    const date = new Date(timestamp * 1000);
    const weekdays = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const weekday = weekdays[date.getDay()];
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    return `${weekday}, ${day}-${month}-${year}, pukul ${hours}:${minutes}:${seconds}`;
  }
};