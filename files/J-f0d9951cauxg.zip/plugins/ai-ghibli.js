import fetch from 'node-fetch'

let handler = async (m, { conn, text, command }) => {
  if (!text) throw `Contoh penggunaan:\n.${command} kucing lucu`

  let res = await fetch(api +`/ai/ghibli?prompt=${encodeURIComponent(text)}`)
  if (!res.ok) throw 'Gagal menghubungi server!'
  let json = await res.json()

  if (!json.status) throw 'Gagal menghasilkan gambar, coba prompt lain.'
  let img = json.result

  await conn.sendMessage(m.chat, {
    image: { url: img },
    caption: `*Ghibli AI Art*\n\n🎨 Prompt: ${text}\n🖼️ Gambar oleh: *Ghibli AI*`,
    footer: 'OwensDev || Ghibli AI',
    buttons: [
      {
        buttonId: `.ghibli ${text}`,
        buttonText: { displayText: '[ Next Image ]' },
        type: 1
      }
    ],
    viewOnce: true,
    headerType: 6,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterName: `Zelda Ai - powered By JulxyZ 🌐`,
        newsletterJid: global.idsal,
        serverMessageId: null
      }
    }
  }, { quoted: m })
}

handler.help = ['ghibli <prompt>']
handler.tags = ['ai', 'image']
handler.command = /^ghibli$/i
handler.limit = true

export default handler