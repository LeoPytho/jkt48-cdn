/*
𝙆𝙮𝙯𝙍𝙮𝙯𝙯 𝙓𝘿
𝘊𝘳𝘦𝘢𝘵𝘰𝘳 𝘉𝘰𝘵 𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱
𝘸𝘢: wa.me/6287815560235
𝘵𝘦𝘭𝘦: t.me/kyzoffc
𝘸𝘦𝘣: s.id/kyzzxd
🚨Di Larang Menghapus Wm Ini🚨
*/

import fs from 'fs'
import path from 'path'

const handler = async (m, { conn}) => {
const directory = './sessions';
function deleteFilesExceptOne(directory, fileNameToKeep) {
  fs.readdir(directory, (err, files) => {
    if (err) {
      console.error('Terjadi kesalahan:', err);
      return;
    }
    
    files.forEach((file) => {
      const filePath = path.join(directory, file);
      if (file !== fileNameToKeep) {
        fs.unlink(filePath, (err) => {
          if (err) {
            console.error(`Gagal menghapus file ${file}:`, err);
          } else {
            console.log(`File ${file} berhasil dihapus.`);
          }
        });
      }
    });
  });
}
deleteFilesExceptOne(directory, 'creds.json');
m.reply('Suskess Clear all sessions ✅')
}
handler.command = handler.help = ['csessi', 'clearsessi']
handler.tags = ['owner']
handler.rowner = true
export default handler