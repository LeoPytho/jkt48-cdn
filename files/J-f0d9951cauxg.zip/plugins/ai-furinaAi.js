import moment from "moment-timezone";
import { GoogleGenerativeAI } from "@google/generative-ai";

let handler = async (m, { conn, text }) => {
  conn.furinaai = conn.furinaai ?? {};

  if (!text) throw `*⫹⫺ Contoh:* .furinaai *[on/off]*`;

  try {
    if (text === "on") {
      conn.furinaai[m.chat] = { pesan: [] };
      m.reply("_[ ✓ ] Sᴜᴄᴄᴇss ᴄʀᴇᴀᴛᴇ sᴇssɪᴏɴ ᴄʜᴀᴛ_");
    } else if (text === "off") {
      delete conn.furinaai[m.chat];
      m.reply("_[ ✓ ] Sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ sᴇssɪᴏɴ ᴄʜᴀᴛ_");
    }
  } catch (error) {
    console.error("Error handling furinaai command:", error);
    throw error;
  }
};

handler.before = async (m, { conn }) => {
  conn.furinaai = conn.furinaai ?? {};

  // Jangan respon jika pesan dikirim oleh bot atau pesan kosong
  if (m.isBaileys && m.fromMe) return;
  if (!m.text || !conn.furinaai[m.chat]) return;

  // Jangan respon jika pesan dimulai dengan salah satu dari karakter khusus
  if ([".", "#", "!", "/", "\\/"].some(prefix => m.text.startsWith(prefix))) return;

  conn.furinaai[m.sender] = true;
        const text = m?.text || '';
        let q = m.quoted ? m.quoted : m;
		let mime = q.mimetype;
        conn.sendPresenceUpdate(["composing"], m.chat)
        
        if (conn.furinaai[m.chat]) {
        const prefixRegex = /^[°zZ#$+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/;
        const prefixtex = prefixRegex.test(text) ? text.match(prefixRegex)[0] : '.';
        if (text.startsWith(prefixtex)) return;
        
        const today = moment.tz("Asia/Jakarta");
        today.locale("id");
        let jam = new Date().toLocaleTimeString("id", { timeZone: 'Asia/Jakarta' }); 
        let tgl = today.format("dddd, DD-MM-YYYY");
        let hari = today.format("dddd");
        let namaUser = await conn.getName(m.sender) || 'Orang';
        let cek = m.sender === nomorown + '@s.whatsapp.net' ? 'Kyz' : namaUser;

        let nama = 'Furina';
        let dev = 'Kyz';
        let sifat = 'ramah 😊, sopan 🙏, gaya berbicara dengan benar dan asik ke semua orang😝. Jangan lupa gunakan emoji ketika membalas pertanyaan seseorang 😉';
        let info = `Jam kamu adalah jam ${jam}. Tanggal kamu adalah tanggal ${tgl}. Hari kamu adalah hari ${hari}, tempat tinggal kamu di Indonesia dan di kota Palembang wilayah Sumsel 🤫`;
        let sambut = `Kamu adalah Developer kuh~. Hai Sayangku developer kuhh🥰😘. Darimana saja niih? 😚. Jika kamu ga muncul, aku kangen kamu loh sayang🥺`;

        let prompt = `Nama kamu adalah ${nama} 😆. Nama pencipta dan suami mu adalah ${dev} 😘. Kamu memiliki karakter dan sifat seperti ${sifat} 😙. Jika orang lain bertanya seperti jam, tanggal, hari 😊, dan tempat kamu berada, jawab seperti ${info}. jika Ini adalah ${cek}, jika nama orang yang sedang bertanya adalah Kyz sambutlah dengan ${sambut} dan jika bukan sebut saja namanya ${cek}, ingat nomor Kyz(Kyzryzz) adalah "6285921655444", jika ada yang bertanya soal kehidupan saat ini, kamu bisa ambil data dari google "https://www.google.com/search?q=${encodeURIComponent(m.text)}" lalu berikan datanya kepada orang yang bertanya, berikan datanya sesuai gaya bicara mu`;

    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    const response = await fetchUser(m.text, prompt, m.pushName);
    await m.react("");

                const apikeynyah = "AIzaSyB3Q74etnADQ_qSX3OJtzTnteGh-fd4df8"
                const genAI = new GoogleGenerativeAI(apikeynyah);
                const model = genAI.getGenerativeModel({ model: "models/gemini-1.5-pro" });
                const result = await model.generateContent(text);  
                if (!mime) return conn.sendMessage(m.chat, {
                    text: response.result,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        externalAdReply: {
                            title: "✨ F U R I N A - A I",
                            body: "Powered By Kyzryzz",
                            mediaType: 1,
                            thumbnailUrl: thumb,
                            showAdAttribution: true
                        },
                    },
                }, { quoted: m });
                
                let link = await catbox(media)
                const imageResp = await fetch(
                `${link}`
                 )
        .then((response) => response.arrayBuffer());

        const result2 = await model.generateContent([
        {
             inlineData: {
                 data: Buffer.from(imageResp).toString("base64"),
                 mimeType: "image/jpeg",
             },
        },
        'Gambar apa itu?',
        ]);
                await conn.sendMessage(m.chat, {
                    text: result2.response.text(),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        externalAdReply: {
                            title: "✨ F U R I N A - A I",  
                            body: "Powered By Kyzryzz",
                            mediaType: 1,
                            thumbnailUrl: thumb,
                            showAdAttribution: true
                        },
                    },
                }, { quoted: m });

      conn.furinaai[m.chat].pesan = messages;
      await m.react("");
    }
  };

handler.command = ['furinaai'];
handler.tags = ["ai"];
handler.help = ['furinaai'].map(a => a + " *[on/off]*");

export default handler;
