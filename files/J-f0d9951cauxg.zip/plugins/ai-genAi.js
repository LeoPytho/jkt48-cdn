let handler = async (m, { conn, text }) => {
  const q = m.quoted ? m.quoted : m;
  if (!q) throw `[❗] Kirim/reply foto waifu kamu yang ingin di ubah dengan caption */genai <prompt>*`;
  if (q.mtype !== "imageMessage") throw "[❗] Media hanya mendukung image saja!.";
  
  let img = await q.download();
  
  await load(); 
  
  const prompt = text || "edit karakter ini mengenakan hijab dan semua aurat seperti dada/payudara, paha hingga mata kaki, pundak hingga lengan serta leher(jika ada) tertutup oleh hijab atau pakaian!";
  let imageUrl = await func.toUrl(img);

  let results = [];
  for (let i = 0; i < 5; i++) {
    let { data: { result } } = await axios.get(
      APIs.ft + `/ai/genai?imageUrl=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`
    );

    let buf = Buffer.from(result.image, 'base64');

    results.push({
      image: buf,
      caption: `${prompt} ✅ Successfull ${i + 1}\n\n> ${global.wm || "Powered by Kyzryzz"}`
    });
  }

  if (results.length > 0) {
    await conn.sendAlbumMessage(m.chat, results, { quoted: m });
  } else {
    let { data: { result } } = await axios.get(
      APIs.ft + `/ai/genai?imageUrl=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`
    );
    let buf = Buffer.from(result.image, 'base64');
    await conn.sendFile(m.chat, buf, "GenAI-result.jpg", `*[ GEN - AI ]*\n\n${result.text}`, m);
  }
};

handler.command = handler.help = ["genai"];
handler.tags = ["ai","premium"];
handler.premium = true;

export default handler;