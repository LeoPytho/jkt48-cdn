import fetch from 'node-fetch'

let timeout = 120000
let poin = 500

let handler = async (m, { conn, usedPrefix }) => {
  conn.tebakbendera = conn.tebakbendera || {}
  let id = m.chat

  if (id in conn.tebakbendera) {
    return conn.reply(m.chat, '❗Masih ada soal belum terjawab di chat ini', conn.tebakbendera[id][0])
  }

  let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera2.json')).json()
  let json = src[Math.floor(Math.random() * src.length)]

  // Hint otomatis: ganti huruf vokal dengan "_"
  let hint = json.name.replace(/[AIUEOaiueo]/g, '_')

  let caption = `
🏳️‍🌈 *Tebak Bendera*
🌍 Bendera negara apakah ini?
💡 Hint: ${hint}
⏳ Timeout: ${(timeout / 1000).toFixed(0)} detik
🎁 Bonus: ${poin} XP
📝 Balas pesan ini untuk menjawab
📌 Ketik *nyerah* untuk menyerah
`.trim()

  let soalMsg = await conn.sendFile(m.chat, json.img, 'bendera.jpg', caption, m)

  conn.tebakbendera[id] = [
    soalMsg,
    json,
    poin,
    setTimeout(() => {
      if (conn.tebakbendera[id]) {
        conn.reply(m.chat, `⏰ *Waktu habis!*\nJawabannya adalah *${json.name}*`, conn.tebakbendera[id][0])
        delete conn.tebakbendera[id]
      }
    }, timeout)
  ]
}

handler.before = async (m, { conn }) => {
  conn.tebakbendera = conn.tebakbendera || {}
  let id = m.chat
  if (!conn.tebakbendera[id]) return
  if (!m.quoted) return
  if (!m.quoted.id || !m.quoted.id.includes(conn.tebakbendera[id][0].id)) return
  if (!m.text) return

  let json = conn.tebakbendera[id][1]
  let user = db.data.users[m.sender] || {}
  if (!user.exp) user.exp = 0

  if (m.text.toLowerCase() === 'nyerah') {
    clearTimeout(conn.tebakbendera[id][3])
    await conn.reply(m.chat, `😢 Kamu menyerah.\nJawabannya: *${json.name}*`, m)
    delete conn.tebakbendera[id]
  } else if (m.text.toLowerCase().trim() === json.name.toLowerCase().trim()) {
    user.exp += conn.tebakbendera[id][2]
    clearTimeout(conn.tebakbendera[id][3])
    await conn.reply(m.chat, `🎉 *Benar!* +${conn.tebakbendera[id][2]} XP`, m)
    delete conn.tebakbendera[id]
  } else {
    await conn.sendMessage(m.chat, {
      react: {
        text: '❌',
        key: m.key
      }
    })
  }
}

handler.help = ['tebakbendera']
handler.tags = ['game']
handler.command = /^tebakbendera$/i

export default handler