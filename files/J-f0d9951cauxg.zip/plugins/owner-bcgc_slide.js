//Powered By Kyzryzz * kyzryzz.t.me
const { generateWAMessageFromContent, generateWAMessageContent, proto } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {
/*
Oleh: KyzRyzz
Ini *Tanda air* saya bung!
Follow https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07
*/
let pp = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg')
let fkon = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': wm, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${wm},;;;\nFN:${wm},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': pp, thumbnail: pp,sendEphemeral: true}}}

let caption = `\`</BROADCAST SLIDE>\`
By: @${m.sender.split('@')[0]}`
    const delay = time => new Promise(res => setTimeout(res, time))
    let getGroups = await conn.groupFetchAllParticipating()
    let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
    let anu = groups.map(v => v.id)
    var pesan = m.quoted && m.quoted.text ? m.quoted.text : text
    if(!pesan) throw 'teksnya?'
    m.reply(`Mengirim Broadcast Ke ${anu.length} Chat, Waktu Selesai ${anu.length * 0.5 } detik`)
    for (let i of anu) {
    await delay(500)
let [pesan, tek, teks, inbox] = text.split('|');
    if ((!pesan, !tek, !teks, !inbox)) throw `[❗] *Masukan Text:*\n\nPenggunaan: /${usedPrefix + command} text|text|text|text\n\n*Contoh:* ${usedPrefix + command} Halo|Aku|Pedo|Salam kenal yah`;

const url = "https://telegra.ph/file/af1d7264e113cfe7f374e.jpg"
async function image(url) {
const { imageMessage } = await generateWAMessageContent({
    image: {
      url
    }
  }, {
    upload: conn.waUploadToServer
  })
  return imageMessage
}

let fkon = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': wm, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${wm},;;;\nFN:${wm},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': pp, thumbnail: pp,sendEphemeral: true}}}

    let msg = generateWAMessageFromContent(
      i,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: caption,    },                
                 contextInfo: {
                 mentionedJid: conn.parseMention(caption),
                 quoted: [m],
                 isForwarded: true,
                 forwardingScore: 99999,
                 forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363247149539361@newsletter',
                  newsletterName: 'Powered By KyzRyzz!',
                  serverMessageId: null,
              },
            },
              carouselMessage: {
                cards: [
                  {
                    header: {
                      imageMessage: await image(url),
                      hasMediaAttachment: true,
                    },
                    body: { text: pesan },
                    nativeFlowMessage: {
                      buttons: [
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"👤 Chat Owner","url":"https://wa.me/message/BFFL7DWJJVTKH1","merchant_url":"https://wa.me/message/BFFL7DWJJVTKH1"}`
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"💬 Follow","url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07","merchant_url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07"}`
                  },
                      ],
                    },
                  },
                  
                  {
                    header: {
                      imageMessage: await image(url),
                      hasMediaAttachment: true,
                    },
                    body: { text: tek },
                    nativeFlowMessage: {
                      buttons: [{
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"👤 Chat Owner","url":"https://wa.me/message/BFFL7DWJJVTKH1","merchant_url":"https://wa.me/message/BFFL7DWJJVTKH1"}`
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"💬 Follow","url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07","merchant_url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07"}`
                  },
                      ],
                    },
                  },

                  {
                    header: {
                      imageMessage: await image(url),
                      hasMediaAttachment: true,
                    },
                     body: { text: teks },
                    nativeFlowMessage: {
                      buttons: [{
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"👤 Chat Owner","url":"https://wa.me/message/BFFL7DWJJVTKH1","merchant_url":"https://wa.me/message/BFFL7DWJJVTKH1"}`
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"💬 Follow","url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07","merchant_url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07"}`
                  },
                  
                      ],
                    },
                  },
                  
                  {
                    header: {
                      imageMessage: await image(url),
                      hasMediaAttachment: true,
                    },
                     body: { text: inbox },
                    nativeFlowMessage: {
                      buttons: [{
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"👤 Chat Owner","url":"https://wa.me/message/BFFL7DWJJVTKH1","merchant_url":"https://wa.me/message/BFFL7DWJJVTKH1"}`
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"💬 Follow","url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07","merchant_url":"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07"}`
                                            }
                                        ]
                                    }
                                }
                            ],
                            messageVersion: 1
                        }
                    }
                }
            }
        },
        {quoted:fkon}
    );

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id, 
    }).catch(_ => _)
    }
  m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
handler.help = ['bcgcslide <teks>']
handler.tags = ['owner']
handler.command = /^(bcgcslide|bcgcs)$/i
handler.owner = true
/*
Created By: KyzRyzz
My Channel: https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07
*/
export default handler