const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = (await import('@adiwajshing/baileys')).default
let handler = async (m, { conn, isROwner, text }) => {
const feriv = {
  key: {
    participant: wa,
    remoteJid: wa
  },
  message: { conversation: '_Furina - AI Terverifikasi Oleh WhatsApp_' }
}
 const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/bf29252842366db5ae047.jpg");
    const delay = time => new Promise(res => setTimeout(res, time)) 
   let gc = (Object.keys(conn.chats)).filter((v) => v.endsWith("@g.us"))
    var pesan = m.quoted && m.quoted.text ? m.quoted.text : text
    if(!pesan) throw 'teksnya?'
    m.reply(`Mengirim Broadcast Ke ${gc.length} Group, Waktu Selesai ${gc.length * 0.5 } detik`)
    for (let i of gc) {
    await delay(500) 
let msg = generateWAMessageFromContent(i, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: {
			newsletterJid: idsal,
			newsletterName: '🔴 Pᴏweʀed By KyzRyzz', 
			serverMessageId: -1
	    	},
            externalAdReply: {
            title: '🔮 ғᴜʀɪɴᴀ - ᴀɪ ᴏғғɪᴄɪᴀʟ ɢʀᴏᴜᴘ ᴄʜᴀᴛ', 
            body: 'ɢʀᴏᴜᴘ ᴄʜᴀᴛ ғᴜʀɪɴᴀ - ᴀɪ',
            thumbnailUrl: thumb,
            sourceUrl: sgc,
            mediaType: 1,
            renderLargerThumbnail: true
            },
          }, 
          body: proto.Message.InteractiveMessage.Body.create({
            text: pesan,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm,
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: '*[ 📢 PESAN DARI OWNER ]*',
            subtitle: '',
            hasMediaAttachment: true,...(await prepareWAMessageMedia({ document: { url: 'https://wa.me/6285921655444' }, mimetype: 'image/png', fileName: `Fᴜʀɪɴᴀ - ᴀɪ ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ`, jpegThumbnail: await conn.resize(pp, 400, 400), fileLength: 1000000000000 }, { upload: conn.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
          buttons: [
{
                 "name": "cta_url",
                 "buttonParamsJson": `{\"display_text\":\"Hᴜʙᴜɴɢɪ 📞\",\"url\":\"https://wa.me/${nomorown}\",\"merchant_url\":\"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07\"}`
              },
              {
                 "name": "cta_url",
                 "buttonParamsJson": "{\"display_text\":\"Iɴғᴏ ʙᴏᴛ 🌐\",\"url\":\"https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q\",\"merchant_url\":\"https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07\"}"
              }
           ],
          })
        })
    }
  }
}, {quoted:feriv})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
}).catch(_ => _)
    }
  m.reply(`Sukses Mengirim Broadcast Ke ${gc.length} Group`)
}
handler.help = ['bcgcbutton <teks>']
handler.tags = ['owner']
handler.command = /^(bcgcbutton|bcgcb)$/i
handler.owner = true
export default handler
/*
Created By: KyzRyzz
Credit: https://whatsapp.com/channel/0029VajfpGV0AgWEdZah4K07
*/