import aoi from "../scraper/aoiWaifu.js"

const handler = async (m, {
    text,
    conn,
    command
}) => {
    const jumlah = text ? parseInt(text) : 2;
    let { key } = await m.reply(wait);
    const results = await aoi(jumlah);
    
    let medias = [];
    let p = 1;
    if (results.length > 0) {
        for (let i = 0; i < results.length; i++) {
            const { image, title, likeCount } = results[i];
            medias.push({
                image: { url: image },
                caption: `*[ AOI PICS ${p++}/${results.length} ]*\njudul: ${title}\nlike: ${likeCount}`
            });
        }
        let kyz = await conn.sendMessage(m.chat, { text: `Mengirim ${jumlah} gambar dari sumber aoi.live`, edit: key }, { quoted: m });
        await conn.sendAlbumMessage(m.chat, medias, { quoted: m });
        let a = await conn.sendMessage(m.chat, { text: `✔ Selesai mengirimkan semua gambar dari resul yg tersedia..`, edit: kyz.key }, { quoted: m });
        
        // Menghapus pesan a dengan cara lain
        setTimeout(async () => {
            try {
                await conn.sendMessage(m.chat, { delete: a.key }); // Menghapus pesan a
            } catch (error) {
                console.error("Gagal menghapus pesan:", error);
            }
        }, 5000); // Menghapus setelah 5 detik
    } else {
        m.reply('[❗] Tidak ada gambar.');
    }
}

handler.help = ['waifuaoi <jumlah>'];
handler.tags = ['anime', 'internet'];
handler.command = /^waifuaoi|aoi|waifu/i;
handler.limit = 2;

export default handler;