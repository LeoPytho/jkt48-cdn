const handler = async (m, { conn, text, usedPrefix, command, args }) => {
    try {
        if (args.length === 0) return m.reply(`Example: ${usedPrefix} ${command} 537212033`);
        const id = args[0];
        const apiUrl = `https://vapis.my.id/api/ff-stalk?id=${id}`;
        const response = await fetch(apiUrl);
        const json = await response.json();
        if (!json.status) return m.reply('Failed to fetch data. User ID might be invalid.');
        const data = json.data;
        const account = data.account;
        const pet = data.pet_info;
        const guild = data.guild;
        const items = data.equippedItems;

        let text = `*👤 FREE FIRE USER INFO*\n\n`;
        text += `*🆔 User ID*: ${account.id}\n`;
        text += `*👤 Username*: ${account.name}\n`;
        text += `*🔰 Level*: ${account.level}\n`;
        text += `*⭐ XP*: ${account.xp}\n`;
        text += `*🌍 Region*: ${account.region}\n`;
        text += `*👍 Likes*: ${account.like}\n`;
        text += `*📝 Bio*: ${account.bio}\n`;
        text += `*🎂 Created*: ${account.create_time}\n`;
        text += `*⏱️ Last Login*: ${account.last_login}\n`;
        text += `*🎖️ Honor Score*: ${account.honor_score}\n`;
        text += `*🎯 BR Points*: ${account.BR_points}\n`;
        text += `*🔫 CS Points*: ${account.CS_points}\n`;
        text += `*🎫 Booyah Pass*: ${account.booyah_pass ? 'Yes' : 'No'}\n`;
        text += `*🏆 Booyah Pass Badge*: ${account.booyah_pass_badge}\n\n`;

        if (pet) {
            text += `*🐱 PET INFO*\n`;
            text += `*🐾 Name*: ${pet.name}\n`;
            text += `*🔰 Level*: ${pet.level}\n`;
            text += `*⭐ XP*: ${pet.xp}\n\n`;
        }

        if (guild) {
            text += `*👥 GUILD INFO*\n`;
            text += `*🛡️ Name*: ${guild.name}\n`;
            text += `*🆔 ID*: ${guild.id}\n`;
            text += `*🔰 Level*: ${guild.level}\n`;
            text += `*👥 Members*: ${guild.member}/${guild.capacity}\n\n`;
        }

        text += `*🎮 EQUIPPED ITEMS*\n`;
        // Assuming items is an array, you may need to format it accordingly
        items.forEach(item => {
            text += `*🪖 Item*: ${item.name}\n`;
        });

        m.reply(text);
    } catch (error) {
        console.error('Plugin error:', error);
        m.reply(`❌ *ERROR:* ${error.message}`);
    }
};

handler.command = /^(epep|ff|ffstalk)$/i; 
handler.premium = false; 
handler.limit = false; 
handler.owner = false; 
handler.tags = ["command"]; 

export default handler;