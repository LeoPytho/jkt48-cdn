/*
 * 𝙊𝙬𝙚𝙣𝙨𝘿𝙚𝙫
 * 𝘵𝘦𝘭𝘦: https://t.me/owenssw
 * 𝘪𝘯𝘧𝘰: https://s.id/26AYH
 * 𝘺𝘵: https://youtube.com/CekGem
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
 * 𝙶𝚛𝚘𝚞𝚙: https://chat.whatsapp.com/LQBLGAalERjE1P5X3REnGC

 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁  
*/

var handler = async (m, { conn, usedPrefix: _p }) => {
  let info = `Iyaaa? Ada apa? Anda mencari saya? Untuk saat ini, orangnya belum membuka chat anda, harap tunggu sebentar yah, pesan tetap dikirimkan kok ke penerima. Terimakasih, Semoga harimu Menyenangkan.😇`;
  
  await conn.reply(m.chat, info, m);
  await conn.sendMessage(m.chat, {
    react: {
      text: '😇',
      key: m.key,
    },
  });
};

// UNTUK handler.customPrefix TAMBAHIN YANG KALIAN MAU YA DAN JANGAN LUPA JUGA DIGANTI PADA BAGIAN if text
handler.customPrefix = /^(Kak|Kakak|Min|Admin|Owner)$/i;
handler.command = new RegExp();

export default handler;