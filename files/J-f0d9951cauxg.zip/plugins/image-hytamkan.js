import uploadImage from "../lib/uploadImage.js";

let handler = async (m, { conn, text }) => {
  async function load() {
    await m.react(`🕐`);
    await conn.delay(1500);
    await m.react(`🕑`);
    await conn.delay(1500);
    await m.react(`🕓`);
    await conn.delay(1500);
    await m.react(`🕖`);
    await conn.delay(1500);
    await m.react(`🕘`);
    await conn.delay(1500);
    await m.react(`🕙`);
    await conn.delay(1500);
    await m.react(`🕛`);
  }

  const q = m.quoted ? m.quoted : m;
  if (!q) throw `[❗] Kirim/reply foto suatu karakter kamu yang ingin di hytamkan dengan caption */hytamkan*`;
  if (q.mtype !== "imageMessage") throw "[❗] Media hanya mendukung image saja!.";

  let image = await q.download();
  load();

  let imageUrl = await uploadImage(image);
  const prompt = "ubah kulit karakter ini menjadi gelap atau hitam seluruh nya";

  let { data: { result } } = await axios.get(
    APIs.ft + `/ai/genai?imageUrl=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`
  );

  let buf = Buffer.from(result.image, 'base64');
  await conn.sendMessage(m.chat, {
    image: buf,
    caption: `✅ Success meng-Hytamkan\n\n> ${global.wm || "Powered by Kyzryzz"}`,
    contextInfo: {
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idch
      }
    }
  });

  setTimeout(async () => {
    await m.react(`✅`);
  }, 2500);
  await m.react(``);
};

handler.command = handler.help = ["hytamkan"];
handler.tags = ["image", "ai", "tools"];
handler.limit = true;

export default handler;