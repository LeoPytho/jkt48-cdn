var handler  = async (m, 
             { conn, 
                usedPrefix: _p }) => {

var inf = `*ɪʏʏaʜ? ᴀᴅᴀ ᴀᴘᴀ?*,\nғᴜʀɪɴᴀ ᴅɪ sɪɴɪ ᴋᴏᴏᴋ (づ￣ ³￣)づ`

let aKyzz = [
      {
        buttonId: "/menu",
        buttonText: {
          displayText: "📜 ᴍᴇɴᴜ",
        },
      },
      {
        buttonId: "/ping",
        buttonText: {
          displayText: "📍 ᴘɪɴɢ",
        },
      },
    ];
    conn.bubbleThumbImg(m.chat, global.thumb, inf, footer, aKyzz, footer, wm, global.furina, m)
}
handler.customPrefix = /^(tes|test|sayan(g|k)?)$/i
handler.command = new RegExp
export default handler