import { promises } from 'fs'
import canvafy from "canvafy";
import { join } from 'path'
import { xpRange } from '../lib/levelling.js'
import moment from 'moment-timezone'
import os from 'os'
import fs from 'fs'
import fetch from 'node-fetch'
import { createHash } from 'crypto'
let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i
let {
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = (await import('@adiwajshing/baileys')).default
let handler = async function (m, { conn, text, usedPrefix }) {
  let sn = createHash('md5').update(m.sender).digest('hex')
let cap = `</> ʏᴏᴜʀ sᴇʀɪᴀʟ ɴᴜᴍʙᴇʀ </>`
let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: sn,
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: cap, 
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "Y O U R  S E R I A L  N U M B E R  I S\n\n", 
                        subtitle: "", 
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                 "name": "cta_copy",
                 "buttonParamsJson": `{\"display_text\":\"ᴄᴏpʏ ʏᴏᴜʀ sᴇʀɪᴀʟ ɴᴜᴍʙᴇʀ 🔮\",\"id\":\"123456789\",\"copy_code\":\"${sn}\"}`
              }, 
           ],
          })
        })
    }
  }
}, {quoted:m})

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}

handler.help = ['ceksn','mysn']
handler.tags = ['main', 'info']
handler.command = /^((cek|my)sn|sn)$/i
handler.register = true 

export default handler