let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`[❗] Input genre query\nEx: ${usedPrefix + command} romantis`);
    }

    try {
        const hasil = (await axios.get(APIs.ft + "/internet/cerpen?q=" +text)).data.result;
        m.react("📖")
        const response = `
*📚 Judul:* ${hasil.title}
*✍️ Penulis:* ${hasil.author}
*🏷️ Kategori:* ${hasil.kategori}
*📆 Lolos Moderasi:* ${hasil.lolos}

*📖 Cerita:*
${hasil.cerita}
        `;

        await conn.sendMessage(m.chat, { text: response, contextInfo: {
        externalAdReply: {
         title: hasil.title, 
         body: `Author: ${hasil.author} | Kategori: ${hasil.kategori}`, 
         thumbnailUrl: thumb, 
         renderLargerThumbnail: true
        }}}, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply('[❗] Terjadi kesalahan saat mengambil cerpen. Coba lagi nanti.');
    }
};

handler.help = ['cerpen <kategori>'];
handler.tags = ['internet','fun','search'];
handler.limit = true;
handler.register = true;
handler.command = /^(cerpen)$/i;

export default handler;