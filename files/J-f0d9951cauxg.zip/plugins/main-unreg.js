//Powered By Kyzryzz * kyzryzz.t.me
import { createHash } from 'crypto'

let handler = async function (m, { conn, args }) {
let hidr = "📮 Sᴇʀɪᴀʟ ɴᴜᴍʙᴇʀ ᴋᴏsᴏɴɢ, sɪʟᴀʜᴋᴀɴ ᴄᴇᴋ sᴇʀɪᴀʟ ɴᴜᴍʙᴇʀ ᴀɴᴅᴀ";
  if (!args[0]) throw hidr

  let user = global.db.data.users[m.sender]
  let sn = createHash('md5').update(m.sender).digest('hex')
let hdr = `[❗] Sᴇʀɪᴀʟ ɴᴜᴍʙᴇʀ sᴀʟᴀʜ!, sɪʟᴀʜᴋᴀɴ ɪɴᴘᴜᴛ sᴇʀɪᴀʟ ɴᴜᴍʙᴇʀ ᴀɴᴅᴀ`;
let ftr = "ᴋʟɪᴋ ᴛᴏᴍʙᴏʟ ᴅɪ ʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴄᴇᴋ sɴ ᴍᴜ";

  if (args[0] !== sn) throw ftr

  user.registered = false
  user.unreg = true
  m.reply('📛Kᴀᴍᴜ ʙᴇʀʜᴀsɪʟ ᴋᴇʟᴜᴀʀ ᴅᴀʀɪ database\n\nFᴜʀɪɴᴀ - ᴀɪ')
}
handler.help = ['unreg']
handler.tags = ['xp']
handler.command = /^unreg(ister)?$/i
handler.register = true

export default handler