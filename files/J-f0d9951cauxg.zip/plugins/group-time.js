let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Parsing perintah dan waktu
  const times = text.match(/(\d+)([smhd])/g);
  if (!times) return m.reply(`Penggunaan:\n${usedPrefix + command} <ᴡᴀᴋᴛᴜ><sᴀᴛᴜᴀɴ> <ᴛɪᴍᴇ><sᴀᴛᴜᴀɴ>\nCᴏɴᴛᴏʜ:\n${usedPrefix + command} 1h 30m\n\nᴍᴀᴋᴀ ɢʀᴏᴜᴘ ᴀᴋᴀɴ ᴅɪ Bᴜᴋᴀ sᴇʟᴀᴍᴀ 1ᴊᴀᴍ 30ᴍᴇɴɪᴛ\n\nUnit(satuan):\nd untuk > Hari(day)\nh untuk > Jam(hour)\nm untuk > Menit(minutes)\ns untuk > Detik(second)`);

  const timeMs = times.reduce((total, time) => {
    const value = parseInt(time.slice(0, -1));
    const unit = time.slice(-1);
    return total + convertToMilliseconds(value, unit);
  }, 0);

  if (!timeMs) return m.reply('Unit waktu yang valid adalah s (detik), m (menit), h (jam), atau d (hari).');

  // Set Timer
  setTimeout(async () => {
    if (command === 'opentime') {
      await conn.groupSettingUpdate(m.chat, 'not_announcement');
      m.reply('Grup telah dibuka!');
    } else if (command === 'closetime') {
      await conn.groupSettingUpdate(m.chat, 'announcement');
      m.reply('Grup telah ditutup!');
    }
  }, timeMs);

  m.reply(`Perintah diterima. Grup akan ${command === 'opentime' ? 'dibuka' : 'ditutup'} dalam ${text}`);
}

// Fungsi untuk mengonversi waktu ke milidetik
const convertToMilliseconds = (time, unit) => {
  switch (unit) {
    case 's':
      return time * 1000;
    case 'm':
      return time * 60 * 1000;
    case 'h':
      return time * 60 * 60 * 1000;
    case 'd':
      return time * 24 * 60 * 60 * 1000;
    default:
      return 0;
  }
}

handler.help = ["opentime <time><unit> <time><unit>", "closetime <time><unit> <time><unit>"]
handler.tags = ["group"]
handler.command = ["opentime"," ot","closetime","ct"]

// Membatasi perintah hanya untuk admin
handler.admin = true
handler.botAdmin = true

export default handler;