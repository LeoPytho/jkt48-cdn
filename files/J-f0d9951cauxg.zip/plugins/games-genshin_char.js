/* 
Plugin Genshin Impact 
Free timpa wm
*/

import axios from 'axios';
import cheerio from 'cheerio';

const url = 'https://genshin.gg/characters';

async function scrapeCharacters() {
  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);
    const characterData = [];

    $('.character-portrait').each((index, element) => {
      const name = $(element).find('.character-name').text().trim();
      const imgUrl = $(element).find('.character-icon').attr('src');
      characterData.push({ name, imageUrl: imgUrl });
    });

    return characterData;
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
    throw new Error('Failed to scrape character data');
  }
}

const handler = async (m, { conn, command, usedPrefix }) => {
  try {
    const characters = await scrapeCharacters();

    if (characters.length === 0) {
      return conn.reply(m.chat, '⚠️ Tidak ada karakter yang ditemukan.', m);
    }

    let message = '🌟 *Daftar Karakter Genshin Impact*\n\n';
    characters.forEach((character, index) => {
      message += `🎮 *${index + 1}. ${character.name}*\n🔗 ${character.imageUrl}\n\n`;
    });

    await conn.reply(m.chat, message, m);
  } catch (error) {
    console.error(error);
    await conn.reply(m.chat, '❌ Terjadi kesalahan saat mengambil data karakter.', m);
  }
};

handler.help = ['genshinchars'];
handler.tags = ['games'];
handler.command = /^(genshinchars|genshin)$/i;

export default handler;