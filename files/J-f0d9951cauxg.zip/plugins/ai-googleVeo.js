import axios from 'axios';

let handler = async (m, { conn, text, args }) => {
  if (!text) throw '🚫 masukkan teks untuk membuat video.\nContoh: .aivideo Bali Indonesia sunset';

  const query = encodeURIComponent(text);
  m.reply("⏰ wait ngab tunggu 1-3 menit untuk proses pembuatan video")
  try {
    const {data} = await axios.get(APIs.jl +`/ai/googleveo?prompt=${query}`);
    const jul = data.result
    
    if (!jul.code || !jul.data) {
      throw 'gagal membuat video dari teks. mungkin server sedang sibuk atau prompt tidak valid.';
    }

    const vidnyah = jul.data.video_url;

    const caption = `</> Prompt: ${text}`

    await conn.sendMessage(m.chat, {
video: { url: vidnyah },
caption: caption
}, { quoted: m })
  } catch (e) {
    console.error(e);
    throw `⚠️ terjadi kesalahan saat memproses permintaan: ${e}.`;
  }
};

handler.help = ["aivideo <text>", "veo3 <text>"];
handler.tags = ["ai"];
handler.command = /^(aivideo|videoai|veo3|googleveo)$/i;
handler.limit = 2;

export default handler;