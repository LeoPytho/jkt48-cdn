import moment from 'moment-timezone';

let handler = async (m, { conn }) => {
    let stats = Object.entries(db.data.stats).map(([key, val]) => {
        let name = Array.isArray(plugins[key]?.help) ? plugins[key]?.help?.join(' , ') : plugins[key]?.help || key;
        if (/exec/.test(name)) return null;
        return { name, ...val };
    }).filter(Boolean);

    stats = stats.sort((a, b) => b.total - a.total);
    if (stats.length === 0) return conn.sendMessage(m.chat, { text: "Tidak ada data statistik yang tersedia." }, { quoted: m });

    let handlers = stats.slice(0, 100).map(({ name, total, last }) => {
        let lastUsed = last ? moment(last).tz('Asia/Jakarta').locale('id').format('dddd, DD MMMM YYYY HH:mm') : 'Belum pernah digunakan';
        return ` *Command/Plugin* : *${name}*
• *Global HIT* : ${total}
• *Terakhir Digunakan pada* : ${lastUsed}`;
    }).join("\n\n");

    await conn.sendMessage(m.chat, {
        text: handlers,
        contextInfo: {
            externalAdReply: {
                title: `[ 🏆 TOP 100 COMMAND TERPOPULER ]`, 
                showAdAttribution: true,
                thumbnailUrl: thumb,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });

    let topStats = stats.slice(0, 5);
    if (topStats.length < 5) return;

    let handl = topStats.map(({ name, total, last }) => {
        let lastUsed = last ? moment(last).tz('Asia/Jakarta').locale('id').format('dddd, DD MMMM YYYY HH:mm') : 'Belum pernah digunakan';
        return `*Command/Plugin* : *${name}*
• *Digunakan Sebanyak* : ${total}x`;
    }).join("\n\n");

    let pollVotes = topStats.map(({ name, total }) => [name, total]);

    await conn.sendMessage(m.chat, {
        pollResult: {
            name: "[ 🏆 TOP 5 COMMAND TERPOPULER ]\n\n" + handl,
            votes: pollVotes
        }
    }, { quoted: null });
};

handler.command = handler.help = ['dashboard', 'dash', 'views'];
handler.tags = ['main'];
handler.limit = true;
export default handler;