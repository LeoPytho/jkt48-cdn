import uploadImage from "../lib/uploadImage.js"

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) return m.reply(`Masukkan tautan yang valid\n\n*Contoh:*\n${usedPrefix + command} link`)

    let link = /^(https?:\/\/)/.test(text) ? text : "https://" + text
    await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key}})
    await m.reply(wait)
    try {
        let res = `https://image.thum.io/get/png/fullpage/viewportWidth/2400/${link}` 
        await conn.sendMessage(m.chat, {
            image: { url: res },
            caption: `*SCREENSHOT*\n- ${link}\n\n*Request:*\n- @${m.sender.split('@')[0]}`,
            mentions: [m.sender]
        }, { quoted: m })

        await conn.sendMessage(m.chat, { react: { text: "✅" , key: m.key}})
    } catch (e) {
        await conn.sendMessage(m.chat,  { react: { text: "❌" , key: m.key}})
        await m.reply(e.toString())
    }
}

handler.help = ["ss", "ssf", "ssweb"]
handler.tags = ["tools"]
handler.command = /^ss(web|f)?$/i
export default handler