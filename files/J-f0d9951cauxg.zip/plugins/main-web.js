let handler = async (m) => {
let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
    if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak ada didalam data base'
    let user = global.db.data.users[who]
    let limit = user.premiumTime >= 1 ? '∞' : user.limit    
let kontol = { key: { remoteJid: 'status@broadcast', participant: '13135550002@s.whatsapp.net' }, message: { orderMessage: { itemCount: limit, status: 1, thumbnail: await conn.resize(await getBuffer(pp),300,150), surface: 1, message: 'ʏ ᴏ ᴜ ʀ  ʟ ɪ ᴍ ɪ ᴛ: ' + limit, orderTitle: wm, sellerJid: '0@s.whatsapp.net' } } }
let i = await style("balance", 1) 
let balance = i.split("").join(" ");
let ah = `▧ *ʟ ɪ ᴍ ɪ ᴛ - ${balance}*
│ ∘ *ᴜsᴇʀɴᴀᴍᴇ:* ${user.registered ? user.name : conn.getName(who)}
│ ∘ *sᴛᴀᴛᴜs:*  ${who.split`@`[0] == global.nomorwa ? '🎗️Developer🎗️' : user.premiumTime >= 1 ? '👑ℙ𝕣𝕖𝕞𝕚𝕦𝕞👑' : user.level >= 1000 ? '🪖ᴇʟɪᴛᴇ ᴜsᴇʀ🪖' : '👤Free User👤'}
│ ∘ *money:* ${users.money}
│ ∘ *ʟɪᴍɪᴛ:* ${limit}
└───╌┄❍`
conn.sendMessage(m.chat, {
text: ah,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: ' ᴛ ʜ ɪ s - '+balance,
thumbnailUrl: 'https://files.catbox.moe/tgy54p.jpg',
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: kontol})
}
handler.help = ['limit [@user]']
handler.tags = ['main']
handler.command = /^(limit)$/i
export default handler