let fs = require('fs')

let handler = async (m, { text, usedPrefix, command }) => {
    if (conn.user.jid !== global.conn.user.jid) return
    if (!text) return conn.reply(m.chat, `• *Example :* ${usedPrefix + command} menu`, m)

    try {
        if (!m.quoted.text) return conn.reply(m.chat, `🚩 Reply Code Message!`, m)

        let code = m.quoted.text
        let path = `plugins/${text}.js`

        // Deteksi apakah kode yang dikutip merupakan ESM dengan regex yang lebih akurat
        let isESM = /^\s*import\s+.*\s+from\s+['"].+['"]|^\s*export\s+(default\s+|const|let|var|function|class)/m.test(code)

        if (isESM) {
            return conn.reply(m.chat, `🚩 Detected ESM Code!\nUse *${usedPrefix}spesm <name>* or *${usedPrefix}sp-esm <name>* instead.`, m)
        }

        // Simpan file jika bukan ESM
        await fs.writeFileSync(path, code)
        conn.reply(m.chat, `🚩 CJS Plugin Saved in ${path}`, m)

    } catch (error) {
        console.log(error)
        conn.reply(m.chat, "🚩 Reply Code Message!", m)
    }
}

handler.help = ['sp'].map(v => v + ' *<text>*')
handler.tags = ['owner']
handler.command = /^sp$/i
handler.owner = true

module.exports = handler
